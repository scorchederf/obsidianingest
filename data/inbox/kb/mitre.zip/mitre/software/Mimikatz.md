---
aliases: 
    - S0002
    
mitre-attack: https://attack.mitre.org/software/S0002
---

## S0002

[Mimikatz](https://attack.mitre.org/software/S0002) is a credential dumper capable of obtaining plaintext Windows account logins and passwords, along with many other features that make it useful for testing the security of networks. [^11]  [^10] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1003.006-dcsync\|T1003.006]] | DCSync | [Mimikatz](https://attack.mitre.org/software/S0002) performs credential dumping to obtain account and password information useful in gaining access to additional systems and enterprise network resources. It contains functionality to acquire information about credentials in many ways, including from DCSync/NetSync.[^11] [^5] [^8] [^4] [^1]  |
| [[T1555-credentials_from_password_stores\|T1555]] | Credentials from Password Stores | [Mimikatz](https://attack.mitre.org/software/S0002) performs credential dumping to obtain account and password information useful in gaining access to additional systems and enterprise network resources. It contains functionality to acquire information about credentials in many ways, including from the credential vault and DPAPI.[^11] [^5] [^8] [^4] [^1] 	 |
| [[T1207-rogue_domain_controller\|T1207]] | Rogue Domain Controller | [Mimikatz](https://attack.mitre.org/software/S0002)’s `LSADUMP::DCShadow` module can be used to make AD updates by temporarily setting a computer to be a DC.[^11] [^10]  |
| [[T1552.004-private_keys\|T1552.004]] | Private Keys | [Mimikatz](https://attack.mitre.org/software/S0002)'s `CRYPTO::Extract` module can extract keys by interacting with Windows cryptographic application programming interface (API) functions.[^10]  |
| [[T1134.005-sid_history_injection\|T1134.005]] | SID-History Injection | [Mimikatz](https://attack.mitre.org/software/S0002)'s `MISC::AddSid` module can append any SID or user/group account to a user's SID-History. [Mimikatz](https://attack.mitre.org/software/S0002) also utilizes [SID-History Injection](https://attack.mitre.org/techniques/T1134/005) to expand the scope of other components such as generated Kerberos Golden Tickets and DCSync beyond a single domain.[^10] [^3]  |
| [[T1547.005-security_support_provider\|T1547.005]] | Security Support Provider | The [Mimikatz](https://attack.mitre.org/software/S0002) credential dumper contains an implementation of an SSP.[^11]  |
| [[T1550.002-pass_the_hash\|T1550.002]] | Pass the Hash | [Mimikatz](https://attack.mitre.org/software/S0002)'s `SEKURLSA::Pth` module can impersonate a user, with only a password hash, to execute arbitrary commands.[^10] [^4] [^1]  |
| [[T1098-account_manipulation\|T1098]] | Account Manipulation | The [Mimikatz](https://attack.mitre.org/software/S0002) credential dumper has been extended to include Skeleton Key domain controller authentication bypass functionality. The `LSADUMP::ChangeNTLM` and `LSADUMP::SetNTLM` modules can also manipulate the password hash of an account without knowing the clear text value.[^10] [^7]  |
| [[T1550.003-pass_the_ticket\|T1550.003]] | Pass the Ticket | [Mimikatz](https://attack.mitre.org/software/S0002)’s `LSADUMP::DCSync` and `KERBEROS::PTT` modules implement the three steps required to extract the krbtgt account hash and create/use Kerberos tickets.[^10] [^3] [^2] [^4]  |
| [[T1555.003-credentials_from_web_browsers\|T1555.003]] | Credentials from Web Browsers | [Mimikatz](https://attack.mitre.org/software/S0002) performs credential dumping to obtain account and password information useful in gaining access to additional systems and enterprise network resources. It contains functionality to acquire information about credentials in many ways, including from DPAPI.[^11] [^5] [^8] [^4] 	 |
| [[T1558.001-golden_ticket\|T1558.001]] | Golden Ticket | [Mimikatz](https://attack.mitre.org/software/S0002)'s kerberos module can create golden tickets.[^6] [^1]  |
| [[T1003.002-security_account_manager\|T1003.002]] | Security Account Manager | [Mimikatz](https://attack.mitre.org/software/S0002) performs credential dumping to obtain account and password information useful in gaining access to additional systems and enterprise network resources. It contains functionality to acquire information about credentials in many ways, including from the SAM table.[^11] [^5] [^8] [^4]  |
| [[T1003.001-lsass_memory\|T1003.001]] | LSASS Memory | [Mimikatz](https://attack.mitre.org/software/S0002) performs credential dumping to obtain account and password information useful in gaining access to additional systems and enterprise network resources. It contains functionality to acquire information about credentials in many ways, including from the LSASS Memory.[^11] [^5] [^8] [^4]  |
| [[T1558.002-silver_ticket\|T1558.002]] | Silver Ticket | [Mimikatz](https://attack.mitre.org/software/S0002)'s kerberos module can create silver tickets.[^6]  |
| [[T1555.004-windows_credential_manager\|T1555.004]] | Windows Credential Manager | [Mimikatz](https://attack.mitre.org/software/S0002) contains functionality to acquire credentials from the Windows Credential Manager.[^9]  |
| [[T1649-steal_or_forge_authentication_certificates\|T1649]] | Steal or Forge Authentication Certificates | [Mimikatz](https://attack.mitre.org/software/S0002)'s `CRYPTO` module can create and export various types of authentication certificates.[^10]  |
| [[T1003.004-lsa_secrets\|T1003.004]] | LSA Secrets | [Mimikatz](https://attack.mitre.org/software/S0002) performs credential dumping to obtain account and password information useful in gaining access to additional systems and enterprise network resources. It contains functionality to acquire information about credentials in many ways, including from the LSA.[^11] [^5] [^8] [^4]  |




## References

[^1]: [Cobalt Strike Manual 4.3 November 2020](https://web.archive.org/web/20210708035426/https://www.cobaltstrike.com/downloads/csmanual43.pdf)


[^2]: [Harmj0y DCSync Sept 2015](http://www.harmj0y.net/blog/redteaming/mimikatz-and-dcsync-and-extrasids-oh-my/)


[^3]: [AdSecurity Kerberos GT Aug 2015](https://adsecurity.org/?p=1640)


[^4]: [NCSC Joint Report Public Tools](https://www.ncsc.gov.uk/report/joint-report-on-publicly-available-hacking-tools)


[^5]: [GitHub Mimikatz lsadump Module](https://github.com/gentilkiwi/mimikatz/wiki/module-~-lsadump)


[^6]: [GitHub Mimikatz kerberos Module](https://github.com/gentilkiwi/mimikatz/wiki/module-~-kerberos)


[^7]: [Metcalf 2015](http://adsecurity.org/?p=1275)


[^8]: [Directory Services Internals DPAPI Backup Keys Oct 2015](https://www.dsinternals.com/en/retrieving-dpapi-backup-keys-from-active-directory/)


[^9]: [Delpy Mimikatz Crendential Manager](https://github.com/gentilkiwi/mimikatz/wiki/howto-~-credential-manager-saved-credentials)


[^10]: [Adsecurity Mimikatz Guide](https://adsecurity.org/?page_id=1821)


[^11]: [Deply Mimikatz](https://github.com/gentilkiwi/mimikatz)

