---
aliases: 
    - S0100
    
mitre-attack: https://attack.mitre.org/software/S0100
---

## S0100

[ipconfig](https://attack.mitre.org/software/S0100) is a Windows utility that can be used to find information about a system's TCP/IP, DNS, DHCP, and adapter configuration. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [ipconfig](https://attack.mitre.org/software/S0100) can be used to display adapter configuration on Windows systems, including information for TCP/IP, DNS, and DHCP. |




## References

[^1]: [TechNet Ipconfig](https://technet.microsoft.com/en-us/library/bb490921.aspx)

