---
aliases: 
    - S0190
    
mitre-attack: https://attack.mitre.org/software/S0190
---

## S0190

[BITSAdmin](https://attack.mitre.org/software/S0190) is a command line tool used to create and manage [BITS Jobs](https://attack.mitre.org/techniques/T1197). [^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1570-lateral_tool_transfer\|T1570]] | Lateral Tool Transfer | [BITSAdmin](https://attack.mitre.org/software/S0190) can be used to create [BITS Jobs](https://attack.mitre.org/techniques/T1197) to upload and/or download files from SMB file servers.[^1]  |
| [[T1048.003-exfiltration_over_unencrypted_non_c2_protocol\|T1048.003]] | Exfiltration Over Unencrypted Non-C2 Protocol | [BITSAdmin](https://attack.mitre.org/software/S0190) can be used to create [BITS Jobs](https://attack.mitre.org/techniques/T1197) to upload files from a compromised host.[^2]  |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [BITSAdmin](https://attack.mitre.org/software/S0190) can be used to create [BITS Jobs](https://attack.mitre.org/techniques/T1197) to upload and/or download files.[^2]  |
| [[T1197-bits_jobs\|T1197]] | BITS Jobs | [BITSAdmin](https://attack.mitre.org/software/S0190) can be used to create [BITS Jobs](https://attack.mitre.org/techniques/T1197) to launch a malicious process.[^3]  |




## References

[^1]: [Microsoft About BITS](https://docs.microsoft.com/en-us/windows/win32/bits/about-bits)


[^2]: [Microsoft BITSAdmin](https://msdn.microsoft.com/library/aa362813.aspx)


[^3]: [TrendMicro Tropic Trooper Mar 2018](https://blog.trendmicro.com/trendlabs-security-intelligence/tropic-trooper-new-strategy/)

