---
aliases: 
    - S0231
    
mitre-attack: https://attack.mitre.org/software/S0231
---

## S0231

[Invoke-PSImage](https://attack.mitre.org/software/S0231) takes a PowerShell script and embeds the bytes of the script into the pixels of a PNG image. It generates a one liner for executing either from a file of from the web. Example of usage is embedding the PowerShell code from the Invoke-Mimikatz module and embed it into an image file. By calling the image file from a macro for example, the macro will download the picture and execute the PowerShell code, which in this case will dump the passwords. [^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1027.003-steganography\|T1027.003]] | Steganography | [Invoke-PSImage](https://attack.mitre.org/software/S0231) can be used to embed a PowerShell script within the pixels of a PNG file.[^2]  |
| [[T1027.009-embedded_payloads\|T1027.009]] | Embedded Payloads | [Invoke-PSImage](https://attack.mitre.org/software/S0231) can be used to embed payload data within a new image file.[^1]  |




## References

[^1]: [GitHub PSImage](https://github.com/peewpw/Invoke-PSImage)


[^2]: [GitHub Invoke-PSImage](https://github.com/peewpw/Invoke-PSImage)

