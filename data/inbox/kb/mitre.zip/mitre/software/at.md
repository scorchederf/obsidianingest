---
aliases: 
    - S0110
    
mitre-attack: https://attack.mitre.org/software/S0110
---

## S0110

[at](https://attack.mitre.org/software/S0110) is used to schedule tasks on a system to run at a specified date or time.[^1] [^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1053.002-at\|T1053.002]] | At | [at](https://attack.mitre.org/software/S0110) can be used to schedule a task on a system to be executed at a specific date or time.[^1] [^2]  |




## References

[^1]: [TechNet At](https://technet.microsoft.com/en-us/library/bb490866.aspx)


[^2]: [Linux at](https://man7.org/linux/man-pages/man1/at.1p.html)

