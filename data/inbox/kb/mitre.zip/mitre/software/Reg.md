---
aliases: 
    - S0075
    
mitre-attack: https://attack.mitre.org/software/S0075
---

## S0075

[Reg](https://attack.mitre.org/software/S0075) is a Windows utility used to interact with the Windows Registry. It can be used at the command-line interface to query, add, modify, and remove information. [^2] <br><br>Utilities such as [Reg](https://attack.mitre.org/software/S0075) are known to be used by persistent threats. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1552.002-credentials_in_registry\|T1552.002]] | Credentials in Registry | [Reg](https://attack.mitre.org/software/S0075) may be used to find credentials in the Windows Registry.[^3]  |
| [[T1012-query_registry\|T1012]] | Query Registry | [Reg](https://attack.mitre.org/software/S0075) may be used to gather details from the Windows Registry of a local or remote system at the command-line interface.[^2]  |
| [[T1112-modify_registry\|T1112]] | Modify Registry | [Reg](https://attack.mitre.org/software/S0075) may be used to interact with and modify the Windows Registry of a local or remote system at the command-line interface.[^2]  |




## References

[^1]: [Windows Commands JPCERT](https://blogs.jpcert.or.jp/en/2016/01/windows-commands-abused-by-attackers.html)


[^2]: [Microsoft Reg](https://technet.microsoft.com/en-us/library/cc732643.aspx)


[^3]: [Pentestlab Stored Credentials](https://pentestlab.blog/2017/04/19/stored-credentials/)

