---
aliases: 
    - S0008
    
mitre-attack: https://attack.mitre.org/software/S0008
---

## S0008

[gsecdump](https://attack.mitre.org/software/S0008) is a publicly-available credential dumper used to obtain password hashes and LSA secrets from Windows operating systems. [^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1003.002-security_account_manager\|T1003.002]] | Security Account Manager | [gsecdump](https://attack.mitre.org/software/S0008) can dump Windows password hashes from the SAM.[^1]  |
| [[T1003.004-lsa_secrets\|T1003.004]] | LSA Secrets | [gsecdump](https://attack.mitre.org/software/S0008) can dump LSA secrets.[^2]  |




## References

[^1]: [Microsoft Gsecdump](https://www.microsoft.com/en-us/wdsi/threats/malware-encyclopedia-description?Name=HackTool:Win32/Gsecdump)


[^2]: [TrueSec Gsecdump](https://web.archive.org/web/20140328102838/https://www.truesec.se/sakerhet/verktyg/saakerhet/gsecdump_v2.0b5)

