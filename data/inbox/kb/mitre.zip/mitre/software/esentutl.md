---
aliases: 
    - S0404
    
mitre-attack: https://attack.mitre.org/software/S0404
---

## S0404

[esentutl](https://attack.mitre.org/software/S0404) is a command-line tool that provides database utilities for the Windows Extensible Storage Engine.[^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1006-direct_volume_access\|T1006]] | Direct Volume Access | [esentutl](https://attack.mitre.org/software/S0404) can use the Volume Shadow Copy service to copy locked files such as `ntds.dit`.[^4] [^3]  |
| [[T1570-lateral_tool_transfer\|T1570]] | Lateral Tool Transfer | [esentutl](https://attack.mitre.org/software/S0404) can be used to copy files to/from a remote share.[^4]  |
| [[T1003.003-ntds\|T1003.003]] | NTDS | [esentutl](https://attack.mitre.org/software/S0404) can copy `ntds.dit` using the Volume Shadow Copy service.[^4] [^3]  |
| [[T1564.004-ntfs_file_attributes\|T1564.004]] | NTFS File Attributes | [esentutl](https://attack.mitre.org/software/S0404) can be used to read and write alternate data streams.[^4]  |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [esentutl](https://attack.mitre.org/software/S0404) can be used to copy files from a given URL.[^4]  |
| [[T1005-data_from_local_system\|T1005]] | Data from Local System | [esentutl](https://attack.mitre.org/software/S0404) can be used to collect data from local file systems.[^2]  |




## References

[^1]: [Microsoft Esentutl](https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2012-R2-and-2012/hh875546(v=ws.11))


[^2]: [Red Canary 2021 Threat Detection Report March 2021](https://resource.redcanary.com/rs/003-YRU-314/images/2021-Threat-Detection-Report.pdf?mkt_tok=MDAzLVlSVS0zMTQAAAF_PIlmhNTaG2McG4X_foM-cIr20UfyB12MIQ10W0HbtMRwxGOJaD0Xj6CRTNg_S-8KniRxtf9xzhz_ACvm_TpbJAIgWCV8yIsFgbhb8cuaZA)


[^3]: [Cary Esentutl](https://dfironthemountain.wordpress.com/2018/12/06/locked-file-access-using-esentutl-exe/)


[^4]: [LOLBAS Esentutl](https://lolbas-project.github.io/lolbas/Binaries/Esentutl/)

