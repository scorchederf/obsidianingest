---
aliases: 
    - S0683
    
mitre-attack: https://attack.mitre.org/software/S0683
---

## S0683

[Peirates](https://attack.mitre.org/software/S0683) is a post-exploitation Kubernetes exploitation framework with a focus on gathering service account tokens for lateral movement and privilege escalation. The tool is written in GoLang and publicly available on GitHub.[^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1613-container_and_resource_discovery\|T1613]] | Container and Resource Discovery | [Peirates](https://attack.mitre.org/software/S0683) can enumerate Kubernetes pods in a given namespace.[^1]  |
| [[T1609-container_administration_command\|T1609]] | Container Administration Command | [Peirates](https://attack.mitre.org/software/S0683) can use `kubectl` or the Kubernetes API to run commands.[^1]  |
| [[T1611-escape_to_host\|T1611]] | Escape to Host | [Peirates](https://attack.mitre.org/software/S0683) can gain a reverse shell on a host node by mounting the Kubernetes hostPath.[^1]  |
| [[T1550.001-application_access_token\|T1550.001]] | Application Access Token | [Peirates](https://attack.mitre.org/software/S0683) can use stolen service account tokens to perform its operations. It also enables adversaries to switch between valid service accounts.[^1]  |
| [[T1530-data_from_cloud_storage\|T1530]] | Data from Cloud Storage | [Peirates](https://attack.mitre.org/software/S0683) can dump the contents of AWS S3 buckets. It can also retrieve service account tokens from kOps buckets in Google Cloud Storage or S3.[^1]  |
| [[T1046-network_service_discovery\|T1046]] | Network Service Discovery | [Peirates](https://attack.mitre.org/software/S0683) can initiate a port scan against a given IP address.[^1]  |
| [[T1610-deploy_container\|T1610]] | Deploy Container | [Peirates](https://attack.mitre.org/software/S0683) can deploy a pod that mounts its node’s root file system, then execute a command to create a reverse shell on the node.[^1]  |
| [[T1552.007-container_api\|T1552.007]] | Container API | [Peirates](https://attack.mitre.org/software/S0683) can query the Kubernetes API for secrets.[^1]  |
| [[T1619-cloud_storage_object_discovery\|T1619]] | Cloud Storage Object Discovery | [Peirates](https://attack.mitre.org/software/S0683) can list AWS S3 buckets.[^1]  |
| [[T1552.005-cloud_instance_metadata_api\|T1552.005]] | Cloud Instance Metadata API | [Peirates](https://attack.mitre.org/software/S0683) can query the query AWS and GCP metadata APIs for secrets.[^1]  |
| [[T1528-steal_application_access_token\|T1528]] | Steal Application Access Token | [Peirates](https://attack.mitre.org/software/S0683) gathers Kubernetes service account tokens using a variety of techniques.[^1]  |
| [[T1078.004-cloud_accounts\|T1078.004]] | Cloud Accounts | [Peirates](https://attack.mitre.org/software/S0683) can use stolen service account tokens to perform its operations.[^1]  |




## References

[^1]: [Peirates GitHub](https://github.com/inguardians/peirates)

