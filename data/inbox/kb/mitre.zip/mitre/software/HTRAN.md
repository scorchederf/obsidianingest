---
aliases: 
    - S0040
    
mitre-attack: https://attack.mitre.org/software/S0040
---

## S0040

[HTRAN](https://attack.mitre.org/software/S0040) is a tool that proxies connections through intermediate hops and aids users in disguising their true geographical location. It can be used by adversaries to hide their location when interacting with the victim networks. [^1] [^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1090-proxy\|T1090]] | Proxy | [HTRAN](https://attack.mitre.org/software/S0040) can proxy TCP socket connections to obfuscate command and control infrastructure.[^1] [^2]  |
| [[T1014-rootkit\|T1014]] | Rootkit | [HTRAN](https://attack.mitre.org/software/S0040) can install a rootkit to hide network connections from the host OS.[^2]  |
| [[T1055-process_injection\|T1055]] | Process Injection | [HTRAN](https://attack.mitre.org/software/S0040) can inject into into running processes.[^2]  |




## References

[^1]: [Operation Quantum Entanglement](https://web.archive.org/web/20210920193513/https://www.fireeye.com/content/dam/fireeye-www/global/en/current-threats/pdfs/wp-operation-quantum-entanglement.pdf)


[^2]: [NCSC Joint Report Public Tools](https://www.ncsc.gov.uk/report/joint-report-on-publicly-available-hacking-tools)


[^3]: HUC Packet Transmit Tool

