---
aliases: 
    - S0508
    
mitre-attack: https://attack.mitre.org/software/S0508
---

## S0508

[ngrok](https://attack.mitre.org/software/S0508) is a legitimate reverse proxy tool that can create a secure tunnel to servers located behind firewalls or on local machines that do not have a public IP. [ngrok](https://attack.mitre.org/software/S0508) has been leveraged by threat actors in several campaigns including use for lateral movement and data exfiltration.[^1] [^3] [^2] [^5] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1090-proxy\|T1090]] | Proxy | [ngrok](https://attack.mitre.org/software/S0508) can be used to proxy connections to machines located behind NAT or firewalls.[^4] [^1]  |
| [[T1567-exfiltration_over_web_service\|T1567]] | Exfiltration Over Web Service | [ngrok](https://attack.mitre.org/software/S0508) has been used by threat actors to configure servers for data exfiltration.[^4]  |
| [[T1568.002-domain_generation_algorithms\|T1568.002]] | Domain Generation Algorithms | [ngrok](https://attack.mitre.org/software/S0508) can provide DGA for C2 servers through the use of random URL strings that change every 12 hours.[^1]  |
| [[T1102-web_service\|T1102]] | Web Service | [ngrok](https://attack.mitre.org/software/S0508) has been used by threat actors to proxy C2 connections to ngrok service subdomains.[^1]  |
| [[T1572-protocol_tunneling\|T1572]] | Protocol Tunneling | [ngrok](https://attack.mitre.org/software/S0508) can tunnel RDP and other services securely over internet connections.[^3] [^2] [^4] [^6]  |




## References

[^1]: [Zdnet Ngrok September 2018](https://www.zdnet.com/article/sly-malware-author-hides-cryptomining-botnet-behind-ever-shifting-proxy-service/)


[^2]: [Cyware Ngrok May 2019](https://cyware.com/news/cyber-attackers-leverage-tunneling-service-to-drop-lokibot-onto-victims-systems-6f610e44)


[^3]: [FireEye Maze May 2020](https://www.fireeye.com/blog/threat-research/2020/05/tactics-techniques-procedures-associated-with-maze-ransomware-incidents.html)


[^4]: [MalwareBytes Ngrok February 2020](https://blog.malwarebytes.com/threat-analysis/2020/02/fraudsters-cloak-credit-card-skimmer-with-fake-content-delivery-network-ngrok-server/)


[^5]: [MalwareBytes LazyScripter Feb 2021](https://web.archive.org/web/20211003035156/https://www.malwarebytes.com/resources/files/2021/02/lazyscripter.pdf)


[^6]: [Trend Micro Ngrok September 2020](https://www.trendmicro.com/en_us/research/20/i/analysis-of-a-convoluted-attack-chain-involving-ngrok.html)

