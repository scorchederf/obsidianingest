---
aliases: 
    - S0677
    
mitre-attack: https://attack.mitre.org/software/S0677
---

## S0677

[AADInternals](https://attack.mitre.org/software/S0677) is a PowerShell-based framework for administering, enumerating, and exploiting Azure Active Directory. The tool is publicly available on GitHub.[^5] [^4] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1526-cloud_service_discovery\|T1526]] | Cloud Service Discovery | [AADInternals](https://attack.mitre.org/software/S0677) can enumerate information about a variety of cloud services, such as Office 365 and Sharepoint instances or OpenID Configurations.[^4]  |
| [[T1649-steal_or_forge_authentication_certificates\|T1649]] | Steal or Forge Authentication Certificates | [AADInternals](https://attack.mitre.org/software/S0677) can create and export various authentication certificates, including those associated with Azure AD joined/registered devices.[^4]  |
| [[T1556.007-hybrid_identity\|T1556.007]] | Hybrid Identity | [AADInternals](https://attack.mitre.org/software/S0677) can inject a malicious DLL (`PTASpy`) into the `AzureADConnectAuthenticationAgentService` to backdoor Azure AD Pass-Through Authentication.[^2]  |
| [[T1098.005-device_registration\|T1098.005]] | Device Registration | [AADInternals](https://attack.mitre.org/software/S0677) can register a device to Azure AD.[^4]  |
| [[T1598.003-spearphishing_link\|T1598.003]] | Spearphishing Link | [AADInternals](https://attack.mitre.org/software/S0677) can send phishing emails containing malicious links designed to collect users’ credentials.[^4]  |
| [[T1552.001-credentials_in_files\|T1552.001]] | Credentials In Files | [AADInternals](https://attack.mitre.org/software/S0677) can gather unsecured credentials for Azure AD services, such as Azure AD Connect, from a local machine.[^4]  |
| [[T1484.002-trust_modification\|T1484.002]] | Trust Modification | [AADInternals](https://attack.mitre.org/software/S0677) can create a backdoor by converting a domain to a federated domain which will be able to authenticate any user across the tenant. [AADInternals](https://attack.mitre.org/software/S0677) can also modify DesktopSSO information.[^4] [^3]  |
| [[T1566.002-spearphishing_link\|T1566.002]] | Spearphishing Link | [AADInternals](https://attack.mitre.org/software/S0677) can send "consent phishing" emails containing malicious links designed to steal users’ access tokens.[^4]  |
| [[T1069.003-cloud_groups\|T1069.003]] | Cloud Groups | [AADInternals](https://attack.mitre.org/software/S0677) can enumerate Azure AD groups.[^4]  |
| [[T1136.003-cloud_account\|T1136.003]] | Cloud Account | [AADInternals](https://attack.mitre.org/software/S0677) can create new Azure AD users.[^4]  |
| [[T1606.002-saml_tokens\|T1606.002]] | SAML Tokens | [AADInternals](https://attack.mitre.org/software/S0677) can be used to create SAML tokens using the AD Federated Services token signing certificate.[^4]  |
| [[T1590.001-domain_properties\|T1590.001]] | Domain Properties | [AADInternals](https://attack.mitre.org/software/S0677) can gather information about a tenant’s domains using public Microsoft APIs.[^4] [^1]  |
| [[T1589.002-email_addresses\|T1589.002]] | Email Addresses | [AADInternals](https://attack.mitre.org/software/S0677) can check for the existence of user email addresses using public Microsoft APIs.[^4] [^1]  |
| [[T1558.002-silver_ticket\|T1558.002]] | Silver Ticket | [AADInternals](https://attack.mitre.org/software/S0677) can be used to forge Kerberos tickets using the password hash of the AZUREADSSOACC account.[^4]  |
| [[T1552.004-private_keys\|T1552.004]] | Private Keys | [AADInternals](https://attack.mitre.org/software/S0677) can gather encryption keys from Azure AD services such as ADSync and Active Directory Federated Services servers.[^4]  |
| [[T1528-steal_application_access_token\|T1528]] | Steal Application Access Token | [AADInternals](https://attack.mitre.org/software/S0677) can steal users’ access tokens via phishing emails containing malicious links.[^4]  |
| [[T1087.004-cloud_account\|T1087.004]] | Cloud Account | [AADInternals](https://attack.mitre.org/software/S0677) can enumerate Azure AD users.[^4]  |
| [[T1003.004-lsa_secrets\|T1003.004]] | LSA Secrets | [AADInternals](https://attack.mitre.org/software/S0677) can dump secrets from the Local Security Authority.[^4]  |
| [[T1556.006-multi_factor_authentication\|T1556.006]] | Multi-Factor Authentication | The [AADInternals](https://attack.mitre.org/software/S0677) `Set-AADIntUserMFA` command can be used to disable MFA for a specified user. |
| [[T1651-cloud_administration_command\|T1651]] | Cloud Administration Command | [AADInternals](https://attack.mitre.org/software/S0677) can execute commands on Azure virtual machines using the VM agent.[^6]  |
| [[T1530-data_from_cloud_storage\|T1530]] | Data from Cloud Storage | AADInternals can collect files from a user’s OneDrive.[^7]  |
| [[T1059.001-powershell\|T1059.001]] | PowerShell | [AADInternals](https://attack.mitre.org/software/S0677) is written and executed via PowerShell.[^4]  |
| [[T1112-modify_registry\|T1112]] | Modify Registry | [AADInternals](https://attack.mitre.org/software/S0677) can modify registry keys as part of setting a new pass-through authentication agent.[^4]  |
| [[T1048-exfiltration_over_alternative_protocol\|T1048]] | Exfiltration Over Alternative Protocol | [AADInternals](https://attack.mitre.org/software/S0677) can directly download cloud user data such as OneDrive files.[^4]  |




## References

[^1]: [Azure AD Recon](https://o365blog.com/post/just-looking)


[^2]: [AADInternals Azure AD On-Prem to Cloud](https://o365blog.com/post/on-prem_admin/)


[^3]: [Azure AD Federation Vulnerability](https://o365blog.com/post/federation-vulnerability/)


[^4]: [AADInternals Documentation](https://o365blog.com/aadinternals)


[^5]: [AADInternals Github](https://github.com/Gerenios/AADInternals)


[^6]: [AADInternals Root Access to Azure VMs](https://aadinternals.com/post/azurevms/)


[^7]: [AADInternals](https://o365blog.com/aadinternals/)

