---
aliases: 
    - S0591
    
mitre-attack: https://attack.mitre.org/software/S0591
---

## S0591

[ConnectWise](https://attack.mitre.org/software/S0591) is a legitimate remote administration tool that has been used since at least 2016 by threat actors including [MuddyWater](https://attack.mitre.org/groups/G0069) and [GOLD SOUTHFIELD](https://attack.mitre.org/groups/G0115) to connect to and conduct lateral movement in target environments.[^2] [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1125-video_capture\|T1125]] | Video Capture | [ConnectWise](https://attack.mitre.org/software/S0591) can record video on remote hosts.[^2]  |
| [[T1059.001-powershell\|T1059.001]] | PowerShell | [ConnectWise](https://attack.mitre.org/software/S0591) can be used to execute PowerShell commands on target machines.[^2]  |
| [[T1113-screen_capture\|T1113]] | Screen Capture | [ConnectWise](https://attack.mitre.org/software/S0591) can take screenshots on remote hosts.[^2]  |




## References

[^1]: [Trend Micro Muddy Water March 2021](https://www.trendmicro.com/en_us/research/21/c/earth-vetala---muddywater-continues-to-target-organizations-in-t.html)


[^2]: [Anomali Static Kitten February 2021](https://www.anomali.com/blog/probable-iranian-cyber-actors-static-kitten-conducting-cyberespionage-campaign-targeting-uae-and-kuwait-government-agencies)


[^3]: ScreenConnect

