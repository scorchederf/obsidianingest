---
aliases: 
    - S0332
    
mitre-attack: https://attack.mitre.org/software/S0332
---

## S0332

[Remcos](https://attack.mitre.org/software/S0332) is a closed-source tool that is marketed as a remote control and surveillance software by a company called Breaking Security. [Remcos](https://attack.mitre.org/software/S0332) has been observed being used in malware campaigns.[^5] [^4] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1491.001-internal_defacement\|T1491.001]] | Internal Defacement | [Remcos](https://attack.mitre.org/software/S0332) has the ability to modify the desktop wallpaper.[^2]  |
| [[T1547.001-registry_run_keys_startup_folder\|T1547.001]] | Registry Run Keys ／ Startup Folder | [Remcos](https://attack.mitre.org/software/S0332) can add itself to the Registry key `HKCU\Software\Microsoft\Windows\CurrentVersion\Run` for persistence.[^3]  |
| [[T1082-system_information_discovery\|T1082]] | System Information Discovery | [Remcos](https://attack.mitre.org/software/S0332) can collect the OS version and process architecture of compromised hosts.[^2]  |
| [[T1115-clipboard_data\|T1115]] | Clipboard Data | [Remcos](https://attack.mitre.org/software/S0332) steals and modifies data from the clipboard.[^5] [^2]  |
| [[T1055-process_injection\|T1055]] | Process Injection | [Remcos](https://attack.mitre.org/software/S0332) has a command to hide itself by injecting into another process.[^3]  |
| [[T1566.001-spearphishing_attachment\|T1566.001]] | Spearphishing Attachment | [Remcos](https://attack.mitre.org/software/S0332) has been spread through emails containing malicious documents.[^2]  |
| [[T1059.006-python\|T1059.006]] | Python | [Remcos](https://attack.mitre.org/software/S0332) uses Python scripts.[^5]  |
| [[T1090-proxy\|T1090]] | Proxy | [Remcos](https://attack.mitre.org/software/S0332) uses the infected hosts as SOCKS5 proxies to allow for tunneling and proxying.[^5] [^2]  |
| [[T1112-modify_registry\|T1112]] | Modify Registry | [Remcos](https://attack.mitre.org/software/S0332) has full control of the Registry, including the ability to modify it.[^5] [^2]  |
| [[T1573.002-asymmetric_cryptography\|T1573.002]] | Asymmetric Cryptography | [Remcos](https://attack.mitre.org/software/S0332) can use TLS to encrypt C2 communication.[^2]  |
| [[T1027-obfuscated_files_or_information\|T1027]] | Obfuscated Files or Information | [Remcos](https://attack.mitre.org/software/S0332) uses RC4 and base64 to obfuscate data, including Registry entries and file paths.[^4]  [Remcos](https://attack.mitre.org/software/S0332) can also employ control flow flattening to hinder analysis.[^1]  |
| [[T1543.003-windows_service\|T1543.003]] | Windows Service | [Remcos](https://attack.mitre.org/software/S0332) can terminate, suspend, and resume a process by PID.[^2]  |
| [[T1497.001-system_checks\|T1497.001]] | System Checks | [Remcos](https://attack.mitre.org/software/S0332) searches for Sandboxie and VMware on the system.[^4]  |
| [[T1059.003-windows_command_shell\|T1059.003]] | Windows Command Shell | [Remcos](https://attack.mitre.org/software/S0332) can launch a remote command line to execute commands on the victim’s machine.[^3] [^2]  |
| [[T1027.013-encrypted_encoded_file\|T1027.013]] | Encrypted／Encoded File | [Remcos](https://attack.mitre.org/software/S0332) can use string encryption to hinder analysis.[^2]  |
| [[T1548.002-bypass_user_account_control\|T1548.002]] | Bypass User Account Control | [Remcos](https://attack.mitre.org/software/S0332) has a command for UAC bypassing.[^3]  |
| [[T1113-screen_capture\|T1113]] | Screen Capture | [Remcos](https://attack.mitre.org/software/S0332) takes automated screenshots of the infected machine.[^5] [^2]  |
| [[T1560.001-archive_via_utility\|T1560.001]] | Archive via Utility | [Remcos](https://attack.mitre.org/software/S0332) can zip files and folders for upload.[^2]  |
| [[T1070-indicator_removal\|T1070]] | Indicator Removal | [Remcos](https://attack.mitre.org/software/S0332) can clean saved cookies and logins from the web browser.[^2]  |
| [[T1564.003-hidden_window\|T1564.003]] | Hidden Window | [Remcos](https://attack.mitre.org/software/S0332) can set `ProcessWindowStyle.Hidden` to hide windows.[^1] <br> |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [Remcos](https://attack.mitre.org/software/S0332) can upload and download files to and from the victim’s machine.[^5] [^2]  |
| [[T1059.005-visual_basic\|T1059.005]] | Visual Basic | [Remcos](https://attack.mitre.org/software/S0332) can execute VBS remotely.[^2]  |
| [[T1204.002-malicious_file\|T1204.002]] | Malicious File | [Remcos](https://attack.mitre.org/software/S0332) has been executed by luring victims into opening malicious email attachments including Excel files.[^2] <br> |
| [[T1568-dynamic_resolution\|T1568]] | Dynamic Resolution | [Remcos](https://attack.mitre.org/software/S0332) has used dynamic DNS domains in C2 communications.[^1]  |
| [[T1056.001-keylogging\|T1056.001]] | Keylogging | [Remcos](https://attack.mitre.org/software/S0332) has a command for keylogging.[^3] [^4]  |
| [[T1125-video_capture\|T1125]] | Video Capture | [Remcos](https://attack.mitre.org/software/S0332) can access a system’s webcam and take pictures.[^3]  |
| [[T1012-query_registry\|T1012]] | Query Registry | [Remcos](https://attack.mitre.org/software/S0332) can obtain Registry data from targeted systems.[^2]  |
| [[T1564-hide_artifacts\|T1564]] | Hide Artifacts | [Remcos](https://attack.mitre.org/software/S0332) can modify file attributes to hide the file.[^2]  |
| [[T1083-file_and_directory_discovery\|T1083]] | File and Directory Discovery | [Remcos](https://attack.mitre.org/software/S0332) can search for files on the infected machine.[^5] [^2]  |
| [[T1123-audio_capture\|T1123]] | Audio Capture | [Remcos](https://attack.mitre.org/software/S0332) can capture data from the system’s microphone.[^3] [^2]  |
| [[T1070.004-file_deletion\|T1070.004]] | File Deletion | [Remcos](https://attack.mitre.org/software/S0332) can delete files and folders from victim machines.[^2]  |
| [[T1057-process_discovery\|T1057]] | Process Discovery | [Remcos](https://attack.mitre.org/software/S0332) can discover running processes on compromised machines.[^2] <br> |
| [[T1614-system_location_discovery\|T1614]] | System Location Discovery | [Remcos](https://attack.mitre.org/software/S0332) can identify the location of targeted devices.[^2]  |
| [[T1010-application_window_discovery\|T1010]] | Application Window Discovery | [Remcos](https://attack.mitre.org/software/S0332) can list all windows on victim systems.[^2]  |
| [[T1529-system_shutdown_reboot\|T1529]] | System Shutdown／Reboot | [Remcos](https://attack.mitre.org/software/S0332) can shutdown and restart remote devices.[^2]  |
| [[T1033-system_owner_user_discovery\|T1033]] | System Owner／User Discovery | [Remcos](https://attack.mitre.org/software/S0332) can enumerate the username on targeted hosts.[^2]  |
| [[T1059.007-javascript\|T1059.007]] | JavaScript | [Remcos](https://attack.mitre.org/software/S0332) has the ability to execute JavaScript remotely.[^2]  |
| [[T1132.001-standard_encoding\|T1132.001]] | Standard Encoding | [Remcos](https://attack.mitre.org/software/S0332) can serialize collected data with Protobuf.[^1]  |




## References

[^1]: [Check Point Blind Eagle MAR 2025](https://research.checkpoint.com/2025/blind-eagle-and-justice-for-all/)


[^2]: [Fortinet Remcos Campaign NOV 2024](https://www.fortinet.com/blog/threat-research/new-campaign-uses-remcos-rat-to-exploit-victims)


[^3]: [Fortinet Remcos Feb 2017](https://www.fortinet.com/blog/threat-research/remcos-a-new-rat-in-the-wild-2.html)


[^4]: [Talos Remcos Aug 2018](https://blog.talosintelligence.com/2018/08/picking-apart-remcos.html)


[^5]: [Riskiq Remcos Jan 2018](https://web.archive.org/web/20180124082756/https://www.riskiq.com/blog/labs/spear-phishing-turkish-defense-contractors/)


[^6]: Remcos

