---
aliases: 
    - S0006
    
mitre-attack: https://attack.mitre.org/software/S0006
---

## S0006

[pwdump](https://attack.mitre.org/software/S0006) is a credential dumper. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1003.002-security_account_manager\|T1003.002]] | Security Account Manager | [pwdump](https://attack.mitre.org/software/S0006) can be used to dump credentials from the SAM.[^1]  |




## References

[^1]: [Wikipedia pwdump](https://en.wikipedia.org/wiki/Pwdump)

