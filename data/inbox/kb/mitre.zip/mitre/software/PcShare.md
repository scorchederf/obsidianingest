---
aliases: 
    - S1050
    
mitre-attack: https://attack.mitre.org/software/S1050
---

## S1050

[PcShare](https://attack.mitre.org/software/S1050) is an open source remote access tool that has been modified and used by Chinese threat actors, most notably during the FunnyDream campaign since late 2018.[^1] [^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1036.005-match_legitimate_resource_name_or_location\|T1036.005]] | Match Legitimate Resource Name or Location | [PcShare](https://attack.mitre.org/software/S1050) has been named `wuauclt.exe` to appear as the legitimate Windows Update AutoUpdate Client.[^1]  |
| [[T1071.001-web_protocols\|T1071.001]] | Web Protocols | [PcShare](https://attack.mitre.org/software/S1050) has used HTTP for C2 communication.[^1]  |
| [[T1057-process_discovery\|T1057]] | Process Discovery | [PcShare](https://attack.mitre.org/software/S1050) can obtain a list of running processes on a compromised host.[^1]  |
| [[T1113-screen_capture\|T1113]] | Screen Capture | [PcShare](https://attack.mitre.org/software/S1050) can take screen shots of a compromised machine.[^1]  |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [PcShare](https://attack.mitre.org/software/S1050) can obtain the proxy settings of a compromised machine using `InternetQueryOptionA` and its IP address by running `nslookup myip.opendns.comresolver1.opendns.com\r\n`.[^1]  |
| [[T1027.015-compression\|T1027.015]] | Compression | [PcShare](https://attack.mitre.org/software/S1050) has been compressed with LZW algorithm.[^1]  |
| [[T1059.003-windows_command_shell\|T1059.003]] | Windows Command Shell | [PcShare](https://attack.mitre.org/software/S1050) can execute `cmd` commands on a compromised host.[^1]  |
| [[T1027.013-encrypted_encoded_file\|T1027.013]] | Encrypted／Encoded File | [PcShare](https://attack.mitre.org/software/S1050) has been encrypted with XOR using different 32-long Base16 strings.[^1]  |
| [[T1546.015-component_object_model_hijacking\|T1546.015]] | Component Object Model Hijacking | [PcShare](https://attack.mitre.org/software/S1050) has created the `HKCU\\Software\\Classes\\CLSID\\{42aedc87-2188-41fd-b9a3-0c966feabec1}\\InprocServer32` Registry key for persistence.[^1]  |
| [[T1056.001-keylogging\|T1056.001]] | Keylogging | [PcShare](https://attack.mitre.org/software/S1050) has the ability to capture keystrokes.[^1]  |
| [[T1005-data_from_local_system\|T1005]] | Data from Local System | [PcShare](https://attack.mitre.org/software/S1050) can collect files and information from a compromised host.[^1]  |
| [[T1218.011-rundll32\|T1218.011]] | Rundll32 | [PcShare](https://attack.mitre.org/software/S1050) has used `rundll32.exe` for execution.[^1]  |
| [[T1140-deobfuscate_decode_files_or_information\|T1140]] | Deobfuscate／Decode Files or Information | [PcShare](https://attack.mitre.org/software/S1050) has decrypted its strings by applying a XOR operation and a decompression using a custom implemented LZM algorithm.[^1]  |
| [[T1012-query_registry\|T1012]] | Query Registry | [PcShare](https://attack.mitre.org/software/S1050) can search the registry files of a compromised host.[^1]  |
| [[T1070.004-file_deletion\|T1070.004]] | File Deletion | [PcShare](https://attack.mitre.org/software/S1050) has deleted its files and components from a compromised host.[^1]  |
| [[T1041-exfiltration_over_c2_channel\|T1041]] | Exfiltration Over C2 Channel | [PcShare](https://attack.mitre.org/software/S1050) can upload files and information from a compromised host to its C2 servers.[^1]  |
| [[T1036.001-invalid_code_signature\|T1036.001]] | Invalid Code Signature | [PcShare](https://attack.mitre.org/software/S1050) has used an invalid certificate in attempt to appear legitimate.[^1]  |
| [[T1112-modify_registry\|T1112]] | Modify Registry | [PcShare](https://attack.mitre.org/software/S1050) can delete its persistence mechanisms from the registry.[^1]  |
| [[T1106-native_api\|T1106]] | Native API | [PcShare](https://attack.mitre.org/software/S1050) has used a variety of Windows API functions.[^1]  |
| [[T1055-process_injection\|T1055]] | Process Injection | The [PcShare](https://attack.mitre.org/software/S1050) payload has been injected into the `logagent.exe` and `rdpclip.exe` processes.[^1]  |
| [[T1125-video_capture\|T1125]] | Video Capture | [PcShare](https://attack.mitre.org/software/S1050) can capture camera video as part of its collection process.[^1]  |




## References

[^1]: [Bitdefender FunnyDream Campaign November 2020](https://www.bitdefender.com/files/News/CaseStudies/study/379/Bitdefender-Whitepaper-Chinese-APT.pdf)


[^2]: [GitHub PcShare 2014](https://github.com/LiveMirror/pcshare)

