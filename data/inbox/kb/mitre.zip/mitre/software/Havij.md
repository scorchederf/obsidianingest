---
aliases: 
    - S0224
    
mitre-attack: https://attack.mitre.org/software/S0224
---

## S0224

[Havij](https://attack.mitre.org/software/S0224) is an automatic SQL Injection tool distributed by the Iranian ITSecTeam security company. Havij has been used by penetration testers and adversaries. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1190-exploit_public_facing_application\|T1190]] | Exploit Public-Facing Application | [Havij](https://attack.mitre.org/software/S0224) is used to automate SQL injection.[^1]  |




## References

[^1]: [Check Point Havij Analysis](https://blog.checkpoint.com/2015/05/14/analysis-havij-sql-injection-tool/)

