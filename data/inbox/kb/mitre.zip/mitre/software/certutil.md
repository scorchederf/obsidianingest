---
aliases: 
    - S0160
    
mitre-attack: https://attack.mitre.org/software/S0160
---

## S0160

[certutil](https://attack.mitre.org/software/S0160) is a command-line utility that can be used to obtain certificate authority information and configure Certificate Services. [^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1560.001-archive_via_utility\|T1560.001]] | Archive via Utility | [certutil](https://attack.mitre.org/software/S0160) may be used to Base64 encode collected data.[^2] [^3]  |
| [[T1553.004-install_root_certificate\|T1553.004]] | Install Root Certificate | [certutil](https://attack.mitre.org/software/S0160) can be used to install browser root certificates as a precursor to performing [Adversary-in-the-Middle](https://attack.mitre.org/techniques/T1557) between connections to banking websites. Example command: `certutil -addstore -f -user ROOT ProgramData\cert512121.der`.[^1]  |
| [[T1140-deobfuscate_decode_files_or_information\|T1140]] | Deobfuscate／Decode Files or Information | [certutil](https://attack.mitre.org/software/S0160) has been used to decode binaries hidden inside certificate files as Base64 information.[^4]  |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [certutil](https://attack.mitre.org/software/S0160) can be used to download files from a given URL.[^2] [^3]  |




## References

[^1]: [Palo Alto Retefe](https://researchcenter.paloaltonetworks.com/2015/08/retefe-banking-trojan-targets-sweden-switzerland-and-japan/)


[^2]: [TechNet Certutil](https://technet.microsoft.com/library/cc732443.aspx)


[^3]: [LOLBAS Certutil](https://lolbas-project.github.io/lolbas/Binaries/Certutil/)


[^4]: [Malwarebytes Targeted Attack against Saudi Arabia](https://blog.malwarebytes.com/cybercrime/social-engineering-cybercrime/2017/03/new-targeted-attack-saudi-arabia-government/)

