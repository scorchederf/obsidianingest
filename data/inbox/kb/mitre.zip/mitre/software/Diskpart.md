---
aliases: 
    - S9002
    
mitre-attack: https://attack.mitre.org/software/S9002
---

## S9002

[Diskpart](https://attack.mitre.org/software/S9002) is a Windows command-line utility that is used to manage the computer’s drives, which includes disks, partitions, volumes and virtual hard disks.[^2]   <br><br>Adversaries may abuse [Diskpart](https://attack.mitre.org/software/S9002) to perform discovery and destructive actions on a system’s storage. For example, adversaries have been observed using [Diskpart](https://attack.mitre.org/software/S9002) to conduct [Discovery](https://attack.mitre.org/tactics/TA0007) techniques to enumerate disks and volumes to gather information about the host environment, and to execute commands such as `clean all` to remove partition information and overwrite data across disks, resulting in data destruction.[^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1561.002-disk_structure_wipe\|T1561.002]] | Disk Structure Wipe | [Diskpart](https://attack.mitre.org/software/S9002) can be used to delete a partition or a volume.[^2]  [Diskpart](https://attack.mitre.org/software/S9002) can also be used to remove all partitions or volume formatting from the selected disk.[^1]     |
| [[T1222.001-windows_permissions\|T1222.001]] | Windows Permissions | [Diskpart](https://attack.mitre.org/software/S9002) can be used to display, set, or clear attributes of a disk or volume.[^2]    |
| [[T1082-system_information_discovery\|T1082]] | System Information Discovery | [Diskpart](https://attack.mitre.org/software/S9002) can show information about the selected disk, partition, volume, or virtual hard disk (VHD).[^2]   |
| [[T1059.003-windows_command_shell\|T1059.003]] | Windows Command Shell | [Diskpart](https://attack.mitre.org/software/S9002) can execute a disk partition script file, which attempts to mount a virtual hard disk.[^3]  [Diskpart](https://attack.mitre.org/software/S9002) can also assign and mount virtual disks.[^3]     |
| [[T1083-file_and_directory_discovery\|T1083]] | File and Directory Discovery | If executed with elevated privileges, [Diskpart](https://attack.mitre.org/software/S9002) can list all volumes, including virtual disks.[^3]     |




## References

[^1]: [Trendmicro_RansomHub_Dec2024](https://www.trendmicro.com/vinfo/us/security/news/ransomware-spotlight/ransomware-spotlight-ransomhub)


[^2]: [Microsoft_diskpart_Feb2023](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/diskpart)


[^3]: [Halcyon_CloakRansomware_Dec2024](https://www.halcyon.ai/blog/cloak-ransomware-variant-exhibits-advanced-persistence-evasion-and-vhd-extraction-capabilities)

