---
aliases: 
    - S0692
    
mitre-attack: https://attack.mitre.org/software/S0692
---

## S0692

[SILENTTRINITY](https://attack.mitre.org/software/S0692) is an open source remote administration and post-exploitation framework primarily written in Python that includes stagers written in Powershell, C, and Boo. [SILENTTRINITY](https://attack.mitre.org/software/S0692) was used in a 2019 campaign against Croatian government agencies by unidentified cyber actors.[^3] [^4] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1552.006-group_policy_preferences\|T1552.006]] | Group Policy Preferences | [SILENTTRINITY](https://attack.mitre.org/software/S0692) has a module that can extract cached GPP passwords.[^1]   |
| [[T1620-reflective_code_loading\|T1620]] | Reflective Code Loading | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can run a .NET executable within the memory of a sacrificial process by loading the CLR.[^2]    |
| [[T1069.002-domain_groups\|T1069.002]] | Domain Groups | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can use `System.DirectoryServices` namespace to retrieve domain group information.[^1]  |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can load additional files and tools, including [Mimikatz](https://attack.mitre.org/software/S0002).[^1]  |
| [[T1546.001-change_default_file_association\|T1546.001]] | Change Default File Association | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can conduct an image hijack of an `.msc` file extension as part of its UAC bypass process.[^1]  |
| [[T1115-clipboard_data\|T1115]] | Clipboard Data | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can monitor Clipboard text and can use `System.Windows.Forms.Clipboard.GetText()` to collect data from the clipboard.[^2]    |
| [[T1070-indicator_removal\|T1070]] | Indicator Removal | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can remove artifacts from the compromised host, including created Registry keys.[^1]  |
| [[T1003.001-lsass_memory\|T1003.001]] | LSASS Memory | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can create a memory dump of LSASS via the `MiniDumpWriteDump Win32` API call.[^1]  |
| [[T1135-network_share_discovery\|T1135]] | Network Share Discovery | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can enumerate shares on a compromised host.[^1]  |
| [[T1564.003-hidden_window\|T1564.003]] | Hidden Window | [SILENTTRINITY](https://attack.mitre.org/software/S0692) has the ability to set its window state to hidden.[^1]  |
| [[T1543.003-windows_service\|T1543.003]] | Windows Service | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can establish persistence by creating a new service.[^1]  |
| [[T1069.001-local_groups\|T1069.001]] | Local Groups | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can obtain a list of local groups and members.[^1]  |
| [[T1685-disable_or_modify_tools\|T1685]] | Disable or Modify Tools | [SILENTTRINITY](https://attack.mitre.org/software/S0692)'s `amsiPatch.py` module can disable Antimalware Scan Interface (AMSI) functions.[^1]  |
| [[T1113-screen_capture\|T1113]] | Screen Capture | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can take a screenshot of the current desktop.[^1]  |
| [[T1047-windows_management_instrumentation\|T1047]] | Windows Management Instrumentation | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can use WMI for lateral movement.[^1]  |
| [[T1055-process_injection\|T1055]] | Process Injection | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can inject shellcode directly into Excel.exe or a specific process.[^1]  |
| [[T1112-modify_registry\|T1112]] | Modify Registry | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can modify registry keys, including to enable or disable Remote Desktop Protocol (RDP).[^1]  |
| [[T1124-system_time_discovery\|T1124]] | System Time Discovery | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can collect start time information from a compromised host.[^1]  |
| [[T1546.003-windows_management_instrumentation_event_subscription\|T1546.003]] | Windows Management Instrumentation Event Subscription | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can create a WMI Event to execute a payload for persistence.[^1]  |
| [[T1134.001-token_impersonation_theft\|T1134.001]] | Token Impersonation／Theft | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can find a process owned by a specific user and impersonate the associated token.[^1]  |
| [[T1556-modify_authentication_process\|T1556]] | Modify Authentication Process | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can create a backdoor in KeePass using a malicious config file and in TortoiseSVN using a registry hook.[^1]  |
| [[T1012-query_registry\|T1012]] | Query Registry | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can use the `GetRegValue` function to check Registry keys within `HKCU\Software\Policies\Microsoft\Windows\Installer\AlwaysInstallElevated` and `HKLM\Software\Policies\Microsoft\Windows\Installer\AlwaysInstallElevated`. It also contains additional modules that can check software AutoRun values and use the Win32 namespace to get values from HKCU, HKLM, HKCR, and HKCC hives.[^1]  |
| [[T1689-downgrade_attack\|T1689]] | Downgrade Attack | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can downgrade NTLM to capture NTLM hashes.[^2]   |
| [[T1087.002-domain_account\|T1087.002]] | Domain Account | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can use `System.Security.AccessControl` namespaces to retrieve domain user information.[^1]    |
| [[T1018-remote_system_discovery\|T1018]] | Remote System Discovery | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can enumerate and collect the properties of domain computers.[^1]  |
| [[T1690-prevent_command_history_logging\|T1690]] | Prevent Command History Logging | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can bypass ScriptBlock logging to execute unmanaged PowerShell code from memory.[^1]  |
| [[T1070.004-file_deletion\|T1070.004]] | File Deletion | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can remove files from the compromised host.[^1]  |
| [[T1134.003-make_and_impersonate_token\|T1134.003]] | Make and Impersonate Token | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can make tokens from known credentials.[^2]   |
| [[T1059.006-python\|T1059.006]] | Python | [SILENTTRINITY](https://attack.mitre.org/software/S0692) is written in Python and can use multiple Python scripts for execution on targeted systems.[^3] [^1]  |
| [[T1046-network_service_discovery\|T1046]] | Network Service Discovery | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can scan for open ports on a compromised machine.[^1]  |
| [[T1059.001-powershell\|T1059.001]] | PowerShell | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can use PowerShell to execute commands.[^1]  |
| [[T1555.003-credentials_from_web_browsers\|T1555.003]] | Credentials from Web Browsers | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can collect clear text web credentials for Internet Explorer/Edge.[^1]  |
| [[T1106-native_api\|T1106]] | Native API | [SILENTTRINITY](https://attack.mitre.org/software/S0692) has the ability to leverage API including `GetProcAddress` and `LoadLibrary`.[^1]  |
| [[T1558.003-kerberoasting\|T1558.003]] | Kerberoasting | [SILENTTRINITY](https://attack.mitre.org/software/S0692) contains a module to conduct Kerberoasting.[^1]  |
| [[T1546.015-component_object_model_hijacking\|T1546.015]] | Component Object Model Hijacking | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can add a CLSID key for payload execution through `Registry.CurrentUser.CreateSubKey("Software\\Classes\\CLSID\\{" + clsid + "}\\InProcServer32")`.[^1]  |
| [[T1041-exfiltration_over_c2_channel\|T1041]] | Exfiltration Over C2 Channel | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can transfer files from an infected host to the C2 server.[^1]  |
| [[T1555.004-windows_credential_manager\|T1555.004]] | Windows Credential Manager | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can gather Windows Vault credentials.[^1]   |
| [[T1021.003-distributed_component_object_model\|T1021.003]] | Distributed Component Object Model | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can use `System` namespace methods to execute lateral movement using DCOM.[^1]  |
| [[T1083-file_and_directory_discovery\|T1083]] | File and Directory Discovery | [SILENTTRINITY](https://attack.mitre.org/software/S0692) has several modules, such as `ls.py`, `pwd.py`, and `recentFiles.py`, to enumerate directories and files.[^1]   |
| [[T1680-local_storage_discovery\|T1680]] | Local Storage Discovery | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can collect information related to a compromised host, including a list of drives.[^1]  |
| [[T1548.002-bypass_user_account_control\|T1548.002]] | Bypass User Account Control | [SILENTTRINITY](https://attack.mitre.org/software/S0692) contains a number of modules that can bypass UAC, including through Window's Device Manager, Manage Optional Features, and an image hijack on the `.msc` file extension.[^1]     |
| [[T1559.001-component_object_model\|T1559.001]] | Component Object Model | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can insert malicious shellcode into Excel.exe using a `Microsoft.Office.Interop` object.[^2]   |
| [[T1059.003-windows_command_shell\|T1059.003]] | Windows Command Shell | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can use `cmd.exe` to enable lateral movement using DCOM.[^1]  |
| [[T1010-application_window_discovery\|T1010]] | Application Window Discovery | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can enumerate the active Window during keylogging through execution of `GetActiveWindowTitle`.[^1]  |
| [[T1021.006-windows_remote_management\|T1021.006]] | Windows Remote Management | [SILENTTRINITY](https://attack.mitre.org/software/S0692) tracks `TrustedHosts` and can move laterally to these targets via WinRM.[^1]  |
| [[T1547.001-registry_run_keys_startup_folder\|T1547.001]] | Registry Run Keys ／ Startup Folder | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can establish a LNK file in the startup folder for persistence.[^1]  |
| [[T1057-process_discovery\|T1057]] | Process Discovery | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can enumerate processes, including properties to determine if they have the Common Language Runtime (CLR) loaded.[^1]  |
| [[T1056.002-gui_input_capture\|T1056.002]] | GUI Input Capture | [SILENTTRINITY](https://attack.mitre.org/software/S0692)'s `credphisher.py` module can prompt a current user for their credentials.[^1]  |
| [[T1056.001-keylogging\|T1056.001]] | Keylogging | [SILENTTRINITY](https://attack.mitre.org/software/S0692) has a keylogging capability.[^1]  |
| [[T1033-system_owner_user_discovery\|T1033]] | System Owner／User Discovery | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can gather a list of logged on users.[^1]   |
| [[T1518.001-security_software_discovery\|T1518.001]] | Security Software Discovery | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can determine if an anti-virus product is installed through the resolution of the service's virtual SID.[^4]  |
| [[T1082-system_information_discovery\|T1082]] | System Information Discovery | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can collect information related to a compromised host, including OS version.[^1]  |
| [[T1007-system_service_discovery\|T1007]] | System Service Discovery | [SILENTTRINITY](https://attack.mitre.org/software/S0692) can search for modifiable services that could be used for privilege escalation.[^1]  |




## References

[^1]: [GitHub SILENTTRINITY Modules July 2019](https://github.com/byt3bl33d3r/SILENTTRINITY/tree/master/silenttrinity/core/teamserver/modules/boo)


[^2]: [Github_SILENTTRINITY](https://github.com/byt3bl33d3r/SILENTTRINITY)


[^3]: [GitHub SILENTTRINITY March 2022](https://github.com/byt3bl33d3r/SILENTTRINITY)


[^4]: [Security Affairs SILENTTRINITY July 2019](https://securityaffairs.co/wordpress/88021/apt/croatia-government-silenttrinity-malware.html)


[^5]: SILENTTRINITY

