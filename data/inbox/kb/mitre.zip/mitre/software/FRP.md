---
aliases: 
    - S1144
    
mitre-attack: https://attack.mitre.org/software/S1144
---

## S1144

[FRP](https://attack.mitre.org/software/S1144), which stands for Fast Reverse Proxy, is an openly available tool that is capable of exposing a server located behind a firewall or Network Address Translation (NAT) to the Internet. [FRP](https://attack.mitre.org/software/S1144) can support multiple protocols including TCP, UDP, and HTTP(S) and has been abused by threat actors to proxy command and control communications.[^3] [^2] [^4] [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1095-non_application_layer_protocol\|T1095]] | Non-Application Layer Protocol | [FRP](https://attack.mitre.org/software/S1144) can communicate over TCP, TCP stream multiplexing, KERN Communications Protocol (KCP), QUIC, and UDP.[^3]  |
| [[T1059.007-javascript\|T1059.007]] | JavaScript | [FRP](https://attack.mitre.org/software/S1144) can support the use of a JSON configuration file.[^3]  |
| [[T1090-proxy\|T1090]] | Proxy | [FRP](https://attack.mitre.org/software/S1144) can proxy communications through a server in public IP space to local servers located behind a NAT or firewall.[^3]  |
| [[T1572-protocol_tunneling\|T1572]] | Protocol Tunneling | [FRP](https://attack.mitre.org/software/S1144) can tunnel SSH and Unix Domain Socket communications over TCP between external nodes and exposed resources behind firewalls or NAT.[^3]  |
| [[T1573.002-asymmetric_cryptography\|T1573.002]] | Asymmetric Cryptography | [FRP](https://attack.mitre.org/software/S1144) can be configured to only accept TLS connections.[^3]  |
| [[T1046-network_service_discovery\|T1046]] | Network Service Discovery | As part of load balancing [FRP](https://attack.mitre.org/software/S1144) can set `healthCheck.type = "tcp"` or `healthCheck.type = "http"` to check service status on specific hosts with TCPing or an HTTP request.[^3]  |
| [[T1049-system_network_connections_discovery\|T1049]] | System Network Connections Discovery | [FRP](https://attack.mitre.org/software/S1144) can use a dashboard and U/I to display the status of connections from the FRP client and server.[^3]  |
| [[T1090.003-multi_hop_proxy\|T1090.003]] | Multi-hop Proxy | The [FRP](https://attack.mitre.org/software/S1144) client can be configured to connect to the server through a proxy.[^3]  |
| [[T1573.001-symmetric_cryptography\|T1573.001]] | Symmetric Cryptography | [FRP](https://attack.mitre.org/software/S1144) can use STCP (Secret TCP) with a preshared key to encrypt services exposed to public networks.[^3]  |
| [[T1071.001-web_protocols\|T1071.001]] | Web Protocols | [FRP](https://attack.mitre.org/software/S1144) has the ability to use HTTP and HTTPS to enable the forwarding of requests for internal services via domain name.[^3]  |




## References

[^1]: [DFIR Phosphorus November 2021](https://thedfirreport.com/2021/11/15/exchange-exploit-leads-to-domain-wide-ransomware/)


[^2]: [Joint Cybersecurity Advisory Volt Typhoon June 2023](https://media.defense.gov/2023/May/24/2003229517/-1/-1/0/CSA_Living_off_the_Land.PDF)


[^3]: [FRP GitHub](https://github.com/fatedier/frp)


[^4]: [RedCanary Mockingbird May 2020](https://redcanary.com/blog/blue-mockingbird-cryptominer/)

