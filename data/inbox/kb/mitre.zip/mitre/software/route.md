---
aliases: 
    - S0103
    
mitre-attack: https://attack.mitre.org/software/S0103
---

## S0103

[route](https://attack.mitre.org/software/S0103) can be used to find or change information within the local system IP routing table. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [route](https://attack.mitre.org/software/S0103) can be used to discover routing configuration information. |




## References

[^1]: [TechNet Route](https://technet.microsoft.com/en-us/library/bb490991.aspx)

