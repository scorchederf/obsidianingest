---
aliases: 
    - S0119
    
mitre-attack: https://attack.mitre.org/software/S0119
---

## S0119

[Cachedump](https://attack.mitre.org/software/S0119) is a publicly-available tool that program extracts cached password hashes from a system’s registry. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1003.005-cached_domain_credentials\|T1003.005]] | Cached Domain Credentials | [Cachedump](https://attack.mitre.org/software/S0119) can extract cached password hashes from cache entry information.[^1]  |




## References

[^1]: [Mandiant APT1](https://www.fireeye.com/content/dam/fireeye-www/services/pdfs/mandiant-apt1-report.pdf)

