---
aliases: 
    - S0592
    
mitre-attack: https://attack.mitre.org/software/S0592
---

## S0592

[RemoteUtilities](https://attack.mitre.org/software/S0592) is a legitimate remote administration tool that has been used by [MuddyWater](https://attack.mitre.org/groups/G0069) since at least 2021 for execution on target machines.[^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1083-file_and_directory_discovery\|T1083]] | File and Directory Discovery | [RemoteUtilities](https://attack.mitre.org/software/S0592) can enumerate files and directories on a target machine.[^1]  |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [RemoteUtilities](https://attack.mitre.org/software/S0592) can upload and download files to and from a target machine.[^1]  |
| [[T1218.007-msiexec\|T1218.007]] | Msiexec | [RemoteUtilities](https://attack.mitre.org/software/S0592) can use Msiexec to install a service.[^1]  |
| [[T1113-screen_capture\|T1113]] | Screen Capture | [RemoteUtilities](https://attack.mitre.org/software/S0592) can take screenshots on a compromised host.[^1]  |




## References

[^1]: [Trend Micro Muddy Water March 2021](https://www.trendmicro.com/en_us/research/21/c/earth-vetala---muddywater-continues-to-target-organizations-in-t.html)

