---
aliases: 
    - S0108
    
mitre-attack: https://attack.mitre.org/software/S0108
---

## S0108

[netsh](https://attack.mitre.org/software/S0108) is a scripting utility used to interact with networking components on local or remote systems. [^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1686-disable_or_modify_system_firewall\|T1686]] | Disable or Modify System Firewall | [netsh](https://attack.mitre.org/software/S0108) can be used to disable local firewall settings.[^2] [^1]  |
| [[T1546.007-netsh_helper_dll\|T1546.007]] | Netsh Helper DLL | [netsh](https://attack.mitre.org/software/S0108) can be used as a persistence proxy technique to execute a helper DLL when netsh.exe is executed.[^3]  |
| [[T1090-proxy\|T1090]] | Proxy | [netsh](https://attack.mitre.org/software/S0108) can be used to set up a proxy tunnel to allow remote host access to an infected host.[^4]  |
| [[T1518.001-security_software_discovery\|T1518.001]] | Security Software Discovery | [netsh](https://attack.mitre.org/software/S0108) can be used to discover system firewall settings.[^2] [^1]  |




## References

[^1]: [TechNet Netsh Firewall](https://technet.microsoft.com/en-us/library/cc771046(v=ws.10).aspx)


[^2]: [TechNet Netsh](https://technet.microsoft.com/library/bb490939.aspx)


[^3]: [Demaske Netsh Persistence](https://htmlpreview.github.io/?https://github.com/MatthewDemaske/blogbackup/blob/master/netshell.html)


[^4]: [Securelist fileless attacks Feb 2017](https://securelist.com/fileless-attacks-against-enterprise-networks/77403/)

