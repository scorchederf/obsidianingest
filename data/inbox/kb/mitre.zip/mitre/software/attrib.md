---
aliases: 
    - S1176
    
mitre-attack: https://attack.mitre.org/software/S1176
---

## S1176

[attrib](https://attack.mitre.org/software/S1176) is a Windows utility used to display, set or remove attributes assigned to files or directories.[^5]  

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1564.001-hidden_files_and_directories\|T1564.001]] | Hidden Files and Directories | [attrib](https://attack.mitre.org/software/S1176) can be used to make files or directories hidden.[^5] [^1] [^3] [^2] [^4]   |




## References

[^1]: [gbhackers Darkgate Malware 2024](https://gbhackers.com/darkgate-malware-leveraging/)


[^2]: [Checkpoint WannaCry 2017](https://blog.checkpoint.com/research/crying-futile-sandblast-forensic-analysis-wannacry/)


[^3]: [LogRhythm WannaCry](https://web.archive.org/web/20230522041200/https://logrhythm.com/blog/a-technical-analysis-of-wannacry-ransomware/)


[^4]: [Unit42 ComboJack 2018](https://unit42.paloaltonetworks.com/unit42-sure-ill-take-new-combojack-malware-alters-clipboards-steal-cryptocurrency/)


[^5]: [Microsoft attrib 2023](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/attrib)

