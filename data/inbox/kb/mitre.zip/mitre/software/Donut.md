---
aliases: 
    - S0695
    
mitre-attack: https://attack.mitre.org/software/S0695
---

## S0695

[Donut](https://attack.mitre.org/software/S0695) is an open source framework used to generate position-independent shellcode.[^1] [^2]  [Donut](https://attack.mitre.org/software/S0695) generated code has been used by multiple threat actors to inject and load malicious payloads into memory.[^3] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1070-indicator_removal\|T1070]] | Indicator Removal | [Donut](https://attack.mitre.org/software/S0695) can erase file references to payloads in-memory after being reflectively loaded and executed.[^1]  |
| [[T1059.006-python\|T1059.006]] | Python | [Donut](https://attack.mitre.org/software/S0695) can generate shellcode outputs that execute via Python.[^1] 	 |
| [[T1055-process_injection\|T1055]] | Process Injection | [Donut](https://attack.mitre.org/software/S0695) includes a subproject `DonutTest` to inject shellcode into a target process.[^1] 	 |
| [[T1059-command_and_scripting_interpreter\|T1059]] | Command and Scripting Interpreter | [Donut](https://attack.mitre.org/software/S0695) can generate shellcode outputs that execute via Ruby.[^1] 	 |
| [[T1059.005-visual_basic\|T1059.005]] | Visual Basic | [Donut](https://attack.mitre.org/software/S0695) can generate shellcode outputs that execute via VBScript.[^1] 	 |
| [[T1027.013-encrypted_encoded_file\|T1027.013]] | Encrypted／Encoded File | [Donut](https://attack.mitre.org/software/S0695) can generate encrypted, compressed/encoded, or otherwise obfuscated code modules.[^1]  |
| [[T1057-process_discovery\|T1057]] | Process Discovery | [Donut](https://attack.mitre.org/software/S0695) includes subprojects that enumerate and identify information about [Process Injection](https://attack.mitre.org/techniques/T1055) candidates.[^1] 	 |
| [[T1027.002-software_packing\|T1027.002]] | Software Packing | [Donut](https://attack.mitre.org/software/S0695) can generate packed code modules.[^1] 	 |
| [[T1071.001-web_protocols\|T1071.001]] | Web Protocols | [Donut](https://attack.mitre.org/software/S0695) can use HTTP to download previously staged shellcode payloads.[^1]  |
| [[T1059.007-javascript\|T1059.007]] | JavaScript | [Donut](https://attack.mitre.org/software/S0695) can generate shellcode outputs that execute via JavaScript or JScript.[^1] 	 |
| [[T1106-native_api\|T1106]] | Native API | [Donut](https://attack.mitre.org/software/S0695) code modules use various API functions to load and inject code.[^1] 	 |
| [[T1620-reflective_code_loading\|T1620]] | Reflective Code Loading | [Donut](https://attack.mitre.org/software/S0695) can generate code modules that enable in-memory execution of VBScript, JScript, EXE, DLL, and dotNET payloads.[^1]  |
| [[T1685-disable_or_modify_tools\|T1685]] | Disable or Modify Tools | [Donut](https://attack.mitre.org/software/S0695) can patch Antimalware Scan Interface (AMSI), Windows Lockdown Policy (WLDP), as well as exit-related [Native API](https://attack.mitre.org/techniques/T1106) functions to avoid process termination.[^1] 	 |
| [[T1027.015-compression\|T1027.015]] | Compression | [Donut](https://attack.mitre.org/software/S0695) can generate encrypted, compressed/encoded, or otherwise obfuscated code modules.[^1]  |
| [[T1059.001-powershell\|T1059.001]] | PowerShell | [Donut](https://attack.mitre.org/software/S0695) can generate shellcode outputs that execute via PowerShell.[^1] 	 |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [Donut](https://attack.mitre.org/software/S0695) can download and execute previously staged shellcode payloads.[^1]  |




## References

[^1]: [Donut Github](https://github.com/TheWover/donut)


[^2]: [Introducing Donut](https://thewover.github.io/Introducing-Donut/)


[^3]: [NCC Group WastedLocker June 2020](https://research.nccgroup.com/2020/06/23/wastedlocker-a-new-ransomware-variant-developed-by-the-evil-corp-group/)

