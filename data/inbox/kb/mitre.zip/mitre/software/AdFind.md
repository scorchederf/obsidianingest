---
aliases: 
    - S0552
    
mitre-attack: https://attack.mitre.org/software/S0552
---

## S0552

[AdFind](https://attack.mitre.org/software/S0552) is a free command-line query tool that can be used for gathering information from Active Directory.[^4] [^1] [^3] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1482-domain_trust_discovery\|T1482]] | Domain Trust Discovery | [AdFind](https://attack.mitre.org/software/S0552) can gather information about organizational units (OUs) and domain trusts from Active Directory.[^4] [^1] [^3] [^5]  |
| [[T1069.002-domain_groups\|T1069.002]] | Domain Groups | [AdFind](https://attack.mitre.org/software/S0552) can enumerate domain groups.[^4] [^1] [^3] [^5]  |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [AdFind](https://attack.mitre.org/software/S0552) can extract subnet information from Active Directory.[^4] [^1] [^3]  |
| [[T1018-remote_system_discovery\|T1018]] | Remote System Discovery | [AdFind](https://attack.mitre.org/software/S0552) has the ability to query Active Directory for computers.[^4] [^1] [^3] [^2]  |
| [[T1087.002-domain_account\|T1087.002]] | Domain Account | [AdFind](https://attack.mitre.org/software/S0552) can enumerate domain users.[^4] [^1] [^3] [^2] [^5]  |




## References

[^1]: [FireEye FIN6 Apr 2019](https://www.fireeye.com/blog/threat-research/2019/04/pick-six-intercepting-a-fin6-intrusion.html)


[^2]: [Cybereason Bumblebee August 2022](https://www.cybereason.com/blog/threat-analysis-report-bumblebee-loader-the-high-road-to-enterprise-domain-control)


[^3]: [FireEye Ryuk and Trickbot January 2019](https://www.fireeye.com/blog/threat-research/2019/01/a-nasty-trick-from-credential-theft-malware-to-business-disruption.html)


[^4]: [Red Canary Hospital Thwarted Ryuk October 2020](https://redcanary.com/blog/how-one-hospital-thwarted-a-ryuk-ransomware-outbreak/)


[^5]: [Symantec Bumblebee June 2022](https://symantec-enterprise-blogs.security.com/blogs/threat-intelligence/bumblebee-loader-cybercrime)

