---
aliases: 
    - S1209
    
mitre-attack: https://attack.mitre.org/software/S1209
---

## S1209

[Quick Assist](https://attack.mitre.org/software/S1209) is a remote assistance tool primarily for Microsoft Windows, although a macOS version also exists. [Quick Assist](https://attack.mitre.org/software/S1209) allows for remote screen sharing and, with end user approval, remote control and command execution on the enabling device.[^1] [^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1071.001-web_protocols\|T1071.001]] | Web Protocols | [Quick Assist](https://attack.mitre.org/software/S1209) communicates over TCP 443 via HTTPS to a remote session server, under which RDP traffic is transferred.[^2]  |
| [[T1113-screen_capture\|T1113]] | Screen Capture | [Quick Assist](https://attack.mitre.org/software/S1209) allows for the remote administrator to take screenshots of the running system.[^2]  |
| [[T1125-video_capture\|T1125]] | Video Capture | [Quick Assist](https://attack.mitre.org/software/S1209) allows for the remote administrator to view the interactive session of the running machine, including full screen activity.[^2] [^1]  |




## References

[^1]: [Microsoft Storm-1811 2024](https://www.microsoft.com/en-us/security/blog/2024/05/15/threat-actors-misusing-quick-assist-in-social-engineering-attacks-leading-to-ransomware/)


[^2]: [Microsoft Quick Assist 2024](https://learn.microsoft.com/en-us/windows/client-management/client-tools/quick-assist)

