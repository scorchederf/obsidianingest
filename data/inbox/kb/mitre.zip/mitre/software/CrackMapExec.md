---
aliases: 
    - S0488
    
mitre-attack: https://attack.mitre.org/software/S0488
---

## S0488

[CrackMapExec](https://attack.mitre.org/software/S0488), or CME, is a post-exploitation tool developed in Python and designed for penetration testing against networks. [CrackMapExec](https://attack.mitre.org/software/S0488) collects Active Directory information to conduct lateral movement through targeted networks.[^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1003.002-security_account_manager\|T1003.002]] | Security Account Manager | [CrackMapExec](https://attack.mitre.org/software/S0488) can dump usernames and hashed passwords from the SAM.[^1]  |
| [[T1003.003-ntds\|T1003.003]] | NTDS | [CrackMapExec](https://attack.mitre.org/software/S0488) can dump hashed passwords associated with Active Directory using Windows' Directory Replication Services API (DRSUAPI), or Volume Shadow Copy.[^1]  |
| [[T1110.003-password_spraying\|T1110.003]] | Password Spraying | [CrackMapExec](https://attack.mitre.org/software/S0488) can brute force credential authentication by using a supplied list of usernames and a single password.[^1]  |
| [[T1201-password_policy_discovery\|T1201]] | Password Policy Discovery | [CrackMapExec](https://attack.mitre.org/software/S0488) can discover the password policies applied to the target system.[^1]  |
| [[T1087.002-domain_account\|T1087.002]] | Domain Account | [CrackMapExec](https://attack.mitre.org/software/S0488) can enumerate the domain user accounts on a targeted system.[^1]  |
| [[T1049-system_network_connections_discovery\|T1049]] | System Network Connections Discovery | [CrackMapExec](https://attack.mitre.org/software/S0488) can discover active sessions for a targeted system.[^1]  |
| [[T1110.001-password_guessing\|T1110.001]] | Password Guessing | [CrackMapExec](https://attack.mitre.org/software/S0488) can brute force passwords for a specified user on a single target system or across an entire network.[^1]  |
| [[T1053.002-at\|T1053.002]] | At | [CrackMapExec](https://attack.mitre.org/software/S0488) can set a scheduled task on the target system to execute commands remotely using [at](https://attack.mitre.org/software/S0110).[^1]  |
| [[T1135-network_share_discovery\|T1135]] | Network Share Discovery | [CrackMapExec](https://attack.mitre.org/software/S0488) can enumerate the shared folders and associated permissions for a targeted network.[^1]  |
| [[T1018-remote_system_discovery\|T1018]] | Remote System Discovery | [CrackMapExec](https://attack.mitre.org/software/S0488) can discover active IP addresses, along with the machine name, within a targeted network.[^1]  |
| [[T1003.004-lsa_secrets\|T1003.004]] | LSA Secrets | [CrackMapExec](https://attack.mitre.org/software/S0488) can dump hashed passwords from LSA secrets for the targeted system.[^1]  |
| [[T1047-windows_management_instrumentation\|T1047]] | Windows Management Instrumentation | [CrackMapExec](https://attack.mitre.org/software/S0488) can execute remote commands using Windows Management Instrumentation.[^1] 	 |
| [[T1112-modify_registry\|T1112]] | Modify Registry | [CrackMapExec](https://attack.mitre.org/software/S0488) can create a registry key using wdigest.[^1]  |
| [[T1083-file_and_directory_discovery\|T1083]] | File and Directory Discovery | [CrackMapExec](https://attack.mitre.org/software/S0488) can discover specified filetypes and log files on a targeted system.[^1]  |
| [[T1550.002-pass_the_hash\|T1550.002]] | Pass the Hash | [CrackMapExec](https://attack.mitre.org/software/S0488) can pass the hash to authenticate via SMB.[^1]  |
| [[T1680-local_storage_discovery\|T1680]] | Local Storage Discovery | [CrackMapExec](https://attack.mitre.org/software/S0488) can enumerate the system drives and associated system name.[^1]  |
| [[T1069.002-domain_groups\|T1069.002]] | Domain Groups | [CrackMapExec](https://attack.mitre.org/software/S0488) can gather the user accounts within domain groups.[^1]  |
| [[T1059.001-powershell\|T1059.001]] | PowerShell | [CrackMapExec](https://attack.mitre.org/software/S0488) can execute PowerShell commands via WMI.[^1]  |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [CrackMapExec](https://attack.mitre.org/software/S0488) can collect DNS information from the targeted system.[^1]  |
| [[T1110-brute_force\|T1110]] | Brute Force | [CrackMapExec](https://attack.mitre.org/software/S0488) can brute force supplied user credentials across a network range.[^1]  |




## References

[^1]: [CME Github September 2018](https://github.com/byt3bl33d3r/CrackMapExec/wiki/SMB-Command-Reference)

