---
aliases: 
    - S0096
    
mitre-attack: https://attack.mitre.org/software/S0096
---

## S0096

[Systeminfo](https://attack.mitre.org/software/S0096) is a Windows utility that can be used to gather detailed information about a computer. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1082-system_information_discovery\|T1082]] | System Information Discovery | [Systeminfo](https://attack.mitre.org/software/S0096) can be used to gather information about the operating system.[^1]  |




## References

[^1]: [TechNet Systeminfo](https://technet.microsoft.com/en-us/library/bb491007.aspx)

