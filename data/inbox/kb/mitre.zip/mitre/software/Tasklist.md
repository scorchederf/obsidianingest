---
aliases: 
    - S0057
    
mitre-attack: https://attack.mitre.org/software/S0057
---

## S0057

The [Tasklist](https://attack.mitre.org/software/S0057) utility displays a list of applications and services with their Process IDs (PID) for all tasks running on either a local or a remote computer. It is packaged with Windows operating systems and can be executed from the command-line interface. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1057-process_discovery\|T1057]] | Process Discovery | [Tasklist](https://attack.mitre.org/software/S0057) can be used to discover processes running on a system.[^1]  |
| [[T1007-system_service_discovery\|T1007]] | System Service Discovery | [Tasklist](https://attack.mitre.org/software/S0057) can be used to discover services running on a system.[^1]  |
| [[T1518.001-security_software_discovery\|T1518.001]] | Security Software Discovery | [Tasklist](https://attack.mitre.org/software/S0057) can be used to enumerate security software currently running on a system by process name of known products.[^1]  |




## References

[^1]: [Microsoft Tasklist](https://technet.microsoft.com/en-us/library/bb491010.aspx)

