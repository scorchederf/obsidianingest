---
aliases: 
    - S0378
    
mitre-attack: https://attack.mitre.org/software/S0378
---

## S0378

[PoshC2](https://attack.mitre.org/software/S0378) is an open source remote administration and post-exploitation framework that is publicly available on GitHub. The server-side components of the tool are primarily written in Python, while the implants are written in [PowerShell](https://attack.mitre.org/techniques/T1059/001). Although [PoshC2](https://attack.mitre.org/software/S0378) is primarily focused on Windows implantation, it does contain a basic Python dropper for Linux/macOS.[^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [PoshC2](https://attack.mitre.org/software/S0378) can enumerate network adapter information.[^1]  |
| [[T1552.001-credentials_in_files\|T1552.001]] | Credentials In Files | [PoshC2](https://attack.mitre.org/software/S0378) contains modules for searching for passwords in local and remote files.[^1]  |
| [[T1557.001-name_resolution_poisoning_and_smb_relay\|T1557.001]] | Name Resolution Poisoning and SMB Relay | [PoshC2](https://attack.mitre.org/software/S0378) can use Inveigh to conduct name service poisoning for credential theft and associated relay attacks.[^1]  |
| [[T1071.001-web_protocols\|T1071.001]] | Web Protocols | [PoshC2](https://attack.mitre.org/software/S0378) can use protocols like HTTP/HTTPS for command and control traffic.[^1]  |
| [[T1047-windows_management_instrumentation\|T1047]] | Windows Management Instrumentation | [PoshC2](https://attack.mitre.org/software/S0378) has a number of modules that use WMI to execute tasks.[^1]  |
| [[T1049-system_network_connections_discovery\|T1049]] | System Network Connections Discovery | [PoshC2](https://attack.mitre.org/software/S0378) contains an implementation of [netstat](https://attack.mitre.org/software/S0104) to enumerate TCP and UDP connections.[^1]  |
| [[T1068-exploitation_for_privilege_escalation\|T1068]] | Exploitation for Privilege Escalation | [PoshC2](https://attack.mitre.org/software/S0378) contains modules for local privilege escalation exploits such as CVE-2016-9192 and CVE-2016-0099.[^1]  |
| [[T1007-system_service_discovery\|T1007]] | System Service Discovery | [PoshC2](https://attack.mitre.org/software/S0378) can enumerate service and service permission information.[^1]  |
| [[T1134.002-create_process_with_token\|T1134.002]] | Create Process with Token | [PoshC2](https://attack.mitre.org/software/S0378) can use Invoke-RunAs to make tokens.[^1]  |
| [[T1548.002-bypass_user_account_control\|T1548.002]] | Bypass User Account Control | [PoshC2](https://attack.mitre.org/software/S0378) can utilize multiple methods to bypass UAC.[^1]  |
| [[T1569.002-service_execution\|T1569.002]] | Service Execution | [PoshC2](https://attack.mitre.org/software/S0378) contains an implementation of [PsExec](https://attack.mitre.org/software/S0029) for remote execution.[^1]  |
| [[T1087.001-local_account\|T1087.001]] | Local Account | [PoshC2](https://attack.mitre.org/software/S0378) can enumerate local and domain user account information.[^1]  |
| [[T1119-automated_collection\|T1119]] | Automated Collection | [PoshC2](https://attack.mitre.org/software/S0378) contains a module for recursively parsing through files and directories to gather valid credit card numbers.[^1]  |
| [[T1082-system_information_discovery\|T1082]] | System Information Discovery | [PoshC2](https://attack.mitre.org/software/S0378) contains modules, such as `Get-ComputerInfo`, for enumerating common system information.[^1]  |
| [[T1056.001-keylogging\|T1056.001]] | Keylogging | [PoshC2](https://attack.mitre.org/software/S0378) has modules for keystroke logging and capturing credentials from spoofed Outlook authentication messages.[^1]  |
| [[T1087.002-domain_account\|T1087.002]] | Domain Account | [PoshC2](https://attack.mitre.org/software/S0378) can enumerate local and domain user account information.[^1]  |
| [[T1560.001-archive_via_utility\|T1560.001]] | Archive via Utility | [PoshC2](https://attack.mitre.org/software/S0378) contains a module for compressing data using ZIP.[^1]  |
| [[T1550.002-pass_the_hash\|T1550.002]] | Pass the Hash | [PoshC2](https://attack.mitre.org/software/S0378) has a number of modules that leverage pass the hash for lateral movement.[^1]  |
| [[T1069.001-local_groups\|T1069.001]] | Local Groups | [PoshC2](https://attack.mitre.org/software/S0378) contains modules, such as `Get-LocAdm` for enumerating permission groups.[^1]  |
| [[T1083-file_and_directory_discovery\|T1083]] | File and Directory Discovery | [PoshC2](https://attack.mitre.org/software/S0378) can enumerate files on the local file system and includes a module for enumerating recently accessed files.[^1]  |
| [[T1090-proxy\|T1090]] | Proxy | [PoshC2](https://attack.mitre.org/software/S0378) contains modules that allow for use of proxies in command and control.[^1]  |
| [[T1110-brute_force\|T1110]] | Brute Force | [PoshC2](https://attack.mitre.org/software/S0378) has modules for brute forcing local administrator and AD user accounts.[^1]  |
| [[T1003.001-lsass_memory\|T1003.001]] | LSASS Memory | [PoshC2](https://attack.mitre.org/software/S0378) contains an implementation of [Mimikatz](https://attack.mitre.org/software/S0002) to gather credentials from memory.[^1]  |
| [[T1055-process_injection\|T1055]] | Process Injection | [PoshC2](https://attack.mitre.org/software/S0378) contains multiple modules for injecting into processes, such as `Invoke-PSInject`.[^1]  |
| [[T1210-exploitation_of_remote_services\|T1210]] | Exploitation of Remote Services | [PoshC2](https://attack.mitre.org/software/S0378) contains a module for exploiting SMB via EternalBlue.[^1]  |
| [[T1482-domain_trust_discovery\|T1482]] | Domain Trust Discovery | [PoshC2](https://attack.mitre.org/software/S0378) has modules for enumerating domain trusts.[^1]  |
| [[T1134-access_token_manipulation\|T1134]] | Access Token Manipulation | [PoshC2](https://attack.mitre.org/software/S0378) can use Invoke-TokenManipulation for manipulating tokens.[^1]  |
| [[T1046-network_service_discovery\|T1046]] | Network Service Discovery | [PoshC2](https://attack.mitre.org/software/S0378) can perform port scans from an infected host.[^1]  |
| [[T1555-credentials_from_password_stores\|T1555]] | Credentials from Password Stores | [PoshC2](https://attack.mitre.org/software/S0378) can decrypt passwords stored in the RDCMan configuration file.[^2]  |
| [[T1040-network_sniffing\|T1040]] | Network Sniffing | [PoshC2](https://attack.mitre.org/software/S0378) contains a module for taking packet captures on compromised hosts.[^1]  |
| [[T1546.003-windows_management_instrumentation_event_subscription\|T1546.003]] | Windows Management Instrumentation Event Subscription | [PoshC2](https://attack.mitre.org/software/S0378) has the ability to persist on a system using WMI events.[^1]  |
| [[T1201-password_policy_discovery\|T1201]] | Password Policy Discovery | [PoshC2](https://attack.mitre.org/software/S0378) can use `Get-PassPol` to enumerate the domain password policy.[^1]  |




## References

[^1]: [GitHub PoshC2](https://github.com/nettitude/PoshC2_Python)


[^2]: [SecureWorks August 2019](https://www.secureworks.com/blog/lyceum-takes-center-stage-in-middle-east-campaign)

