---
aliases: 
    - S0225
    
mitre-attack: https://attack.mitre.org/software/S0225
---

## S0225

[sqlmap](https://attack.mitre.org/software/S0225) is an open source penetration testing tool that can be used to automate the process of detecting and exploiting SQL injection flaws. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1190-exploit_public_facing_application\|T1190]] | Exploit Public-Facing Application | [sqlmap](https://attack.mitre.org/software/S0225) can be used to automate exploitation of SQL injection vulnerabilities.[^1]  |




## References

[^1]: [sqlmap Introduction](http://sqlmap.org/)

