---
aliases: 
    - S0633
    
mitre-attack: https://attack.mitre.org/software/S0633
---

## S0633

[Sliver](https://attack.mitre.org/software/S0633) is an open source, cross-platform, red team command and control (C2) framework written in Golang. [Sliver](https://attack.mitre.org/software/S0633) includes its own package manager, "armory," for staging and downloading additional tools and payloads to the primary C2 framework.[^11] [^12] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1027-obfuscated_files_or_information\|T1027]] | Obfuscated Files or Information | [Sliver](https://attack.mitre.org/software/S0633) obfuscates configuration and other static files using native Go libraries such as `garble` and `gobfuscate` to inhibit configuration analysis and static detection.[^14]  |
| [[T1055-process_injection\|T1055]] | Process Injection | [Sliver](https://attack.mitre.org/software/S0633) includes multiple methods to perform process injection to migrate the framework into other, potentially privileged processes on the victim machine.[^14] [^12] [^11] [^4]  |
| [[T1083-file_and_directory_discovery\|T1083]] | File and Directory Discovery | [Sliver](https://attack.mitre.org/software/S0633) can enumerate files on a target system.[^2]  |
| [[T1027.004-compile_after_delivery\|T1027.004]] | Compile After Delivery | [Sliver](https://attack.mitre.org/software/S0633) includes functionality to retrieve source code and compile locally prior to execution in victim environments.[^12]  |
| [[T1001.002-steganography\|T1001.002]] | Steganography | [Sliver](https://attack.mitre.org/software/S0633) can encode binary data into a .PNG file for C2 communication.[^10]  |
| [[T1134-access_token_manipulation\|T1134]] | Access Token Manipulation | [Sliver](https://attack.mitre.org/software/S0633) has the ability to manipulate user tokens on targeted Windows systems.[^11] [^4]  |
| [[T1059.001-powershell\|T1059.001]] | PowerShell | [Sliver](https://attack.mitre.org/software/S0633) has built-in functionality to launch a Powershell command prompt.[^12]  |
| [[T1071.004-dns\|T1071.004]] | DNS | [Sliver](https://attack.mitre.org/software/S0633) can support C2 communications over DNS.[^13] [^11] [^3] [^12] [^14]  |
| [[T1027.013-encrypted_encoded_file\|T1027.013]] | Encrypted／Encoded File | [Sliver](https://attack.mitre.org/software/S0633) can encrypt strings at compile time.[^11] [^4]  |
| [[T1573.002-asymmetric_cryptography\|T1573.002]] | Asymmetric Cryptography | [Sliver](https://attack.mitre.org/software/S0633) can use mutual TLS and RSA  cryptography to exchange a session key.[^13] [^11] [^9] [^12] [^14]  |
| [[T1090.001-internal_proxy\|T1090.001]] | Internal Proxy | [Sliver](https://attack.mitre.org/software/S0633) has a built-in SOCKS5 proxying capability allowing for [Sliver](https://attack.mitre.org/software/S0633) clients to proxy network traffic through other clients within a victim network.[^12]  |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [Sliver](https://attack.mitre.org/software/S0633) has the ability to gather network configuration information.[^5]  |
| [[T1113-screen_capture\|T1113]] | Screen Capture | [Sliver](https://attack.mitre.org/software/S0633) can take screenshots of the victim’s active display.[^8]  |
| [[T1071.001-web_protocols\|T1071.001]] | Web Protocols |  [Sliver](https://attack.mitre.org/software/S0633) has the ability to support C2 communications over HTTP and HTTPS.[^13] [^11] [^4] [^12] [^14]  |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [Sliver](https://attack.mitre.org/software/S0633) can download additional content and files from the [Sliver](https://attack.mitre.org/software/S0633) server to the client residing on the victim machine using the `upload` command.[^1] [^12]  |
| [[T1573.001-symmetric_cryptography\|T1573.001]] | Symmetric Cryptography | [Sliver](https://attack.mitre.org/software/S0633) can use AES-GCM-256 to encrypt a session key for C2 message exchange.[^9]  |
| [[T1071-application_layer_protocol\|T1071]] | Application Layer Protocol | [Sliver](https://attack.mitre.org/software/S0633) can utilize the Wireguard VPN protocol for command and control.[^12]  |
| [[T1558.001-golden_ticket\|T1558.001]] | Golden Ticket | [Sliver](https://attack.mitre.org/software/S0633) incorporates the [Rubeus](https://attack.mitre.org/software/S1071) framework to allow for Kerberos ticket manipulation, specifically for forging Kerberos Golden Tickets.[^12]  |
| [[T1041-exfiltration_over_c2_channel\|T1041]] | Exfiltration Over C2 Channel | [Sliver](https://attack.mitre.org/software/S0633) can exfiltrate files from the victim using the `download` command.[^6]  |
| [[T1548.002-bypass_user_account_control\|T1548.002]] | Bypass User Account Control | [Sliver](https://attack.mitre.org/software/S0633) can leverage multiple techniques to bypass User Account Control (UAC) on Windows systems.[^12]  |
| [[T1132.001-standard_encoding\|T1132.001]] | Standard Encoding | [Sliver](https://attack.mitre.org/software/S0633) can use standard encoding techniques like gzip and hex to ASCII to encode the C2 communication payload.[^10]  |
| [[T1003.001-lsass_memory\|T1003.001]] | LSASS Memory | [Sliver](https://attack.mitre.org/software/S0633) has a built-in `procdump` command allowing for retrieval of memory from processes such as `lsass.exe` for credential harvesting.[^12]  |
| [[T1049-system_network_connections_discovery\|T1049]] | System Network Connections Discovery | [Sliver](https://attack.mitre.org/software/S0633) can collect network connection information.[^7]  |




## References

[^1]: [GitHub Sliver Upload](https://github.com/BishopFox/sliver/blob/ea329226636ab8e470086a17f13aa8d330baad22/client/command/filesystem/upload.go)


[^2]: [GitHub Sliver File System August 2021](https://github.com/BishopFox/sliver/tree/master/client/command/filesystem)


[^3]: [GitHub Sliver C2 DNS](https://github.com/BishopFox/sliver/wiki/DNS-C2)


[^4]: [GitHub Sliver C2](https://github.com/BishopFox/sliver/)


[^5]: [GitHub Sliver Ifconfig](https://github.com/BishopFox/sliver/blob/ea329226636ab8e470086a17f13aa8d330baad22/client/command/network/ifconfig.go)


[^6]: [GitHub Sliver Download](https://github.com/BishopFox/sliver/blob/7489c69962b52b09ed377d73d142266564845297/client/command/filesystem/download.go)


[^7]: [GitHub Sliver Netstat](https://github.com/BishopFox/sliver/tree/58a56a077f0813bb312f9fa4df7453b510c3a73b/implant/sliver/netstat)


[^8]: [GitHub Sliver Screen](https://github.com/BishopFox/sliver/blob/master/implant/sliver/screen/screenshot_windows.go)


[^9]: [GitHub Sliver Encryption](https://github.com/BishopFox/sliver/wiki/Transport-Encryption)


[^10]: [GitHub Sliver HTTP](https://github.com/BishopFox/sliver/wiki/HTTP(S)-C2)


[^11]: [Bishop Fox Sliver Framework August 2019](https://labs.bishopfox.com/tech-blog/sliver)


[^12]: [Cybereason Sliver Undated](https://www.cybereason.com/blog/sliver-c2-leveraged-by-many-threat-actors)


[^13]: [Cybersecurity Advisory SVR TTP May 2021](https://www.ncsc.gov.uk/files/Advisory-further-TTPs-associated-with-SVR-cyber-actors.pdf)


[^14]: [Microsoft Sliver 2022](https://www.microsoft.com/en-us/security/blog/2022/08/24/looking-for-the-sliver-lining-hunting-for-emerging-command-and-control-frameworks/)

