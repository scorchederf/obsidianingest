---
aliases: 
    - S0039
    
mitre-attack: https://attack.mitre.org/software/S0039
---

## S0039

The [Net](https://attack.mitre.org/software/S0039) utility is a component of the Windows operating system. It is used in command-line operations for control of users, groups, services, and network connections. [^1] <br><br>[Net](https://attack.mitre.org/software/S0039) has a great deal of functionality, [^6]  much of which is useful for an adversary, such as gathering system and network information for Discovery, moving laterally through [SMB/Windows Admin Shares](https://attack.mitre.org/techniques/T1021/002) using `net use` commands, and interacting with services. The net1.exe utility is executed for certain functionality when net.exe is run and can be used directly in commands such as `net1 user`.

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1201-password_policy_discovery\|T1201]] | Password Policy Discovery | The `net accounts` and `net accounts /domain` commands with [Net](https://attack.mitre.org/software/S0039) can be used to obtain password policy information.[^6]  |
| [[T1069.002-domain_groups\|T1069.002]] | Domain Groups | Commands such as `net group /domain` can be used in [Net](https://attack.mitre.org/software/S0039) to gather information about and manipulate groups.[^6]  |
| [[T1124-system_time_discovery\|T1124]] | System Time Discovery | The `net time` command can be used in [Net](https://attack.mitre.org/software/S0039) to determine the local or remote system time.[^4]  |
| [[T1087.002-domain_account\|T1087.002]] | Domain Account | [Net](https://attack.mitre.org/software/S0039) commands used with the `/domain` flag can be used to gather information about and manipulate user accounts on the current domain.[^7]  |
| [[T1087.001-local_account\|T1087.001]] | Local Account | Commands under `net user` can be used in [Net](https://attack.mitre.org/software/S0039) to gather information about and manipulate user accounts.[^6]  |
| [[T1007-system_service_discovery\|T1007]] | System Service Discovery | The `net start` command can be used in [Net](https://attack.mitre.org/software/S0039) to find information about Windows services.[^6]  |
| [[T1018-remote_system_discovery\|T1018]] | Remote System Discovery | Commands such as `net view` can be used in [Net](https://attack.mitre.org/software/S0039) to gather information about available remote systems.[^6]  |
| [[T1135-network_share_discovery\|T1135]] | Network Share Discovery | The `net view \\remotesystem` and `net share` commands in [Net](https://attack.mitre.org/software/S0039) can be used to find shared drives and directories on remote and local systems respectively.[^6]  |
| [[T1049-system_network_connections_discovery\|T1049]] | System Network Connections Discovery | Commands such as `net use` and `net session` can be used in [Net](https://attack.mitre.org/software/S0039) to gather information about network connections from a particular host.[^6]  |
| [[T1070.005-network_share_connection_removal\|T1070.005]] | Network Share Connection Removal | The `net use \\system\share /delete` command can be used in [Net](https://attack.mitre.org/software/S0039) to remove an established connection to a network share.[^2]  |
| [[T1569.002-service_execution\|T1569.002]] | Service Execution | The `net start` and `net stop` commands can be used in [Net](https://attack.mitre.org/software/S0039) to execute or stop Windows services.[^6]  |
| [[T1136.001-local_account\|T1136.001]] | Local Account | The `net user username \password` commands in [Net](https://attack.mitre.org/software/S0039) can be used to create a local account.[^6]  |
| [[T1098.007-additional_local_or_domain_groups\|T1098.007]] | Additional Local or Domain Groups | The `net localgroup` and `net group` commands in [Net](https://attack.mitre.org/software/S0039) can be used to add existing users to local and domain groups.[^3]  [^5]  |
| [[T1069.001-local_groups\|T1069.001]] | Local Groups | Commands such as `net group` and `net localgroup` can be used in [Net](https://attack.mitre.org/software/S0039) to gather information about and manipulate groups.[^6]  |
| [[T1021.002-smb_windows_admin_shares\|T1021.002]] | SMB／Windows Admin Shares | Lateral movement can be done with [Net](https://attack.mitre.org/software/S0039) through `net use` commands to connect to the on remote systems.[^6]  |
| [[T1136.002-domain_account\|T1136.002]] | Domain Account | The `net user username \password \domain` commands in [Net](https://attack.mitre.org/software/S0039) can be used to create a domain account.[^6]  |




## References

[^1]: [Microsoft Net Utility](https://msdn.microsoft.com/en-us/library/aa939914)


[^2]: [Technet Net Use](https://technet.microsoft.com/bb490717.aspx)


[^3]: [Microsoft Net Localgroup](https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2012-r2-and-2012/cc725622(v=ws.11))


[^4]: [TechNet Net Time](https://technet.microsoft.com/bb490716.aspx)


[^5]: [Microsoft Net Group](https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2012-r2-and-2012/cc754051(v=ws.11))


[^6]: [Savill 1999](https://web.archive.org/web/20150511162820/http://windowsitpro.com/windows/netexe-reference)


[^7]: [Microsoft Net](https://support.microsoft.com/en-us/help/556003)

