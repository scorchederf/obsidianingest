---
aliases: 
    - S0684
    
mitre-attack: https://attack.mitre.org/software/S0684
---

## S0684

[ROADTools](https://attack.mitre.org/software/S0684) is a framework for enumerating Azure Active Directory environments. The tool is written in Python and publicly available on GitHub.[^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1018-remote_system_discovery\|T1018]] | Remote System Discovery | [ROADTools](https://attack.mitre.org/software/S0684) can enumerate Azure AD systems and devices.[^1]  |
| [[T1119-automated_collection\|T1119]] | Automated Collection | [ROADTools](https://attack.mitre.org/software/S0684) automatically gathers data from Azure AD environments using the Azure Graph API.[^1]  |
| [[T1526-cloud_service_discovery\|T1526]] | Cloud Service Discovery | [ROADTools](https://attack.mitre.org/software/S0684) can enumerate Azure AD applications and service principals.[^1] 	 |
| [[T1087.004-cloud_account\|T1087.004]] | Cloud Account | [ROADTools](https://attack.mitre.org/software/S0684) can enumerate Azure AD users.[^1]  |
| [[T1069.003-cloud_groups\|T1069.003]] | Cloud Groups | [ROADTools](https://attack.mitre.org/software/S0684) can enumerate Azure AD groups.[^1] 	 |
| [[T1078.004-cloud_accounts\|T1078.004]] | Cloud Accounts | [ROADTools](https://attack.mitre.org/software/S0684) leverages valid cloud credentials to perform enumeration operations using the internal Azure AD Graph API.[^1] 	 |




## References

[^1]: [Roadtools](https://dirkjanm.io/introducing-roadtools-and-roadrecon-azure-ad-exploration-framework/)


[^2]: [ROADtools Github](https://github.com/dirkjanm/ROADtools)

