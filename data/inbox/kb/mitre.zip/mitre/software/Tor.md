---
aliases: 
    - S0183
    
mitre-attack: https://attack.mitre.org/software/S0183
---

## S0183

[Tor](https://attack.mitre.org/software/S0183) is a software suite and network that provides increased anonymity on the Internet. It creates a multi-hop proxy network and utilizes multilayer encryption to protect both the message and routing information. [Tor](https://attack.mitre.org/software/S0183) utilizes "Onion Routing," in which messages are encrypted with multiple layers of encryption; at each step in the proxy network, the topmost layer is decrypted and the contents forwarded on to the next node until it reaches its destination. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1573.002-asymmetric_cryptography\|T1573.002]] | Asymmetric Cryptography | [Tor](https://attack.mitre.org/software/S0183) encapsulates traffic in multiple layers of encryption, using TLS by default.[^1]  |
| [[T1090.003-multi_hop_proxy\|T1090.003]] | Multi-hop Proxy | Traffic traversing the [Tor](https://attack.mitre.org/software/S0183) network will be forwarded to multiple nodes before exiting the [Tor](https://attack.mitre.org/software/S0183) network and continuing on to its intended destination.[^1]  |




## References

[^1]: [Dingledine Tor The Second-Generation Onion Router](http://www.dtic.mil/dtic/tr/fulltext/u2/a465464.pdf)


[^2]: Tor

