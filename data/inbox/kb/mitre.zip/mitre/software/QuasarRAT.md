---
aliases: 
    - S0262
    
mitre-attack: https://attack.mitre.org/software/S0262
---

## S0262

[QuasarRAT](https://attack.mitre.org/software/S0262) is an open-source, remote access tool that has been publicly available on GitHub since at least 2014. [QuasarRAT](https://attack.mitre.org/software/S0262) is developed in the C# language.[^8] [^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1021.001-remote_desktop_protocol\|T1021.001]] | Remote Desktop Protocol | [QuasarRAT](https://attack.mitre.org/software/S0262) has a module for performing remote desktop access.[^8] [^2]  |
| [[T1056.001-keylogging\|T1056.001]] | Keylogging | [QuasarRAT](https://attack.mitre.org/software/S0262) has a built-in keylogger.[^8] [^2] [^4]  |
| [[T1573.001-symmetric_cryptography\|T1573.001]] | Symmetric Cryptography | [QuasarRAT](https://attack.mitre.org/software/S0262) uses AES with a hardcoded pre-shared key to encrypt network communication.[^8] [^2] [^5]  |
| [[T1555.003-credentials_from_web_browsers\|T1555.003]] | Credentials from Web Browsers | [QuasarRAT](https://attack.mitre.org/software/S0262) can obtain passwords from common web browsers.[^8] [^2] [^4] <br> |
| [[T1547.001-registry_run_keys_startup_folder\|T1547.001]] | Registry Run Keys ／ Startup Folder | If the [QuasarRAT](https://attack.mitre.org/software/S0262) client process does not have administrator privileges it will add a registry key to `HKCU\Software\Microsoft\Windows\CurrentVersion\Run` for persistence.[^8] [^5]   |
| [[T1564.003-hidden_window\|T1564.003]] | Hidden Window | [QuasarRAT](https://attack.mitre.org/software/S0262) can hide process windows and make web requests invisible to the compromised user. Requests marked as invisible have been sent with user-agent string `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/7046A194A` though [QuasarRAT](https://attack.mitre.org/software/S0262) can only be run on Windows systems.[^5]  |
| [[T1082-system_information_discovery\|T1082]] | System Information Discovery | [QuasarRAT](https://attack.mitre.org/software/S0262) can gather system information from the victim’s machine including the OS type.[^8]  |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [QuasarRAT](https://attack.mitre.org/software/S0262) can download files to the victim’s machine and execute them.[^8] [^2]  |
| [[T1614-system_location_discovery\|T1614]] | System Location Discovery | [QuasarRAT](https://attack.mitre.org/software/S0262) can determine the country a victim host is located in.[^5]  |
| [[T1112-modify_registry\|T1112]] | Modify Registry | [QuasarRAT](https://attack.mitre.org/software/S0262) has a command to edit the Registry on the victim’s machine.[^8] [^5]  |
| [[T1564.001-hidden_files_and_directories\|T1564.001]] | Hidden Files and Directories | <br>[QuasarRAT](https://attack.mitre.org/software/S0262) has the ability to set file attributes to "hidden" to hide files from the compromised user's view in Windows File Explorer.[^5]  |
| [[T1033-system_owner_user_discovery\|T1033]] | System Owner／User Discovery | [QuasarRAT](https://attack.mitre.org/software/S0262) can enumerate the username and account type.[^5]  |
| [[T1548.002-bypass_user_account_control\|T1548.002]] | Bypass User Account Control | <br>[QuasarRAT](https://attack.mitre.org/software/S0262) can generate a UAC pop-up Window to prompt the target user to run a command as the administrator.[^5]  |
| [[T1005-data_from_local_system\|T1005]] | Data from Local System | [QuasarRAT](https://attack.mitre.org/software/S0262) can retrieve files from compromised client machines.[^5]  |
| [[T1095-non_application_layer_protocol\|T1095]] | Non-Application Layer Protocol | [QuasarRAT](https://attack.mitre.org/software/S0262) can use TCP for C2 communication.[^5]  |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [QuasarRAT](https://attack.mitre.org/software/S0262) has the ability to enumerate the Wide Area Network (WAN) IP through requests to ip-api[.]com, freegeoip[.]net, or api[.]ipify[.]org observed with user-agent string `Mozilla/5.0 (Windows NT 6.3; rv:48.0) Gecko/20100101 Firefox/48.0`.[^5]  |
| [[T1555-credentials_from_password_stores\|T1555]] | Credentials from Password Stores | [QuasarRAT](https://attack.mitre.org/software/S0262) can obtain passwords from common FTP clients.[^8] [^2]  |
| [[T1552.001-credentials_in_files\|T1552.001]] | Credentials In Files | [QuasarRAT](https://attack.mitre.org/software/S0262) can obtain passwords from FTP clients.[^8] [^2]  |
| [[T1059.003-windows_command_shell\|T1059.003]] | Windows Command Shell | [QuasarRAT](https://attack.mitre.org/software/S0262) can launch a remote shell to execute commands on the victim’s machine.[^8] [^5]  |
| [[T1090-proxy\|T1090]] | Proxy | [QuasarRAT](https://attack.mitre.org/software/S0262) can communicate over a reverse proxy using SOCKS5.[^8] [^2]  |
| [[T1571-non_standard_port\|T1571]] | Non-Standard Port | [QuasarRAT](https://attack.mitre.org/software/S0262) can use port 4782 on the compromised host for TCP callbacks.[^5]  |
| [[T1553.002-code_signing\|T1553.002]] | Code Signing | A [QuasarRAT](https://attack.mitre.org/software/S0262) .dll file is digitally signed by a certificate from AirVPN.[^2]  |
| [[T1010-application_window_discovery\|T1010]] | Application Window Discovery | [APT-C-36](https://attack.mitre.org/groups/G0099) used a customized version of [QuasarRAT](https://attack.mitre.org/software/S0262) to monitor browser windows for strings relating to specific Colombian financial institutions.[^4] <br> |
| [[T1053.005-scheduled_task\|T1053.005]] | Scheduled Task | [QuasarRAT](https://attack.mitre.org/software/S0262) contains a .NET wrapper DLL for creating and managing scheduled tasks for maintaining persistence upon reboot.[^2] [^5]  |
| [[T1125-video_capture\|T1125]] | Video Capture | [QuasarRAT](https://attack.mitre.org/software/S0262) can perform webcam viewing.[^8] [^2]  |




## References

[^1]: [TrendMicro Patchwork Dec 2017](https://documents.trendmicro.com/assets/tech-brief-untangling-the-patchwork-cyberespionage-group.pdf)


[^2]: [Volexity Patchwork June 2018](https://www.volexity.com/blog/2018/06/07/patchwork-apt-group-targets-us-think-tanks/)


[^3]: [Securelist APT10 March 2021](https://securelist.com/apt10-sophisticated-multi-layered-loader-ecipekac-discovered-in-a41apt-campaign/101519/)


[^4]: [Kaspersky BlindEagle AUG 2024](https://securelist.com/blindeagle-apt/113414/)


[^5]: [CISA AR18-352A Quasar RAT December 2018](https://www.cisa.gov/uscert/ncas/analysis-reports/AR18-352A)


[^6]: QuasarRAT


[^7]: xRAT


[^8]: [GitHub QuasarRAT](https://github.com/quasar/QuasarRAT)

