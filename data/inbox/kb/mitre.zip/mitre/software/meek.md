---
aliases: 
    - S0175
    
mitre-attack: https://attack.mitre.org/software/S0175
---

## S0175

[meek](https://attack.mitre.org/software/S0175) is an open-source Tor plugin that tunnels Tor traffic through HTTPS connections.

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1090.004-domain_fronting\|T1090.004]] | Domain Fronting | [meek](https://attack.mitre.org/software/S0175) uses Domain Fronting to disguise the destination of network traffic as another server that is hosted in the same Content Delivery Network (CDN) as the intended destination. |




## References
