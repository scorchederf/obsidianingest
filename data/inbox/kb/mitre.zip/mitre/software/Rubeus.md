---
aliases: 
    - S1071
    
mitre-attack: https://attack.mitre.org/software/S1071
---

## S1071

[Rubeus](https://attack.mitre.org/software/S1071) is a C# toolset designed for raw Kerberos interaction that has been used since at least 2020, including in ransomware operations.[^2] [^3] [^4] [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1558.003-kerberoasting\|T1558.003]] | Kerberoasting | [Rubeus](https://attack.mitre.org/software/S1071) can use the `KerberosRequestorSecurityToken.GetRequest` method to request kerberoastable service tickets.[^2]  |
| [[T1482-domain_trust_discovery\|T1482]] | Domain Trust Discovery | [Rubeus](https://attack.mitre.org/software/S1071) can gather information about domain trusts.[^4] [^1]  |
| [[T1558.002-silver_ticket\|T1558.002]] | Silver Ticket | [Rubeus](https://attack.mitre.org/software/S1071) can create silver tickets.[^2]  |
| [[T1558.004-as_rep_roasting\|T1558.004]] | AS-REP Roasting | [Rubeus](https://attack.mitre.org/software/S1071) can reveal the credentials of accounts that have Kerberos pre-authentication disabled through AS-REP roasting.[^2] [^4] [^1]   |
| [[T1558.001-golden_ticket\|T1558.001]] | Golden Ticket | [Rubeus](https://attack.mitre.org/software/S1071) can forge a ticket-granting ticket.[^2]  |




## References

[^1]: [DFIR Ryuk 2 Hour Speed Run November 2020](https://thedfirreport.com/2020/11/05/ryuk-speed-run-2-hours-to-ransom/)


[^2]: [GitHub Rubeus March 2023](https://github.com/GhostPack/Rubeus)


[^3]: [FireEye KEGTAP SINGLEMALT October 2020](https://www.fireeye.com/blog/threat-research/2020/10/kegtap-and-singlemalt-with-a-ransomware-chaser.html)


[^4]: [DFIR Ryuk's Return October 2020](https://thedfirreport.com/2020/10/08/ryuks-return/)

