---
aliases: 
    - S0106
    
mitre-attack: https://attack.mitre.org/software/S0106
---

## S0106

[cmd](https://attack.mitre.org/software/S0106) is the Windows command-line interpreter that can be used to interact with systems and execute other processes and utilities. [^2] <br><br>Cmd.exe contains native functionality to perform many operations to interact with the system, including listing files in a directory (e.g., `dir` [^3] ), deleting files (e.g., `del` [^4] ), and copying files (e.g., `copy` [^1] ).

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1083-file_and_directory_discovery\|T1083]] | File and Directory Discovery | [cmd](https://attack.mitre.org/software/S0106) can be used to find files and directories with native functionality such as `dir` commands.[^3]  |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [cmd](https://attack.mitre.org/software/S0106) can be used to copy files to/from a remotely connected external system.[^1]  |
| [[T1082-system_information_discovery\|T1082]] | System Information Discovery | [cmd](https://attack.mitre.org/software/S0106) can be used to find information about the operating system.[^3]  |
| [[T1070.004-file_deletion\|T1070.004]] | File Deletion | [cmd](https://attack.mitre.org/software/S0106) can be used to delete files from the file system.[^4]  |
| [[T1059.003-windows_command_shell\|T1059.003]] | Windows Command Shell | [cmd](https://attack.mitre.org/software/S0106) is used to execute programs and other actions at the command-line interface.[^2]  |
| [[T1570-lateral_tool_transfer\|T1570]] | Lateral Tool Transfer | [cmd](https://attack.mitre.org/software/S0106) can be used to copy files to/from a remotely connected internal system.[^1]  |




## References

[^1]: [TechNet Copy](https://technet.microsoft.com/en-us/library/bb490886.aspx)


[^2]: [TechNet Cmd](https://technet.microsoft.com/en-us/library/bb490880.aspx)


[^3]: [TechNet Dir](https://technet.microsoft.com/en-us/library/cc755121.aspx)


[^4]: [TechNet Del](https://technet.microsoft.com/en-us/library/cc771049.aspx)

