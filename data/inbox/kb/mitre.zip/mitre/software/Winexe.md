---
aliases: 
    - S0191
    
mitre-attack: https://attack.mitre.org/software/S0191
---

## S0191

[Winexe](https://attack.mitre.org/software/S0191) is a lightweight, open source tool similar to [PsExec](https://attack.mitre.org/software/S0029) designed to allow system administrators to execute commands on remote servers. [^1]  [Winexe](https://attack.mitre.org/software/S0191) is unique in that it is a GNU/Linux based client. [^3] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1569.002-service_execution\|T1569.002]] | Service Execution | [Winexe](https://attack.mitre.org/software/S0191) installs a service on the remote system, executes the command, then uninstalls the service.[^2]  |




## References

[^1]: [Winexe Github Sept 2013](https://github.com/skalkoto/winexe/)


[^2]: [Secpod Winexe June 2017](https://web.archive.org/web/20211019012628/https://www.secpod.com/blog/winexe/)


[^3]: [Überwachung APT28 Forfiles June 2015](https://netzpolitik.org/2015/digital-attack-on-german-parliament-investigative-report-on-the-hack-of-the-left-party-infrastructure-in-bundestag/)

