---
aliases: 
    - S0363
    
mitre-attack: https://attack.mitre.org/software/S0363
---

## S0363

[Empire](https://attack.mitre.org/software/S0363) is an open-source, cross-platform remote administration and post-exploitation framework that is publicly available on GitHub. While the tool itself is primarily written in Python, the post-exploitation agents are written in pure [PowerShell](https://attack.mitre.org/techniques/T1059/001) for Windows and Python for Linux/macOS. [Empire](https://attack.mitre.org/software/S0363) was one of five tools singled out by a joint report on public hacking tools being widely used by adversaries.[^6] [^8] [^3] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1125-video_capture\|T1125]] | Video Capture | [Empire](https://attack.mitre.org/software/S0363) can capture webcam data on Windows and macOS systems.[^8]  |
| [[T1021.003-distributed_component_object_model\|T1021.003]] | Distributed Component Object Model | [Empire](https://attack.mitre.org/software/S0363) can utilize `Invoke-DCOM` to leverage remote COM execution for lateral movement.[^8]  |
| [[T1557.001-name_resolution_poisoning_and_smb_relay\|T1557.001]] | Name Resolution Poisoning and SMB Relay | [Empire](https://attack.mitre.org/software/S0363) can use Inveigh to conduct name service poisoning for credential theft and associated relay attacks.[^8] [^2]  |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [Empire](https://attack.mitre.org/software/S0363) can acquire network configuration information like DNS servers, public IP, and network proxies used by a host.[^8] [^4]  |
| [[T1059.001-powershell\|T1059.001]] | PowerShell | [Empire](https://attack.mitre.org/software/S0363) leverages PowerShell for the majority of its client-side agent tasks. [Empire](https://attack.mitre.org/software/S0363) also contains the ability to conduct PowerShell remoting with the `Invoke-PSRemoting` module.[^8] [^6]  |
| [[T1482-domain_trust_discovery\|T1482]] | Domain Trust Discovery | [Empire](https://attack.mitre.org/software/S0363) has modules for enumerating domain trusts.[^8]  |
| [[T1056.001-keylogging\|T1056.001]] | Keylogging | [Empire](https://attack.mitre.org/software/S0363) includes keylogging capabilities for Windows, Linux, and macOS systems.[^8]  |
| [[T1027.010-command_obfuscation\|T1027.010]] | Command Obfuscation | [Empire](https://attack.mitre.org/software/S0363) has the ability to obfuscate commands using `Invoke-Obfuscation`.[^8]  |
| [[T1136.001-local_account\|T1136.001]] | Local Account | [Empire](https://attack.mitre.org/software/S0363) has a module for creating a local user if permissions allow.[^8]  |
| [[T1113-screen_capture\|T1113]] | Screen Capture | [Empire](https://attack.mitre.org/software/S0363) is capable of capturing screenshots on Windows and macOS systems.[^8]  |
| [[T1046-network_service_discovery\|T1046]] | Network Service Discovery | [Empire](https://attack.mitre.org/software/S0363) can perform port scans from an infected host.[^8]  |
| [[T1552.001-credentials_in_files\|T1552.001]] | Credentials In Files | [Empire](https://attack.mitre.org/software/S0363) can use various modules to search for files containing passwords.[^8]  |
| [[T1560-archive_collected_data\|T1560]] | Archive Collected Data | [Empire](https://attack.mitre.org/software/S0363) can ZIP directories on the target system.[^8]  |
| [[T1484.001-group_policy_modification\|T1484.001]] | Group Policy Modification | [Empire](https://attack.mitre.org/software/S0363) can use `New-GPOImmediateTask` to modify a GPO that will install and execute a malicious [Scheduled Task/Job](https://attack.mitre.org/techniques/T1053).[^8]  |
| [[T1041-exfiltration_over_c2_channel\|T1041]] | Exfiltration Over C2 Channel | [Empire](https://attack.mitre.org/software/S0363) can send data gathered from a target through the command and control channel.[^8] [^4]  |
| [[T1082-system_information_discovery\|T1082]] | System Information Discovery | [Empire](https://attack.mitre.org/software/S0363) can enumerate host system information like OS, architecture, domain name, applied patches, and more.[^8] [^4]  |
| [[T1115-clipboard_data\|T1115]] | Clipboard Data | [Empire](https://attack.mitre.org/software/S0363) can harvest clipboard data on both Windows and macOS systems.[^8]  |
| [[T1068-exploitation_for_privilege_escalation\|T1068]] | Exploitation for Privilege Escalation | [Empire](https://attack.mitre.org/software/S0363) can exploit vulnerabilities such as MS16-032 and MS16-135.[^8]  |
| [[T1020-automated_exfiltration\|T1020]] | Automated Exfiltration | [Empire](https://attack.mitre.org/software/S0363) has the ability to automatically send collected data back to the threat actors' C2.[^4]  |
| [[T1546.008-accessibility_features\|T1546.008]] | Accessibility Features | [Empire](https://attack.mitre.org/software/S0363) can leverage WMI debugging to remotely replace binaries like sethc.exe, Utilman.exe, and Magnify.exe with cmd.exe.[^8]  |
| [[T1119-automated_collection\|T1119]] | Automated Collection | [Empire](https://attack.mitre.org/software/S0363) can automatically gather the username, domain name, machine name, and other information from a compromised system.[^4]  |
| [[T1555.001-keychain\|T1555.001]] | Keychain | [Empire](https://attack.mitre.org/software/S0363) uses the command `/usr/bin/security dump-keychain -d` to read the keychain credential.[^5]  |
| [[T1615-group_policy_discovery\|T1615]] | Group Policy Discovery | [Empire](https://attack.mitre.org/software/S0363) includes various modules for enumerating Group Policy.[^8]  |
| [[T1087.002-domain_account\|T1087.002]] | Domain Account | [Empire](https://attack.mitre.org/software/S0363) can acquire local and domain user account information.[^8] [^9]  |
| [[T1547.005-security_support_provider\|T1547.005]] | Security Support Provider | [Empire](https://attack.mitre.org/software/S0363) can enumerate Security Support Providers (SSPs) as well as utilize [PowerSploit](https://attack.mitre.org/software/S0194)'s `Install-SSP` and `Invoke-Mimikatz` to install malicious SSPs and log authentication events.[^8]  |
| [[T1021.004-ssh\|T1021.004]] | SSH | [Empire](https://attack.mitre.org/software/S0363) contains modules for executing commands over SSH as well as in-memory VNC agent injection.[^8]  |
| [[T1558.003-kerberoasting\|T1558.003]] | Kerberoasting | [Empire](https://attack.mitre.org/software/S0363) uses [PowerSploit](https://attack.mitre.org/software/S0194)'s `Invoke-Kerberoast` to request service tickets and return crackable ticket hashes.[^8]  |
| [[T1134.005-sid_history_injection\|T1134.005]] | SID-History Injection | [Empire](https://attack.mitre.org/software/S0363) can add a SID-History to a user if on a domain controller.[^8]  |
| [[T1574.009-path_interception_by_unquoted_path\|T1574.009]] | Path Interception by Unquoted Path | [Empire](https://attack.mitre.org/software/S0363) contains modules that can discover and exploit unquoted path vulnerabilities.[^8]  |
| [[T1547.001-registry_run_keys_startup_folder\|T1547.001]] | Registry Run Keys ／ Startup Folder | [Empire](https://attack.mitre.org/software/S0363) can modify the registry run keys `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run` and `HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Run` for persistence.[^8]  |
| [[T1135-network_share_discovery\|T1135]] | Network Share Discovery | [Empire](https://attack.mitre.org/software/S0363) can find shared drives on the local system.[^8]  |
| [[T1574.008-path_interception_by_search_order_hijacking\|T1574.008]] | Path Interception by Search Order Hijacking | [Empire](https://attack.mitre.org/software/S0363) contains modules that can discover and exploit search order hijacking vulnerabilities.[^8]  |
| [[T1558.001-golden_ticket\|T1558.001]] | Golden Ticket | [Empire](https://attack.mitre.org/software/S0363) can leverage its implementation of [Mimikatz](https://attack.mitre.org/software/S0002) to obtain and use golden tickets.[^8]  |
| [[T1210-exploitation_of_remote_services\|T1210]] | Exploitation of Remote Services | [Empire](https://attack.mitre.org/software/S0363) has a limited number of built-in modules for exploiting remote SMB, JBoss, and Jenkins servers.[^8]  |
| [[T1569.002-service_execution\|T1569.002]] | Service Execution | [Empire](https://attack.mitre.org/software/S0363) can use [PsExec](https://attack.mitre.org/software/S0029) to execute a payload on a remote host.[^8]  |
| [[T1567.001-exfiltration_to_code_repository\|T1567.001]] | Exfiltration to Code Repository | [Empire](https://attack.mitre.org/software/S0363) can use GitHub for data exfiltration.[^8]  |
| [[T1083-file_and_directory_discovery\|T1083]] | File and Directory Discovery | [Empire](https://attack.mitre.org/software/S0363) includes various modules for finding files of interest on hosts and network shares.[^8]  |
| [[T1056.004-credential_api_hooking\|T1056.004]] | Credential API Hooking | [Empire](https://attack.mitre.org/software/S0363) contains some modules that leverage API hooking to carry out tasks, such as netripper.[^8]  |
| [[T1574.007-path_interception_by_path_environment_variable\|T1574.007]] | Path Interception by PATH Environment Variable | [Empire](https://attack.mitre.org/software/S0363) contains modules that can discover and exploit path interception opportunities in the PATH environment variable.[^8]  |
| [[T1106-native_api\|T1106]] | Native API | [Empire](https://attack.mitre.org/software/S0363) contains a variety of enumeration modules that have an option to use API calls to carry out tasks.[^8]  |
| [[T1047-windows_management_instrumentation\|T1047]] | Windows Management Instrumentation | [Empire](https://attack.mitre.org/software/S0363) can use WMI to deliver a payload to a remote host.[^8]   |
| [[T1055-process_injection\|T1055]] | Process Injection | [Empire](https://attack.mitre.org/software/S0363) contains multiple modules for injecting into processes, such as `Invoke-PSInject`.[^8]  |
| [[T1550.002-pass_the_hash\|T1550.002]] | Pass the Hash | [Empire](https://attack.mitre.org/software/S0363) can perform pass the hash attacks.[^8]  |
| [[T1217-browser_information_discovery\|T1217]] | Browser Information Discovery | [Empire](https://attack.mitre.org/software/S0363) has the ability to gather browser data such as bookmarks and visited sites.[^8]  |
| [[T1127.001-msbuild\|T1127.001]] | MSBuild | [Empire](https://attack.mitre.org/software/S0363) can use built-in modules to abuse trusted utilities like MSBuild.exe.[^8] <br> |
| [[T1552.004-private_keys\|T1552.004]] | Private Keys | [Empire](https://attack.mitre.org/software/S0363) can use modules like `Invoke-SessionGopher` to extract private key and session information.[^8]  |
| [[T1567.002-exfiltration_to_cloud_storage\|T1567.002]] | Exfiltration to Cloud Storage | [Empire](https://attack.mitre.org/software/S0363) can use Dropbox for data exfiltration.[^8]  |
| [[T1071.001-web_protocols\|T1071.001]] | Web Protocols | [Empire](https://attack.mitre.org/software/S0363) can conduct command and control over protocols like HTTP and HTTPS.[^8]  |
| [[T1134-access_token_manipulation\|T1134]] | Access Token Manipulation | [Empire](https://attack.mitre.org/software/S0363) can use [PowerSploit](https://attack.mitre.org/software/S0194)'s `Invoke-TokenManipulation` to manipulate access tokens.[^8]  |
| [[T1040-network_sniffing\|T1040]] | Network Sniffing | [Empire](https://attack.mitre.org/software/S0363) can be used to conduct packet captures on target hosts.[^8]  |
| [[T1114.001-local_email_collection\|T1114.001]] | Local Email Collection | [Empire](https://attack.mitre.org/software/S0363) has the ability to collect emails on a target system.[^8]  |
| [[T1059.003-windows_command_shell\|T1059.003]] | Windows Command Shell | [Empire](https://attack.mitre.org/software/S0363) has modules for executing scripts.[^8]  |
| [[T1102.002-bidirectional_communication\|T1102.002]] | Bidirectional Communication | [Empire](https://attack.mitre.org/software/S0363) can use Dropbox and GitHub for C2.[^8]  |
| [[T1555.003-credentials_from_web_browsers\|T1555.003]] | Credentials from Web Browsers | [Empire](https://attack.mitre.org/software/S0363) can use modules that extract passwords from common web browsers such as Firefox and Chrome.[^8]  |
| [[T1518.001-security_software_discovery\|T1518.001]] | Security Software Discovery | [Empire](https://attack.mitre.org/software/S0363) can enumerate antivirus software on the target.[^8]  |
| [[T1087.001-local_account\|T1087.001]] | Local Account | [Empire](https://attack.mitre.org/software/S0363) can acquire local and domain user account information.[^8]  |
| [[T1574.004-dylib_hijacking\|T1574.004]] | Dylib Hijacking | [Empire](https://attack.mitre.org/software/S0363) has a dylib hijacker module that generates a malicious dylib given the path to a legitimate dylib of a vulnerable application.[^8]  |
| [[T1049-system_network_connections_discovery\|T1049]] | System Network Connections Discovery | [Empire](https://attack.mitre.org/software/S0363) can enumerate the current network connections of a host.[^8]  |
| [[T1053.005-scheduled_task\|T1053.005]] | Scheduled Task | [Empire](https://attack.mitre.org/software/S0363) has modules to interact with the Windows task scheduler.[^8]  |
| [[T1003.001-lsass_memory\|T1003.001]] | LSASS Memory | [Empire](https://attack.mitre.org/software/S0363) contains an implementation of [Mimikatz](https://attack.mitre.org/software/S0002) to gather credentials from memory.[^8]  |
| [[T1573.002-asymmetric_cryptography\|T1573.002]] | Asymmetric Cryptography | [Empire](https://attack.mitre.org/software/S0363) can use TLS to encrypt its C2 channel.[^8]  |
| [[T1134.002-create_process_with_token\|T1134.002]] | Create Process with Token | [Empire](https://attack.mitre.org/software/S0363) can use `Invoke-RunAs` to make tokens.[^8]  |
| [[T1543.003-windows_service\|T1543.003]] | Windows Service | [Empire](https://attack.mitre.org/software/S0363) can utilize built-in modules to modify service binaries and restore them to their original state.[^8]  |
| [[T1059-command_and_scripting_interpreter\|T1059]] | Command and Scripting Interpreter | [Empire](https://attack.mitre.org/software/S0363) uses a command-line interface to interact with systems.[^8]  |
| [[T1057-process_discovery\|T1057]] | Process Discovery | [Empire](https://attack.mitre.org/software/S0363) can find information about processes running on local and remote systems.[^8] [^4]  |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [Empire](https://attack.mitre.org/software/S0363) can upload and download to and from a victim machine.[^8]  |
| [[T1070.006-timestomp\|T1070.006]] | Timestomp | [Empire](https://attack.mitre.org/software/S0363) can timestomp any files or payloads placed on a target machine to help them blend in.[^8]  |
| [[T1547.009-shortcut_modification\|T1547.009]] | Shortcut Modification | [Empire](https://attack.mitre.org/software/S0363) can persist by modifying a .LNK file to include a backdoor.[^8]  |
| [[T1574.001-dll\|T1574.001]] | DLL | [Empire](https://attack.mitre.org/software/S0363) contains modules that can discover and exploit various DLL hijacking opportunities.[^8]  |
| [[T1136.002-domain_account\|T1136.002]] | Domain Account | [Empire](https://attack.mitre.org/software/S0363) has a module for creating a new domain user if permissions allow.[^8]  |
| [[T1033-system_owner_user_discovery\|T1033]] | System Owner／User Discovery | [Empire](https://attack.mitre.org/software/S0363) can enumerate the username on targeted hosts.[^4]  |
| [[T1548.002-bypass_user_account_control\|T1548.002]] | Bypass User Account Control | [Empire](https://attack.mitre.org/software/S0363) includes various modules to attempt to bypass UAC for escalation of privileges.[^8]  |
| [[T1558.002-silver_ticket\|T1558.002]] | Silver Ticket | [Empire](https://attack.mitre.org/software/S0363) can leverage its implementation of [Mimikatz](https://attack.mitre.org/software/S0002) to obtain and use silver tickets.[^8]  |




## References

[^1]: EmPyre


[^2]: [GitHub Inveigh](https://github.com/Kevin-Robertson/Inveigh)


[^3]: [GitHub ATTACK Empire](https://github.com/dstepanic/attck_empire)


[^4]: [Talos Frankenstein June 2019](https://blog.talosintelligence.com/2019/06/frankenstein-campaign.html)


[^5]: [Empire Keychain Decrypt](https://github.com/EmpireProject/Empire/blob/08cbd274bef78243d7a8ed6443b8364acd1fc48b/lib/modules/python/collection/osx/keychaindump_decrypt.py)


[^6]: [NCSC Joint Report Public Tools](https://www.ncsc.gov.uk/report/joint-report-on-publicly-available-hacking-tools)


[^7]: PowerShell Empire


[^8]: [Github PowerShell Empire](https://github.com/PowerShellEmpire/Empire)


[^9]: [SecureWorks August 2019](https://www.secureworks.com/blog/lyceum-takes-center-stage-in-middle-east-campaign)

