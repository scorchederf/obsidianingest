---
aliases: 
    - S1091
    
mitre-attack: https://attack.mitre.org/software/S1091
---

## S1091

Pacu is an open-source AWS exploitation framework. The tool is written in Python and publicly available on GitHub.[^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1648-serverless_execution\|T1648]] | Serverless Execution | [Pacu](https://attack.mitre.org/software/S1091) can create malicious Lambda functions.[^1]  |
| [[T1685.002-disable_or_modify_cloud_log\|T1685.002]] | Disable or Modify Cloud Log | [Pacu](https://attack.mitre.org/software/S1091) can disable or otherwise restrict various AWS logging services, such as AWS CloudTrail and VPC flow logs.[^1]  |
| [[T1619-cloud_storage_object_discovery\|T1619]] | Cloud Storage Object Discovery | [Pacu](https://attack.mitre.org/software/S1091) can enumerate AWS storage services, such as S3 buckets and Elastic Block Store volumes.[^1]  |
| [[T1049-system_network_connections_discovery\|T1049]] | System Network Connections Discovery | Once inside a Virtual Private Cloud, [Pacu](https://attack.mitre.org/software/S1091) can attempt to identify DirectConnect, VPN, or VPC Peering.[^1]  |
| [[T1654-log_enumeration\|T1654]] | Log Enumeration | [Pacu](https://attack.mitre.org/software/S1091) can collect CloudTrail event histories and CloudWatch logs.[^1]  |
| [[T1526-cloud_service_discovery\|T1526]] | Cloud Service Discovery | [Pacu](https://attack.mitre.org/software/S1091) can enumerate AWS services, such as CloudTrail and CloudWatch.[^1]  |
| [[T1552-unsecured_credentials\|T1552]] | Unsecured Credentials | [Pacu](https://attack.mitre.org/software/S1091) can search for sensitive data: for example, in Code Build environment variables, EC2 user data, and Cloud Formation templates.[^1]  |
| [[T1546-event_triggered_execution\|T1546]] | Event Triggered Execution | [Pacu](https://attack.mitre.org/software/S1091) can set up S3 bucket notifications to trigger a malicious Lambda function when a CloudFormation template is uploaded to the bucket. It can also create Lambda functions that trigger upon the creation of users, roles, and groups.[^1]  |
| [[T1686.001-cloud_firewall\|T1686.001]] | Cloud Firewall | [Pacu](https://attack.mitre.org/software/S1091) can allowlist IP addresses in AWS GuardDuty.[^1]  |
| [[T1069.003-cloud_groups\|T1069.003]] | Cloud Groups | [Pacu](https://attack.mitre.org/software/S1091) can enumerate IAM permissions.[^1]  |
| [[T1098.001-additional_cloud_credentials\|T1098.001]] | Additional Cloud Credentials | [Pacu](https://attack.mitre.org/software/S1091) can generate SSH and API keys for AWS infrastructure and additional API keys for other IAM users.[^1]  |
| [[T1555.006-cloud_secrets_management_stores\|T1555.006]] | Cloud Secrets Management Stores | [Pacu](https://attack.mitre.org/software/S1091) can retrieve secrets from the AWS Secrets Manager via the enum_secrets module.[^1]  |
| [[T1580-cloud_infrastructure_discovery\|T1580]] | Cloud Infrastructure Discovery | [Pacu](https://attack.mitre.org/software/S1091) can enumerate AWS infrastructure, such as EC2 instances.[^1]  |
| [[T1059.009-cloud_api\|T1059.009]] | Cloud API | [Pacu](https://attack.mitre.org/software/S1091) leverages the AWS CLI for its operations.[^1]  |
| [[T1530-data_from_cloud_storage\|T1530]] | Data from Cloud Storage | [Pacu](https://attack.mitre.org/software/S1091) can enumerate and download files stored in AWS storage services, such as S3 buckets.[^1]  |
| [[T1078.004-cloud_accounts\|T1078.004]] | Cloud Accounts | [Pacu](https://attack.mitre.org/software/S1091) leverages valid cloud accounts to perform most of its operations.[^1]  |
| [[T1119-automated_collection\|T1119]] | Automated Collection | [Pacu](https://attack.mitre.org/software/S1091) can automatically collect data, such as CloudFormation templates, EC2 user data, AWS Inspector reports, and IAM credential reports.[^1]  |
| [[T1518.001-security_software_discovery\|T1518.001]] | Security Software Discovery | [Pacu](https://attack.mitre.org/software/S1091) can enumerate AWS security services, including WAF rules and GuardDuty detectors.[^1]  |
| [[T1578.001-create_snapshot\|T1578.001]] | Create Snapshot | [Pacu](https://attack.mitre.org/software/S1091) can create snapshots of EBS volumes and RDS instances.[^1]  |
| [[T1087.004-cloud_account\|T1087.004]] | Cloud Account | [Pacu](https://attack.mitre.org/software/S1091) can enumerate IAM users, roles, and groups. [^1]  |
| [[T1651-cloud_administration_command\|T1651]] | Cloud Administration Command | [Pacu](https://attack.mitre.org/software/S1091) can run commands on EC2 instances using AWS Systems Manager Run Command.[^1]  |




## References

[^1]: [GitHub Pacu](https://github.com/RhinoSecurityLabs/pacu)

