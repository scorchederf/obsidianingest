---
aliases: 
    - S0105
    
mitre-attack: https://attack.mitre.org/software/S0105
---

## S0105

[dsquery](https://attack.mitre.org/software/S0105) is a command-line utility that can be used to query Active Directory for information from a system within a domain. [^3]  It is typically installed only on Windows Server versions but can be installed on non-server variants through the Microsoft-provided Remote Server Administration Tools bundle.

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1087.002-domain_account\|T1087.002]] | Domain Account | [dsquery](https://attack.mitre.org/software/S0105) can be used to gather information on user accounts within a domain.[^3] [^2]  |
| [[T1482-domain_trust_discovery\|T1482]] | Domain Trust Discovery | [dsquery](https://attack.mitre.org/software/S0105) can be used to gather information on domain trusts with `dsquery * -filter "(objectClass=trustedDomain)" -attr *`.[^1]  |
| [[T1069.002-domain_groups\|T1069.002]] | Domain Groups | [dsquery](https://attack.mitre.org/software/S0105) can be used to gather information on permission groups within a domain.[^3] [^2]  |
| [[T1082-system_information_discovery\|T1082]] | System Information Discovery | [dsquery](https://attack.mitre.org/software/S0105) has the ability to enumerate various information, such as the operating system and host name, for systems within a domain.[^2]  |




## References

[^1]: [Harmj0y Domain Trusts](https://posts.specterops.io/a-guide-to-attacking-domain-trusts-971e52cb2944)


[^2]: [Mandiant APT41](https://www.mandiant.com/resources/apt41-us-state-governments)


[^3]: [TechNet Dsquery](https://technet.microsoft.com/en-us/library/cc732952.aspx)

