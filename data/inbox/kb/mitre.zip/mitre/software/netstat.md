---
aliases: 
    - S0104
    
mitre-attack: https://attack.mitre.org/software/S0104
---

## S0104

[netstat](https://attack.mitre.org/software/S0104) is an operating system utility that displays active TCP connections, listening ports, and network statistics. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1049-system_network_connections_discovery\|T1049]] | System Network Connections Discovery | [netstat](https://attack.mitre.org/software/S0104) can be used to enumerate local network connections, including active TCP connections and other network statistics.[^1]  |




## References

[^1]: [TechNet Netstat](https://technet.microsoft.com/en-us/library/bb490947.aspx)

