---
aliases: 
    - S0349
    
mitre-attack: https://attack.mitre.org/software/S0349
---

## S0349

[LaZagne](https://attack.mitre.org/software/S0349) is a post-exploitation, open-source tool used to recover stored passwords on a system. It has modules for Windows, Linux, and OSX, but is mainly focused on Windows systems. [LaZagne](https://attack.mitre.org/software/S0349) is publicly available on GitHub.[^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1552.001-credentials_in_files\|T1552.001]] | Credentials In Files | [LaZagne](https://attack.mitre.org/software/S0349) can obtain credentials from chats, databases, mail, and WiFi.[^1]  |
| [[T1555.004-windows_credential_manager\|T1555.004]] | Windows Credential Manager | [LaZagne](https://attack.mitre.org/software/S0349) can obtain credentials from Vault files.[^1] 	 |
| [[T1003.004-lsa_secrets\|T1003.004]] | LSA Secrets | [LaZagne](https://attack.mitre.org/software/S0349) can perform credential dumping from LSA secrets to obtain account and password information.[^1]  |
| [[T1003.008-etc_passwd_and_etc_shadow\|T1003.008]] | ／etc／passwd and ／etc／shadow | [LaZagne](https://attack.mitre.org/software/S0349) can obtain credential information from /etc/shadow using the shadow.py module.[^1]  |
| [[T1555.003-credentials_from_web_browsers\|T1555.003]] | Credentials from Web Browsers | [LaZagne](https://attack.mitre.org/software/S0349) can obtain credentials from web browsers such as Google Chrome, Internet Explorer, and Firefox.[^1]  |
| [[T1003.001-lsass_memory\|T1003.001]] | LSASS Memory | [LaZagne](https://attack.mitre.org/software/S0349) can perform credential dumping from memory to obtain account and password information.[^1]  |
| [[T1003.005-cached_domain_credentials\|T1003.005]] | Cached Domain Credentials | [LaZagne](https://attack.mitre.org/software/S0349) can perform credential dumping from MSCache to obtain account and password information.[^1]  |
| [[T1555-credentials_from_password_stores\|T1555]] | Credentials from Password Stores | [LaZagne](https://attack.mitre.org/software/S0349) can obtain credentials from databases, mail, and WiFi across multiple platforms.[^1]  |
| [[T1555.001-keychain\|T1555.001]] | Keychain | [LaZagne](https://attack.mitre.org/software/S0349) can obtain credentials from macOS Keychains.[^1] 	 |
| [[T1003.007-proc_filesystem\|T1003.007]] | Proc Filesystem | [LaZagne](https://attack.mitre.org/software/S0349) can use the `<PID>/maps` and `<PID>/mem` files to identify regex patterns to dump cleartext passwords from the browser's process memory.[^1] [^2]  |




## References

[^1]: [GitHub LaZagne Dec 2018](https://github.com/AlessandroZ/LaZagne)


[^2]: [Picus Labs Proc cump 2022](https://www.picussecurity.com/resource/the-mitre-attck-t1003-os-credential-dumping-technique-and-its-adversary-use)


[^3]: [GitHub LaZange Dec 2018](https://github.com/AlessandroZ/LaZagne)


[^4]: LaZagne

