---
aliases: 
    - S0102
    
mitre-attack: https://attack.mitre.org/software/S0102
---

## S0102

[nbtstat](https://attack.mitre.org/software/S0102) is a utility used to troubleshoot NetBIOS name resolution. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [nbtstat](https://attack.mitre.org/software/S0102) can be used to discover local NetBIOS domain names. |
| [[T1049-system_network_connections_discovery\|T1049]] | System Network Connections Discovery | [nbtstat](https://attack.mitre.org/software/S0102) can be used to discover current NetBIOS sessions. |




## References

[^1]: [TechNet Nbtstat](https://technet.microsoft.com/en-us/library/cc940106.aspx)

