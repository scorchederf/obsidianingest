---
aliases: 
    - S0434
    
mitre-attack: https://attack.mitre.org/software/S0434
---

## S0434

[Imminent Monitor](https://attack.mitre.org/software/S0434) was a commodity remote access tool (RAT) offered for sale from 2012 until 2019, when an operation was conducted to take down the Imminent Monitor infrastructure. Various cracked versions and variations of this RAT are still in circulation.[^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1106-native_api\|T1106]] | Native API | [Imminent Monitor](https://attack.mitre.org/software/S0434) has leveraged CreateProcessW() call to execute the debugger.[^1]  |
| [[T1555.003-credentials_from_web_browsers\|T1555.003]] | Credentials from Web Browsers | [Imminent Monitor](https://attack.mitre.org/software/S0434) has a PasswordRecoveryPacket module for recovering browser passwords.[^1]  |
| [[T1140-deobfuscate_decode_files_or_information\|T1140]] | Deobfuscate／Decode Files or Information | [Imminent Monitor](https://attack.mitre.org/software/S0434) has decoded malware components that are then dropped to the system.[^1]  |
| [[T1056.001-keylogging\|T1056.001]] | Keylogging | [Imminent Monitor](https://attack.mitre.org/software/S0434) has a keylogging module.[^2]  |
| [[T1070.004-file_deletion\|T1070.004]] | File Deletion | [Imminent Monitor](https://attack.mitre.org/software/S0434) has deleted files related to its dynamic debugger feature.[^1]  |
| [[T1021.001-remote_desktop_protocol\|T1021.001]] | Remote Desktop Protocol | [Imminent Monitor](https://attack.mitre.org/software/S0434) has a module for performing remote desktop access.[^1]  |
| [[T1057-process_discovery\|T1057]] | Process Discovery | [Imminent Monitor](https://attack.mitre.org/software/S0434) has a "Process Watcher" feature to monitor processes in case the client ever crashes or gets closed.[^2]  |
| [[T1059-command_and_scripting_interpreter\|T1059]] | Command and Scripting Interpreter | [Imminent Monitor](https://attack.mitre.org/software/S0434) has a CommandPromptPacket and ScriptPacket module(s) for creating a remote shell and executing scripts.[^1]  |
| [[T1125-video_capture\|T1125]] | Video Capture | [Imminent Monitor](https://attack.mitre.org/software/S0434) has a remote webcam monitoring capability.[^2] [^1]  |
| [[T1685-disable_or_modify_tools\|T1685]] | Disable or Modify Tools | [Imminent Monitor](https://attack.mitre.org/software/S0434) has a feature to disable Windows Task Manager.[^2] 	 |
| [[T1564.001-hidden_files_and_directories\|T1564.001]] | Hidden Files and Directories | [Imminent Monitor](https://attack.mitre.org/software/S0434) has a dynamic debugging feature to set the file attribute to hidden.[^1]  |
| [[T1496.001-compute_hijacking\|T1496.001]] | Compute Hijacking | [Imminent Monitor](https://attack.mitre.org/software/S0434) has the capability to run a cryptocurrency miner on the victim machine.[^2]  |
| [[T1041-exfiltration_over_c2_channel\|T1041]] | Exfiltration Over C2 Channel | [Imminent Monitor](https://attack.mitre.org/software/S0434) has uploaded a file containing debugger logs, network information and system information to the C2.[^1]  |
| [[T1123-audio_capture\|T1123]] | Audio Capture | [Imminent Monitor](https://attack.mitre.org/software/S0434) has a remote microphone monitoring capability.[^2] [^1]  |
| [[T1027-obfuscated_files_or_information\|T1027]] | Obfuscated Files or Information | [Imminent Monitor](https://attack.mitre.org/software/S0434) has encrypted the spearphish attachments to avoid detection from email gateways; the debugger also encrypts information before sending to the C2.[^1]  |
| [[T1083-file_and_directory_discovery\|T1083]] | File and Directory Discovery | [Imminent Monitor](https://attack.mitre.org/software/S0434) has a dynamic debugging feature to check whether it is located in the %TEMP% directory, otherwise it copies itself there.[^1]  |




## References

[^1]: [QiAnXin APT-C-36 Feb2019](https://web.archive.org/web/20190625182633if_/https://ti.360.net/blog/articles/apt-c-36-continuous-attacks-targeting-colombian-government-institutions-and-corporations-en/)


[^2]: [Imminent Unit42 Dec2019](https://unit42.paloaltonetworks.com/imminent-monitor-a-rat-down-under/)

