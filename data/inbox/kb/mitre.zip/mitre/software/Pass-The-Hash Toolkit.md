---
aliases: 
    - S0122
    
mitre-attack: https://attack.mitre.org/software/S0122
---

## S0122

[Pass-The-Hash Toolkit](https://attack.mitre.org/software/S0122) is a toolkit that allows an adversary to "pass" a password hash (without knowing the original password) to log in to systems. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1550.002-pass_the_hash\|T1550.002]] | Pass the Hash | [Pass-The-Hash Toolkit](https://attack.mitre.org/software/S0122) can perform pass the hash.[^1]  |




## References

[^1]: [Mandiant APT1](https://www.fireeye.com/content/dam/fireeye-www/services/pdfs/mandiant-apt1-report.pdf)

