---
aliases: 
    - S0095
    
mitre-attack: https://attack.mitre.org/software/S0095
---

## S0095

[ftp](https://attack.mitre.org/software/S0095) is a utility commonly available with operating systems to transfer information over the File Transfer Protocol (FTP). Adversaries can use it to transfer other tools onto a system or to exfiltrate data.[^1] [^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1570-lateral_tool_transfer\|T1570]] | Lateral Tool Transfer | [ftp](https://attack.mitre.org/software/S0095) may be abused by adversaries to transfer tools or files between systems within a compromised environment.[^1] [^2]  |
| [[T1048.003-exfiltration_over_unencrypted_non_c2_protocol\|T1048.003]] | Exfiltration Over Unencrypted Non-C2 Protocol | [ftp](https://attack.mitre.org/software/S0095) may be used to exfiltrate data separate from the main command and control protocol.[^1] [^2]  |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [ftp](https://attack.mitre.org/software/S0095) may be abused by adversaries to transfer tools or files from an external system into a compromised environment.[^1] [^2]  |




## References

[^1]: [Microsoft FTP](https://docs.microsoft.com/en-us/windows-server/administration/windows-commands/ftp)


[^2]: [Linux FTP](https://linux.die.net/man/1/ftp)

