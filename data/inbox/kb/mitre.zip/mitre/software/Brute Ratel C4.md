---
aliases: 
    - S1063
    
mitre-attack: https://attack.mitre.org/software/S1063
---

## S1063

[Brute Ratel C4](https://attack.mitre.org/software/S1063) is a commercial red-teaming and adversarial attack simulation tool that first appeared in December 2020. [Brute Ratel C4](https://attack.mitre.org/software/S1063) was specifically designed to avoid detection by endpoint detection and response (EDR) and antivirus (AV) capabilities, and deploys agents called badgers to enable arbitrary command execution for lateral movement, privilege escalation, and persistence. In September 2022, a cracked version of [Brute Ratel C4](https://attack.mitre.org/software/S1063) was leaked in the cybercriminal underground, leading to its use by threat actors.[^6] [^2] [^1] [^5] [^4] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1055.002-portable_executable_injection\|T1055.002]] | Portable Executable Injection | [Brute Ratel C4](https://attack.mitre.org/software/S1063) has injected [Latrodectus](https://attack.mitre.org/software/S1160) into the Explorer.exe process on comrpomised hosts.[^7]  |
| [[T1569.002-service_execution\|T1569.002]] | Service Execution | <br>[Brute Ratel C4](https://attack.mitre.org/software/S1063) can create Windows system services for execution.[^2]  |
| [[T1059.003-windows_command_shell\|T1059.003]] | Windows Command Shell | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can use cmd.exe for execution.[^2]  |
| [[T1021.006-windows_remote_management\|T1021.006]] | Windows Remote Management | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can use WinRM for pivoting.[^2]  |
| [[T1113-screen_capture\|T1113]] | Screen Capture | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can take screenshots on compromised hosts.[^2]  |
| [[T1057-process_discovery\|T1057]] | Process Discovery | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can enumerate all processes and locate specific process IDs (PIDs).[^2]  |
| [[T1027-obfuscated_files_or_information\|T1027]] | Obfuscated Files or Information | [Brute Ratel C4](https://attack.mitre.org/software/S1063) has used encrypted payload files and maintains an encrypted configuration structure in memory.[^2] [^1]  |
| [[T1047-windows_management_instrumentation\|T1047]] | Windows Management Instrumentation | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can use WMI to move laterally.[^2]  |
| [[T1036.005-match_legitimate_resource_name_or_location\|T1036.005]] | Match Legitimate Resource Name or Location | [Brute Ratel C4](https://attack.mitre.org/software/S1063) has used a payload file named OneDrive.update to appear benign.[^2]  |
| [[T1021.002-smb_windows_admin_shares\|T1021.002]] | SMB／Windows Admin Shares | [Brute Ratel C4](https://attack.mitre.org/software/S1063) has the ability to use SMB to pivot in compromised networks.[^2] [^1] [^6]  |
| [[T1005-data_from_local_system\|T1005]] | Data from Local System | <br>[Brute Ratel C4](https://attack.mitre.org/software/S1063) has the ability to upload files from a compromised system.[^2]  |
| [[T1140-deobfuscate_decode_files_or_information\|T1140]] | Deobfuscate／Decode Files or Information | [Brute Ratel C4](https://attack.mitre.org/software/S1063) has the ability to deobfuscate its payload prior to execution.[^2]  |
| [[T1069.002-domain_groups\|T1069.002]] | Domain Groups | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can use `net group` for discovery on targeted domains.[^4]  |
| [[T1572-protocol_tunneling\|T1572]] | Protocol Tunneling | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can use DNS over HTTPS for C2.[^2] [^4]  |
| [[T1518.001-security_software_discovery\|T1518.001]] | Security Software Discovery | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can detect EDR userland hooks.[^2]  |
| [[T1685-disable_or_modify_tools\|T1685]] | Disable or Modify Tools | [Brute Ratel C4](https://attack.mitre.org/software/S1063) has the ability to hide memory artifacts and to patch Event Tracing for Windows (ETW) and the Anti Malware Scan Interface (AMSI).[^2] [^1]  |
| [[T1036.008-masquerade_file_type\|T1036.008]] | Masquerade File Type | [Brute Ratel C4](https://attack.mitre.org/software/S1063) has used Microsoft Word icons to hide malicious LNK files.[^2]  |
| [[T1087.002-domain_account\|T1087.002]] | Domain Account | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can use LDAP queries, `net group "Domain Admins" /domain` and `net user /domain` for discovery.[^2] [^4]  |
| [[T1021-remote_services\|T1021]] | Remote Services | [Brute Ratel C4](https://attack.mitre.org/software/S1063) has the ability to use RPC for lateral movement.[^2]  |
| [[T1620-reflective_code_loading\|T1620]] | Reflective Code Loading | [Brute Ratel C4](https://attack.mitre.org/software/S1063) has used reflective loading to execute malicious DLLs.[^1]  |
| [[T1046-network_service_discovery\|T1046]] | Network Service Discovery | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can conduct port scanning against targeted systems.[^2]  |
| [[T1482-domain_trust_discovery\|T1482]] | Domain Trust Discovery | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can use LDAP queries and `nltest /domain_trusts` for domain trust discovery.[^2] [^4]  |
| [[T1106-native_api\|T1106]] | Native API | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can call multiple Windows APIs for execution, to share memory, and defense evasion.[^2] [^1]  |
| [[T1102-web_service\|T1102]] | Web Service | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can use legitimate websites for external C2 channels including Slack, Discord, and MS Teams.[^2]  |
| [[T1071.004-dns\|T1071.004]] | DNS | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can use DNS over HTTPS for C2.[^2] [^4]  |
| [[T1095-non_application_layer_protocol\|T1095]] | Non-Application Layer Protocol | [Brute Ratel C4](https://attack.mitre.org/software/S1063) has the ability to use TCP for external C2.[^2]  |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | <br>[Brute Ratel C4](https://attack.mitre.org/software/S1063) can download files to compromised hosts.[^2] [^7]  |
| [[T1027.007-dynamic_api_resolution\|T1027.007]] | Dynamic API Resolution | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can call and dynamically resolve hashed APIs.[^2]  |
| [[T1497.003-time_based_checks\|T1497.003]] | Time Based Checks | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can call `NtDelayExecution` to pause execution.[^2] [^1]  |
| [[T1574.001-dll\|T1574.001]] | DLL | [Brute Ratel C4](https://attack.mitre.org/software/S1063) has used search order hijacking to load a malicious payload DLL as a dependency to a benign application packaged in the same ISO.[^2]  [Brute Ratel C4](https://attack.mitre.org/software/S1063) has loaded a malicious DLL by spoofing the name of the legitimate Version.DLL and placing it in the same folder as the digitally-signed Microsoft binary OneDriveUpdater.exe.[^2]  |
| [[T1558.003-kerberoasting\|T1558.003]] | Kerberoasting | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can decode Kerberos 5 tickets and convert it to hashcat format for subsequent cracking.[^2]  |
| [[T1204.002-malicious_file\|T1204.002]] | Malicious File | [Brute Ratel C4](https://attack.mitre.org/software/S1063) has gained execution through users opening malicious documents.[^2]  |
| [[T1071.001-web_protocols\|T1071.001]] | Web Protocols | [Brute Ratel C4](https://attack.mitre.org/software/S1063) can use HTTPS and HTTPS for C2 communication.[^2] [^4]  |




## References

[^1]: [MDSec Brute Ratel August 2022](https://www.mdsec.co.uk/2022/08/part-3-how-i-met-your-beacon-brute-ratel/)


[^2]: [Palo Alto Brute Ratel July 2022](https://unit42.paloaltonetworks.com/brute-ratel-c4-tool/)


[^3]: BRc4


[^4]: [Trend Micro Black Basta October 2022](https://www.trendmicro.com/en_us/research/22/j/black-basta-infiltrates-networks-via-qakbot-brute-ratel-and-coba.html)


[^5]: [SANS Brute Ratel October 2022](https://www.sans.org/blog/cracked-brute-ratel-c4-framework-proliferates-across-the-cybercriminal-underground/)


[^6]: [Dark Vortex Brute Ratel C4](https://bruteratel.com/)


[^7]: [Rapid7 Fake W2 July 2024](https://www.rapid7.com/blog/post/2024/07/24/malware-campaign-lures-users-with-fake-w2-form/)

