---
aliases: 
    - S0521
    
mitre-attack: https://attack.mitre.org/software/S0521
---

## S0521

[BloodHound](https://attack.mitre.org/software/S0521) is an Active Directory (AD) reconnaissance tool that can reveal hidden relationships and identify attack paths within an AD environment.[^1] [^2] [^4] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1069.002-domain_groups\|T1069.002]] | Domain Groups | [BloodHound](https://attack.mitre.org/software/S0521) can collect information about domain groups and members.[^2]  |
| [[T1615-group_policy_discovery\|T1615]] | Group Policy Discovery | [BloodHound](https://attack.mitre.org/software/S0521) has the ability to collect local admin information via GPO.[^1]  |
| [[T1560-archive_collected_data\|T1560]] | Archive Collected Data | [BloodHound](https://attack.mitre.org/software/S0521) can compress data collected by its SharpHound ingestor into a ZIP file to be written to disk.[^1] [^3]  |
| [[T1069.001-local_groups\|T1069.001]] | Local Groups | [BloodHound](https://attack.mitre.org/software/S0521) can collect information about local groups and members.[^2]  |
| [[T1087.002-domain_account\|T1087.002]] | Domain Account | [BloodHound](https://attack.mitre.org/software/S0521) can collect information about domain users, including identification of domain admin accounts.[^2]  |
| [[T1087.001-local_account\|T1087.001]] | Local Account | [BloodHound](https://attack.mitre.org/software/S0521) can identify users with local administrator rights.[^2]  |
| [[T1033-system_owner_user_discovery\|T1033]] | System Owner／User Discovery | [BloodHound](https://attack.mitre.org/software/S0521) can collect information on user sessions.[^2]  |
| [[T1018-remote_system_discovery\|T1018]] | Remote System Discovery | [BloodHound](https://attack.mitre.org/software/S0521) can enumerate and collect the properties of domain computers, including domain controllers.[^2]  |
| [[T1106-native_api\|T1106]] | Native API | [BloodHound](https://attack.mitre.org/software/S0521) can use .NET API calls in the SharpHound ingestor component to pull Active Directory data.[^1]  |
| [[T1059.001-powershell\|T1059.001]] | PowerShell | [BloodHound](https://attack.mitre.org/software/S0521) can use PowerShell to pull Active Directory information from the target environment.[^2]  |
| [[T1482-domain_trust_discovery\|T1482]] | Domain Trust Discovery | [BloodHound](https://attack.mitre.org/software/S0521) has the ability to map domain trusts and identify misconfigurations for potential abuse.[^2]  |




## References

[^1]: [GitHub Bloodhound](https://github.com/BloodHoundAD/BloodHound)


[^2]: [CrowdStrike BloodHound April 2018](https://www.crowdstrike.com/blog/hidden-administrative-accounts-bloodhound-to-the-rescue/)


[^3]: [Trend Micro Black Basta October 2022](https://www.trendmicro.com/en_us/research/22/j/black-basta-infiltrates-networks-via-qakbot-brute-ratel-and-coba.html)


[^4]: [FoxIT Wocao December 2019](https://www.fox-it.com/media/kadlze5c/201912_report_operation_wocao.pdf)

