---
aliases: 
    - S0195
    
mitre-attack: https://attack.mitre.org/software/S0195
---

## S0195

[SDelete](https://attack.mitre.org/software/S0195) is an application that securely deletes data in a way that makes it unrecoverable. It is part of the Microsoft Sysinternals suite of tools. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1070.004-file_deletion\|T1070.004]] | File Deletion | [SDelete](https://attack.mitre.org/software/S0195) deletes data in a way that makes it unrecoverable.[^1]  |
| [[T1485-data_destruction\|T1485]] | Data Destruction | [SDelete](https://attack.mitre.org/software/S0195) deletes data in a way that makes it unrecoverable.[^1]  |




## References

[^1]: [Microsoft SDelete July 2016](https://docs.microsoft.com/en-us/sysinternals/downloads/sdelete)


[^2]: SDelete

