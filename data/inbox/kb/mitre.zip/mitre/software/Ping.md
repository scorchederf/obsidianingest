---
aliases: 
    - S0097
    
mitre-attack: https://attack.mitre.org/software/S0097
---

## S0097

[Ping](https://attack.mitre.org/software/S0097) is an operating system utility commonly used to troubleshoot and verify network connections. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1018-remote_system_discovery\|T1018]] | Remote System Discovery | [Ping](https://attack.mitre.org/software/S0097) can be used to identify remote systems within a network.[^1]  |




## References

[^1]: [TechNet Ping](https://technet.microsoft.com/en-us/library/bb490968.aspx)

