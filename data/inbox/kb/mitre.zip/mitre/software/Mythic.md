---
aliases: 
    - S0699
    
mitre-attack: https://attack.mitre.org/software/S0699
---

## S0699

[Mythic](https://attack.mitre.org/software/S0699) is an open source, cross-platform post-exploitation/command and control platform. [Mythic](https://attack.mitre.org/software/S0699) is designed to "plug-n-play" with various agents and communication channels.[^3] [^4] [^2]  Deployed [Mythic](https://attack.mitre.org/software/S0699) C2 servers have been observed as part of potentially malicious infrastructure.[^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1090.002-external_proxy\|T1090.002]] | External Proxy | [Mythic](https://attack.mitre.org/software/S0699) can leverage a modified SOCKS5 proxy to tunnel egress C2 traffic.[^2]  |
| [[T1071.002-file_transfer_protocols\|T1071.002]] | File Transfer Protocols | [Mythic](https://attack.mitre.org/software/S0699) supports SMB-based peer-to-peer C2 profiles.[^2] 	 |
| [[T1573.002-asymmetric_cryptography\|T1573.002]] | Asymmetric Cryptography | [Mythic](https://attack.mitre.org/software/S0699) supports SSL encrypted C2.[^2] 	 |
| [[T1071.004-dns\|T1071.004]] | DNS | [Mythic](https://attack.mitre.org/software/S0699) supports DNS-based C2 profiles.[^2] 	 |
| [[T1071.001-web_protocols\|T1071.001]] | Web Protocols | [Mythic](https://attack.mitre.org/software/S0699) supports HTTP-based C2 profiles.[^2] 	 |
| [[T1132-data_encoding\|T1132]] | Data Encoding | [Mythic](https://attack.mitre.org/software/S0699) provides various transform functions to encode and/or randomize C2 data.[^2] 	 |
| [[T1090.001-internal_proxy\|T1090.001]] | Internal Proxy | [Mythic](https://attack.mitre.org/software/S0699) can leverage a peer-to-peer C2 profile between agents.[^2] 		 |
| [[T1095-non_application_layer_protocol\|T1095]] | Non-Application Layer Protocol | [Mythic](https://attack.mitre.org/software/S0699) supports WebSocket and TCP-based C2 profiles.[^2] 	 |
| [[T1030-data_transfer_size_limits\|T1030]] | Data Transfer Size Limits | [Mythic](https://attack.mitre.org/software/S0699) supports custom chunk sizes used to upload/download files.[^2] 	 |
| [[T1119-automated_collection\|T1119]] | Automated Collection | [Mythic](https://attack.mitre.org/software/S0699) supports scripting of file downloads from agents.[^2] 	 |
| [[T1572-protocol_tunneling\|T1572]] | Protocol Tunneling | [Mythic](https://attack.mitre.org/software/S0699) can use SOCKS proxies to tunnel traffic through another protocol.[^2]  |
| [[T1090.004-domain_fronting\|T1090.004]] | Domain Fronting | [Mythic](https://attack.mitre.org/software/S0699) supports domain fronting via custom request headers.[^2] 	 |
| [[T1008-fallback_channels\|T1008]] | Fallback Channels | [Mythic](https://attack.mitre.org/software/S0699) can use a list of C2 URLs as fallback mechanisms in case one IP or domain gets blocked.[^2] 	 |




## References

[^1]: [RecordedFuture 2021 Ad Infra](https://go.recordedfuture.com/hubfs/reports/cta-2022-0118.pdf)


[^2]: [Mythc Documentation](https://docs.mythic-c2.net/)


[^3]: [Mythic Github](https://github.com/its-a-feature/Mythic)


[^4]: [Mythic SpecterOps](https://posts.specterops.io/a-change-of-mythic-proportions-21debeb03617)

