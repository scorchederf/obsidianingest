---
aliases: 
    - S0194
    
mitre-attack: https://attack.mitre.org/software/S0194
---

## S0194

[PowerSploit](https://attack.mitre.org/software/S0194) is an open source, offensive security framework comprised of [PowerShell](https://attack.mitre.org/techniques/T1059/001) modules and scripts that perform a wide range of tasks related to penetration testing such as code execution, persistence, bypassing anti-virus, recon, and exfiltration. [^2]  [^4]  [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1574.007-path_interception_by_path_environment_variable\|T1574.007]] | Path Interception by PATH Environment Variable | [PowerSploit](https://attack.mitre.org/software/S0194) contains a collection of Privesc-PowerUp modules that can discover and exploit path interception opportunities in the PATH environment variable.[^2] [^1]  |
| [[T1056.001-keylogging\|T1056.001]] | Keylogging | [PowerSploit](https://attack.mitre.org/software/S0194)'s `Get-Keystrokes` Exfiltration module can log keystrokes.[^2] [^1]  |
| [[T1620-reflective_code_loading\|T1620]] | Reflective Code Loading | [PowerSploit](https://attack.mitre.org/software/S0194) reflectively loads a Windows PE file into a process.[^2] [^1]  |
| [[T1552.002-credentials_in_registry\|T1552.002]] | Credentials in Registry | [PowerSploit](https://attack.mitre.org/software/S0194) has several modules that search the Windows Registry for stored credentials: `Get-UnattendedInstallFile`, `Get-Webconfig`, `Get-ApplicationHost`, `Get-SiteListPassword`, `Get-CachedGPPPassword`, and `Get-RegistryAutoLogon`.[^6]  |
| [[T1027.005-indicator_removal_from_tools\|T1027.005]] | Indicator Removal from Tools | [PowerSploit](https://attack.mitre.org/software/S0194)'s `Find-AVSignature` AntivirusBypass module can be used to locate single byte anti-virus signatures.[^2] [^1]  |
| [[T1123-audio_capture\|T1123]] | Audio Capture | [PowerSploit](https://attack.mitre.org/software/S0194)'s `Get-MicrophoneAudio` Exfiltration module can record system microphone audio.[^2] [^1]  |
| [[T1047-windows_management_instrumentation\|T1047]] | Windows Management Instrumentation | [PowerSploit](https://attack.mitre.org/software/S0194)'s `Invoke-WmiCommand` CodeExecution module uses WMI to execute and retrieve the output from a [PowerShell](https://attack.mitre.org/techniques/T1086) payload.[^2] [^1]  |
| [[T1574.009-path_interception_by_unquoted_path\|T1574.009]] | Path Interception by Unquoted Path | [PowerSploit](https://attack.mitre.org/software/S0194) contains a collection of Privesc-PowerUp modules that can discover and exploit unquoted path vulnerabilities.[^2] [^1]  |
| [[T1012-query_registry\|T1012]] | Query Registry | [PowerSploit](https://attack.mitre.org/software/S0194) contains a collection of Privesc-PowerUp modules that can query Registry keys for potential opportunities.[^2] [^1]  |
| [[T1005-data_from_local_system\|T1005]] | Data from Local System | [PowerSploit](https://attack.mitre.org/software/S0194) contains a collection of Exfiltration modules that can access data from local files, volumes, and processes.[^2] [^1]  |
| [[T1552.006-group_policy_preferences\|T1552.006]] | Group Policy Preferences | [PowerSploit](https://attack.mitre.org/software/S0194) contains a collection of Exfiltration modules that can harvest credentials from Group Policy Preferences.[^2] [^1]  |
| [[T1055.001-dynamic_link_library_injection\|T1055.001]] | Dynamic-link Library Injection | [PowerSploit](https://attack.mitre.org/software/S0194) contains a collection of CodeExecution modules that inject code (DLL, shellcode) into a process.[^2] [^1]  |
| [[T1027.010-command_obfuscation\|T1027.010]] | Command Obfuscation | [PowerSploit](https://attack.mitre.org/software/S0194) contains a collection of ScriptModification modules that compress and encode scripts and payloads.[^2] [^1]  |
| [[T1134-access_token_manipulation\|T1134]] | Access Token Manipulation | [PowerSploit](https://attack.mitre.org/software/S0194)'s `Invoke-TokenManipulation` Exfiltration module can be used to manipulate tokens.[^2] [^1]  |
| [[T1543.003-windows_service\|T1543.003]] | Windows Service | [PowerSploit](https://attack.mitre.org/software/S0194) contains a collection of Privesc-PowerUp modules that can discover and replace/modify service binaries, paths, and configs.[^2] [^1]  |
| [[T1113-screen_capture\|T1113]] | Screen Capture | [PowerSploit](https://attack.mitre.org/software/S0194)'s `Get-TimedScreenshot` Exfiltration module can take screenshots at regular intervals.[^2] [^1]  |
| [[T1547.001-registry_run_keys_startup_folder\|T1547.001]] | Registry Run Keys ／ Startup Folder | [PowerSploit](https://attack.mitre.org/software/S0194)'s `New-UserPersistenceOption` Persistence argument can be used to establish via the `HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run` Registry key.[^2] [^1]  |
| [[T1053.005-scheduled_task\|T1053.005]] | Scheduled Task | [PowerSploit](https://attack.mitre.org/software/S0194)'s `New-UserPersistenceOption` Persistence argument can be used to establish via a [Scheduled Task/Job](https://attack.mitre.org/techniques/T1053).[^2] [^1]  |
| [[T1574.001-dll\|T1574.001]] | DLL | [PowerSploit](https://attack.mitre.org/software/S0194) contains a collection of Privesc-PowerUp modules that can discover and exploit DLL hijacking opportunities in services and processes.[^2] [^1]  |
| [[T1574.008-path_interception_by_search_order_hijacking\|T1574.008]] | Path Interception by Search Order Hijacking | [PowerSploit](https://attack.mitre.org/software/S0194) contains a collection of Privesc-PowerUp modules that can discover and exploit search order hijacking vulnerabilities.[^2] [^1]  |
| [[T1558.003-kerberoasting\|T1558.003]] | Kerberoasting | [PowerSploit](https://attack.mitre.org/software/S0194)'s `Invoke-Kerberoast` module can request service tickets and return crackable ticket hashes.[^3] [^5]  |
| [[T1087.001-local_account\|T1087.001]] | Local Account | [PowerSploit](https://attack.mitre.org/software/S0194)'s `Get-ProcessTokenGroup` Privesc-PowerUp module can enumerate all SIDs associated with its current token.[^2] [^1]  |
| [[T1547.005-security_support_provider\|T1547.005]] | Security Support Provider | [PowerSploit](https://attack.mitre.org/software/S0194)'s `Install-SSP` Persistence module can be used to establish by installing a SSP DLL.[^2] [^1]  |
| [[T1057-process_discovery\|T1057]] | Process Discovery | [PowerSploit](https://attack.mitre.org/software/S0194)'s `Get-ProcessTokenPrivilege` Privesc-PowerUp module can enumerate privileges for a given process.[^2] [^1]  |
| [[T1555.004-windows_credential_manager\|T1555.004]] | Windows Credential Manager | [PowerSploit](https://attack.mitre.org/software/S0194) contains a collection of Exfiltration modules that can harvest credentials from Windows vault credential objects.[^2] [^1]  |
| [[T1059.001-powershell\|T1059.001]] | PowerShell | [PowerSploit](https://attack.mitre.org/software/S0194) modules are written in and executed via [PowerShell](https://attack.mitre.org/techniques/T1086).[^2] [^1]  |
| [[T1482-domain_trust_discovery\|T1482]] | Domain Trust Discovery | [PowerSploit](https://attack.mitre.org/software/S0194) has modules such as `Get-NetDomainTrust` and `Get-NetForestTrust` to enumerate domain and forest trusts.[^2] [^1]  |
| [[T1003.001-lsass_memory\|T1003.001]] | LSASS Memory | [PowerSploit](https://attack.mitre.org/software/S0194) contains a collection of Exfiltration modules that can harvest credentials using [Mimikatz](https://attack.mitre.org/software/S0002).[^2] [^1]  |




## References

[^1]: [PowerSploit Documentation](http://powersploit.readthedocs.io)


[^2]: [GitHub PowerSploit May 2012](https://github.com/PowerShellMafia/PowerSploit)


[^3]: [PowerSploit Invoke Kerberoast](https://powersploit.readthedocs.io/en/latest/Recon/Invoke-Kerberoast/)


[^4]: [PowerShellMagazine PowerSploit July 2014](http://www.powershellmagazine.com/2014/07/08/powersploit/)


[^5]: [Harmj0y Kerberoast Nov 2016](https://blog.harmj0y.net/powershell/kerberoasting-without-mimikatz/)


[^6]: [Pentestlab Stored Credentials](https://pentestlab.blog/2017/04/19/stored-credentials/)

