---
aliases: 
    - S0590
    
mitre-attack: https://attack.mitre.org/software/S0590
---

## S0590

[NBTscan](https://attack.mitre.org/software/S0590) is an open source tool that has been used by state groups to conduct internal reconnaissance within a compromised network.[^4] [^3] [^2] [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1033-system_owner_user_discovery\|T1033]] | System Owner／User Discovery | [NBTscan](https://attack.mitre.org/software/S0590) can list active users on the system.[^4] [^3] 	 |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [NBTscan](https://attack.mitre.org/software/S0590) can be used to collect MAC addresses.[^4] [^3] 	 |
| [[T1040-network_sniffing\|T1040]] | Network Sniffing | [NBTscan](https://attack.mitre.org/software/S0590) can dump and print whole packet content.[^4] [^3] 	 |
| [[T1046-network_service_discovery\|T1046]] | Network Service Discovery | [NBTscan](https://attack.mitre.org/software/S0590) can be used to scan IP networks.[^4] [^3]  |
| [[T1018-remote_system_discovery\|T1018]] | Remote System Discovery | [NBTscan](https://attack.mitre.org/software/S0590) can list NetBIOS computer names.[^4] [^3] 	 |




## References

[^1]: [FireEye APT39 Jan 2019](https://www.fireeye.com/blog/threat-research/2019/01/apt39-iranian-cyber-espionage-group-focused-on-personal-information.html)


[^2]: [Symantec Waterbug Jun 2019](https://www.symantec.com/blogs/threat-intelligence/waterbug-espionage-governments)


[^3]: [SecTools nbtscan June 2003](https://sectools.org/tool/nbtscan/)


[^4]: [Debian nbtscan Nov 2019](https://manpages.debian.org/testing/nbtscan/nbtscan.1.en.html)

