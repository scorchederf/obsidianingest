---
aliases: 
    - S0174
    
mitre-attack: https://attack.mitre.org/software/S0174
---

## S0174

Responder is an open source tool used for LLMNR, NBT-NS and MDNS poisoning, with built-in HTTP/SMB/MSSQL/FTP/LDAP rogue authentication server supporting NTLMv1/NTLMv2/LMv2, Extended Security NTLMSSP and Basic HTTP authentication. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1040-network_sniffing\|T1040]] | Network Sniffing | [Responder](https://attack.mitre.org/software/S0174) captures hashes and credentials that are sent to the system after the name services have been poisoned.[^1]  |
| [[T1557.001-name_resolution_poisoning_and_smb_relay\|T1557.001]] | Name Resolution Poisoning and SMB Relay | [Responder](https://attack.mitre.org/software/S0174) is used to poison name services to gather hashes and credentials from systems within a local network.[^1]  |




## References

[^1]: [GitHub Responder](https://github.com/SpiderLabs/Responder)

