---
aliases: 
    - S0357
    
mitre-attack: https://attack.mitre.org/software/S0357
---

## S0357

[Impacket](https://attack.mitre.org/software/S0357) is an open source collection of modules written in Python for programmatically constructing and manipulating network protocols. [Impacket](https://attack.mitre.org/software/S0357) contains several tools for remote service execution, Kerberos manipulation, Windows credential dumping, packet sniffing, and relay attacks.[^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1557.001-name_resolution_poisoning_and_smb_relay\|T1557.001]] | Name Resolution Poisoning and SMB Relay | [Impacket](https://attack.mitre.org/software/S0357) modules like ntlmrelayx and smbrelayx can be used in conjunction with [Network Sniffing](https://attack.mitre.org/techniques/T1040) and [Name Resolution Poisoning and SMB Relay](https://attack.mitre.org/techniques/T1557/001) to gather NetNTLM credentials for [Brute Force](https://attack.mitre.org/techniques/T1110) or relay attacks that can gain code execution.[^2]  |
| [[T1040-network_sniffing\|T1040]] | Network Sniffing | [Impacket](https://attack.mitre.org/software/S0357) can be used to sniff network traffic via an interface or raw socket.[^2]  |
| [[T1558.003-kerberoasting\|T1558.003]] | Kerberoasting | [Impacket](https://attack.mitre.org/software/S0357) modules like GetUserSPNs can be used to get Service Principal Names (SPNs) for user accounts. The output is formatted to be compatible with cracking tools like John the Ripper and Hashcat.[^2]  |
| [[T1558.005-ccache_files\|T1558.005]] | Ccache Files | [Impacket](https://attack.mitre.org/software/S0357) tools – such as `getST.py` or `ticketer.py` – can be used to steal or forge Kerberos tickets using ccache files given a password, hash, aesKey, or TGT.[^3] [^1]  |
| [[T1003.003-ntds\|T1003.003]] | NTDS | SecretsDump and [Mimikatz](https://attack.mitre.org/software/S0002) modules within [Impacket](https://attack.mitre.org/software/S0357) can perform credential dumping to obtain account and password information from NTDS.dit.[^2]  |
| [[T1569.002-service_execution\|T1569.002]] | Service Execution | [Impacket](https://attack.mitre.org/software/S0357) contains various modules emulating other service execution tools such as [PsExec](https://attack.mitre.org/software/S0029).[^2]  |
| [[T1003.001-lsass_memory\|T1003.001]] | LSASS Memory | SecretsDump and [Mimikatz](https://attack.mitre.org/software/S0002) modules within [Impacket](https://attack.mitre.org/software/S0357) can perform credential dumping to obtain account and password information.[^2]  |
| [[T1047-windows_management_instrumentation\|T1047]] | Windows Management Instrumentation | [Impacket](https://attack.mitre.org/software/S0357)'s `wmiexec` module can be used to execute commands through WMI.[^2] [^4]  |
| [[T1003.002-security_account_manager\|T1003.002]] | Security Account Manager | SecretsDump and [Mimikatz](https://attack.mitre.org/software/S0002) modules within [Impacket](https://attack.mitre.org/software/S0357) can perform credential dumping to obtain account and password information.[^2]  |
| [[T1570-lateral_tool_transfer\|T1570]] | Lateral Tool Transfer | [Impacket](https://attack.mitre.org/software/S0357) has used its `wmiexec` command, leveraging Windows Management Instrumentation, to remotely stage and execute payloads in victim networks.[^4]  |
| [[T1003.004-lsa_secrets\|T1003.004]] | LSA Secrets | SecretsDump and [Mimikatz](https://attack.mitre.org/software/S0002) modules within [Impacket](https://attack.mitre.org/software/S0357) can perform credential dumping to obtain account and password information.[^2]  |




## References

[^1]: [on security kerberos linux](https://www.onsecurity.io/blog/abusing-kerberos-from-linux/)


[^2]: [Impacket Tools](https://www.secureauth.com/labs/open-source-tools/impacket)


[^3]: [Kerberos GNU/Linux](https://adepts.of0x.cc/kerberos-thievery-linux/)


[^4]: [Sygnia VelvetAnt 2024A](https://www.sygnia.co/blog/china-nexus-threat-group-velvet-ant/)

