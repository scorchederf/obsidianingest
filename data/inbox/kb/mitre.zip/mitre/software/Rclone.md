---
aliases: 
    - S1040
    
mitre-attack: https://attack.mitre.org/software/S1040
---

## S1040

[Rclone](https://attack.mitre.org/software/S1040) is a command line program for syncing files with cloud storage services such as Dropbox, Google Drive, Amazon S3, and MEGA. [Rclone](https://attack.mitre.org/software/S1040) has been used in a number of ransomware campaigns, including those associated with the [Conti](https://attack.mitre.org/software/S0575) and DarkSide Ransomware-as-a-Service operations.[^3] [^1] [^2] [^4] [^5] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1567.002-exfiltration_to_cloud_storage\|T1567.002]] | Exfiltration to Cloud Storage | [Rclone](https://attack.mitre.org/software/S1040) can exfiltrate data to cloud storage services such as Dropbox, Google Drive, Amazon S3, and MEGA.[^3] [^5]  |
| [[T1083-file_and_directory_discovery\|T1083]] | File and Directory Discovery | [Rclone](https://attack.mitre.org/software/S1040) can list files and directories with the `ls`, `lsd`, and `lsl` commands.[^3]  |
| [[T1030-data_transfer_size_limits\|T1030]] | Data Transfer Size Limits | The [Rclone](https://attack.mitre.org/software/S1040) "chunker" overlay supports splitting large files in smaller chunks during upload to circumvent size limits.[^3] [^5]  |
| [[T1560.001-archive_via_utility\|T1560.001]] | Archive via Utility | [Rclone](https://attack.mitre.org/software/S1040) can compress files using `gzip` prior to exfiltration.[^3]  |
| [[T1048.002-exfiltration_over_asymmetric_encrypted_non_c2_protocol\|T1048.002]] | Exfiltration Over Asymmetric Encrypted Non-C2 Protocol | [Rclone](https://attack.mitre.org/software/S1040) can exfiltrate data over SFTP or HTTPS via WebDAV.[^3]  |
| [[T1048.003-exfiltration_over_unencrypted_non_c2_protocol\|T1048.003]] | Exfiltration Over Unencrypted Non-C2 Protocol | [Rclone](https://attack.mitre.org/software/S1040) can exfiltrate data over FTP or HTTP, including HTTP via WebDAV.[^3]  |




## References

[^1]: [Rclone Wars](https://redcanary.com/blog/rclone-mega-extortion/)


[^2]: [Detecting Rclone](https://research.nccgroup.com/2021/05/27/detecting-rclone-an-effective-tool-for-exfiltration/)


[^3]: [Rclone](https://rclone.org)


[^4]: [DarkSide Ransomware Gang](https://unit42.paloaltonetworks.com/darkside-ransomware/)


[^5]: [DFIR Conti Bazar Nov 2021](https://thedfirreport.com/2021/11/29/continuing-the-bazar-ransomware-story/)

