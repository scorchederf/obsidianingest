---
aliases: 
    - S0005
    
mitre-attack: https://attack.mitre.org/software/S0005
---

## S0005

[Windows Credential Editor](https://attack.mitre.org/software/S0005) is a password dumping tool. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1003.001-lsass_memory\|T1003.001]] | LSASS Memory | [Windows Credential Editor](https://attack.mitre.org/software/S0005) can dump credentials.[^1]  |




## References

[^1]: [Amplia WCE](https://web.archive.org/web/20240904163410/https://www.ampliasecurity.com/research/wcefaq.html)

