---
aliases: 
    - S0029
    
mitre-attack: https://attack.mitre.org/software/S0029
---

## S0029

[PsExec](https://attack.mitre.org/software/S0029) is a free Microsoft tool that can be used to execute a program on another computer. It is used by IT administrators and attackers.[^2] [^4] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1021.002-smb_windows_admin_shares\|T1021.002]] | SMB／Windows Admin Shares | [PsExec](https://attack.mitre.org/software/S0029), a tool that has been used by adversaries, writes programs to the `ADMIN$` network share to execute commands on remote systems.[^3]  |
| [[T1543.003-windows_service\|T1543.003]] | Windows Service | [PsExec](https://attack.mitre.org/software/S0029) can leverage Windows services to escalate privileges from administrator to SYSTEM with the `-s` argument.[^2]  |
| [[T1570-lateral_tool_transfer\|T1570]] | Lateral Tool Transfer | [PsExec](https://attack.mitre.org/software/S0029) can be used to download or upload a file over a network share.[^3]  |
| [[T1569.002-service_execution\|T1569.002]] | Service Execution | Microsoft Sysinternals [PsExec](https://attack.mitre.org/software/S0029) is a popular administration tool that can be used to execute binaries on remote systems using a temporary Windows service.[^2]  |
| [[T1136.002-domain_account\|T1136.002]] | Domain Account | [PsExec](https://attack.mitre.org/software/S0029) has the ability to remotely create accounts on target systems.[^1]  |




## References

[^1]: [NCC Group Fivehands June 2021](https://research.nccgroup.com/2021/06/15/handy-guide-to-a-new-fivehands-ransomware-variant/)


[^2]: [Russinovich Sysinternals](https://technet.microsoft.com/en-us/sysinternals/bb897553.aspx)


[^3]: [PsExec Russinovich](http://windowsitpro.com/systems-management/psexec)


[^4]: [SANS PsExec](https://www.sans.org/blog/protecting-privileged-domain-accounts-psexec-deep-dive/)

