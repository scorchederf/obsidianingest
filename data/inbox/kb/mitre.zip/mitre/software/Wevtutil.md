---
aliases: 
    - S0645
    
mitre-attack: https://attack.mitre.org/software/S0645
---

## S0645

[Wevtutil](https://attack.mitre.org/software/S0645) is a Windows command-line utility that enables administrators to retrieve information about event logs and publishers.[^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1685.001-disable_or_modify_windows_event_log\|T1685.001]] | Disable or Modify Windows Event Log | [Wevtutil](https://attack.mitre.org/software/S0645) can be used to disable specific event logs on the system.[^2]  |
| [[T1005-data_from_local_system\|T1005]] | Data from Local System | [Wevtutil](https://attack.mitre.org/software/S0645) can be used to export events from a specific log.[^2] [^1]  |
| [[T1685.005-clear_windows_event_logs\|T1685.005]] | Clear Windows Event Logs | [Wevtutil](https://attack.mitre.org/software/S0645) can be used to clear system and security event logs from the system.[^2] [^3]  |




## References

[^1]: [F-Secure Lazarus Cryptocurrency Aug 2020](https://web.archive.org/web/20200901113617/https://labs.f-secure.com/assets/BlogFiles/f-secureLABS-tlp-white-lazarus-threat-intel-report2.pdf)


[^2]: [Wevtutil Microsoft Documentation](https://docs.microsoft.com/en-us/windows-server/administration/windows-commands/wevtutil)


[^3]: [Crowdstrike DNC June 2016](https://www.crowdstrike.com/blog/bears-midst-intrusion-democratic-national-committee/)

