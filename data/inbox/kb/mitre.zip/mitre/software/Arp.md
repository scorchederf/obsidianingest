---
aliases: 
    - S0099
    
mitre-attack: https://attack.mitre.org/software/S0099
---

## S0099

[Arp](https://attack.mitre.org/software/S0099) displays and modifies information about a system's Address Resolution Protocol (ARP) cache. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1018-remote_system_discovery\|T1018]] | Remote System Discovery | [Arp](https://attack.mitre.org/software/S0099) can be used to display a host's ARP cache, which may include address resolutions for remote systems.[^1] [^2]  |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [Arp](https://attack.mitre.org/software/S0099) can be used to display ARP configuration information on the host.[^1]  |




## References

[^1]: [TechNet Arp](https://technet.microsoft.com/en-us/library/bb490864.aspx)


[^2]: [Palo Alto ARP](https://docs.paloaltonetworks.com/cortex/cortex-xdr/cortex-xdr-analytics-alert-reference/cortex-xdr-analytics-alert-reference/uncommon-arp-cache-listing-via-arp-exe.html)

