---
aliases: 
    - S9017
    
mitre-attack: https://attack.mitre.org/software/S9017
---

## S9017

[DCRAT](https://attack.mitre.org/software/S9017) is a variant of the open-source [AsyncRAT](https://attack.mitre.org/software/S1087) developed in C# with additional capabilities such as patching Microsoft’s Antimalware Scan Interface (AMSI).[^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1573.002-asymmetric_cryptography\|T1573.002]] | Asymmetric Cryptography | [DCRAT](https://attack.mitre.org/software/S9017) can use certificate-based authentication for C2 servers.[^1] <br> |
| [[T1056.001-keylogging\|T1056.001]] | Keylogging | [DCRAT](https://attack.mitre.org/software/S9017) can log keystrokes on targeted systems.[^1]  |
| [[T1027.013-encrypted_encoded_file\|T1027.013]] | Encrypted／Encoded File | The [DCRAT](https://attack.mitre.org/software/S9017) configuration file is encrypted using AES-256.[^1]  |
| [[T1685-disable_or_modify_tools\|T1685]] | Disable or Modify Tools | [DCRAT](https://attack.mitre.org/software/S9017) can patch Microsoft’s Antimalware Scan Interface (AMSI) to evade detection.[^1]  |




## References

[^1]: [Zscaler BlindEagle DEC 2025](https://www.zscaler.com/blogs/security-research/blindeagle-targets-colombian-government-agency-caminho-and-dcrat)

