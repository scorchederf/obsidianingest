---
aliases: 
    - S0123
    
mitre-attack: https://attack.mitre.org/software/S0123
---

## S0123

[xCmd](https://attack.mitre.org/software/S0123) is an open source tool that is similar to [PsExec](https://attack.mitre.org/software/S0029) and allows the user to execute applications on remote systems. [^1] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1569.002-service_execution\|T1569.002]] | Service Execution | [xCmd](https://attack.mitre.org/software/S0123) can be used to execute binaries on remote systems by creating and starting a service.[^1]  |




## References

[^1]: [xCmd](https://ashwinrayaprolu.wordpress.com/2011/04/12/xcmd-an-alternative-to-psexec/)

