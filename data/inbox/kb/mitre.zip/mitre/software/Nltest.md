---
aliases: 
    - S0359
    
mitre-attack: https://attack.mitre.org/software/S0359
---

## S0359

[Nltest](https://attack.mitre.org/software/S0359) is a Windows command-line utility used to list domain controllers and enumerate domain trusts.[^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1482-domain_trust_discovery\|T1482]] | Domain Trust Discovery | [Nltest](https://attack.mitre.org/software/S0359) may be used to enumerate trusted domains by using commands such as `nltest /domain_trusts`.[^2] [^1]  |
| [[T1018-remote_system_discovery\|T1018]] | Remote System Discovery | [Nltest](https://attack.mitre.org/software/S0359) may be used to enumerate remote domain controllers using options such as `/dclist` and `/dsgetdc`.[^2]  |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [Nltest](https://attack.mitre.org/software/S0359) may be used to enumerate the parent domain of a local machine using `/parentdomain`.[^2]  |




## References

[^1]: [Fortinet TrickBot](https://www.fortinet.com/blog/threat-research/trickbot-s-new-reconnaissance-plugin.html)


[^2]: [Nltest Manual](https://ss64.com/nt/nltest.html)

