---
aliases: 
    - S0250
    
mitre-attack: https://attack.mitre.org/software/S0250
---

## S0250

[Koadic](https://attack.mitre.org/software/S0250) is a Windows post-exploitation framework and penetration testing tool that is publicly available on GitHub. [Koadic](https://attack.mitre.org/software/S0250) has several options for staging payloads and creating implants, and performs most of its operations using Windows Script Host.[^2] [^4] [^3] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [Koadic](https://attack.mitre.org/software/S0250) can retrieve the contents of the IP routing table as well as information about the Windows domain.[^2] [^3]  |
| [[T1082-system_information_discovery\|T1082]] | System Information Discovery | [Koadic](https://attack.mitre.org/software/S0250) can obtain the OS version and build, computer name, and processor architecture from a compromised host.[^3]  |
| [[T1059.005-visual_basic\|T1059.005]] | Visual Basic | [Koadic](https://attack.mitre.org/software/S0250) performs most of its operations using Windows Script Host (VBScript) and runs arbitrary shellcode .[^2]  |
| [[T1218.005-mshta\|T1218.005]] | Mshta | [Koadic](https://attack.mitre.org/software/S0250) can use mshta to serve additional payloads and to help schedule tasks for persistence.[^2] [^3]   |
| [[T1055.001-dynamic_link_library_injection\|T1055.001]] | Dynamic-link Library Injection | [Koadic](https://attack.mitre.org/software/S0250) can perform process injection by using a reflective DLL.[^2]  |
| [[T1218.010-regsvr32\|T1218.010]] | Regsvr32 | [Koadic](https://attack.mitre.org/software/S0250) can use Regsvr32 to execute additional payloads.[^2]  |
| [[T1033-system_owner_user_discovery\|T1033]] | System Owner／User Discovery | [Koadic](https://attack.mitre.org/software/S0250) can identify logged in users across the domain and views user sessions.[^2] [^3]  |
| [[T1564.003-hidden_window\|T1564.003]] | Hidden Window | [Koadic](https://attack.mitre.org/software/S0250) has used the command `Powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden` to hide its window.[^3]  |
| [[T1003.002-security_account_manager\|T1003.002]] | Security Account Manager | [Koadic](https://attack.mitre.org/software/S0250) can gather hashed passwords by dumping SAM/SECURITY hive.[^2]  |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [Koadic](https://attack.mitre.org/software/S0250) can download additional files and tools.[^2] [^3]  |
| [[T1071.001-web_protocols\|T1071.001]] | Web Protocols | [Koadic](https://attack.mitre.org/software/S0250) has used HTTP for C2 communications.[^3]  |
| [[T1047-windows_management_instrumentation\|T1047]] | Windows Management Instrumentation | [Koadic](https://attack.mitre.org/software/S0250) can use WMI to execute commands.[^2]  |
| [[T1059.001-powershell\|T1059.001]] | PowerShell | [Koadic](https://attack.mitre.org/software/S0250) has used PowerShell to establish persistence.[^3]   |
| [[T1115-clipboard_data\|T1115]] | Clipboard Data | [Koadic](https://attack.mitre.org/software/S0250) can retrieve the current content of the user clipboard.[^2]  |
| [[T1548.002-bypass_user_account_control\|T1548.002]] | Bypass User Account Control | [Koadic](https://attack.mitre.org/software/S0250) has 2 methods for elevating integrity. It can bypass UAC through `eventvwr.exe` and `sdclt.exe`.[^2]  |
| [[T1046-network_service_discovery\|T1046]] | Network Service Discovery | [Koadic](https://attack.mitre.org/software/S0250) can scan for open TCP ports on the target network.[^2]  |
| [[T1021.001-remote_desktop_protocol\|T1021.001]] | Remote Desktop Protocol | [Koadic](https://attack.mitre.org/software/S0250) can enable remote desktop on the victim's machine.[^2]  |
| [[T1059.003-windows_command_shell\|T1059.003]] | Windows Command Shell | [Koadic](https://attack.mitre.org/software/S0250) can open an interactive command-shell to perform command line functions on victim machines. [Koadic](https://attack.mitre.org/software/S0250) performs most of its operations using Windows Script Host (Jscript) and to run arbitrary shellcode.[^2] [^3]  |
| [[T1083-file_and_directory_discovery\|T1083]] | File and Directory Discovery | [Koadic](https://attack.mitre.org/software/S0250) can obtain a list of directories.[^3]  |
| [[T1547.001-registry_run_keys_startup_folder\|T1547.001]] | Registry Run Keys ／ Startup Folder | [Koadic](https://attack.mitre.org/software/S0250) has added persistence to the `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run` Registry key.[^3]  |
| [[T1003.003-ntds\|T1003.003]] | NTDS | [Koadic](https://attack.mitre.org/software/S0250) can gather hashed passwords by gathering domain controller hashes from NTDS.[^2]  |
| [[T1569.002-service_execution\|T1569.002]] | Service Execution | [Koadic](https://attack.mitre.org/software/S0250) can run a command on another machine using [PsExec](https://attack.mitre.org/software/S0029).[^2]  |
| [[T1005-data_from_local_system\|T1005]] | Data from Local System | [Koadic](https://attack.mitre.org/software/S0250) can download files off the target system to send back to the server.[^2] [^3]  |
| [[T1573.002-asymmetric_cryptography\|T1573.002]] | Asymmetric Cryptography | [Koadic](https://attack.mitre.org/software/S0250) can use SSL and TLS for communications.[^2]  |
| [[T1135-network_share_discovery\|T1135]] | Network Share Discovery | [Koadic](https://attack.mitre.org/software/S0250) can scan local network for open SMB.[^2]  |
| [[T1218.011-rundll32\|T1218.011]] | Rundll32 | [Koadic](https://attack.mitre.org/software/S0250) can use Rundll32 to execute additional payloads.[^2]  |
| [[T1053.005-scheduled_task\|T1053.005]] | Scheduled Task | [Koadic](https://attack.mitre.org/software/S0250) has used scheduled tasks to add persistence.[^3]   |




## References

[^1]: Koadic


[^2]: [Github Koadic](https://github.com/offsecginger/koadic)


[^3]: [MalwareBytes LazyScripter Feb 2021](https://web.archive.org/web/20211003035156/https://www.malwarebytes.com/resources/files/2021/02/lazyscripter.pdf)


[^4]: [Palo Alto Sofacy 06-2018](https://researchcenter.paloaltonetworks.com/2018/06/unit42-sofacy-groups-parallel-attacks/)

