---
aliases: 
    - S1087
    
mitre-attack: https://attack.mitre.org/software/S1087
---

## S1087

[AsyncRAT](https://attack.mitre.org/software/S1087) is an open-source remote access tool originally available through the NYANxCAT Github repository that has been used in malicious campaigns.[^4] [^1] [^3] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1622-debugger_evasion\|T1622]] | Debugger Evasion | [AsyncRAT](https://attack.mitre.org/software/S1087) can use the `CheckRemoteDebuggerPresent` function to detect the presence of a debugger.[^3]  |
| [[T1059.003-windows_command_shell\|T1059.003]] | Windows Command Shell | [AsyncRAT](https://attack.mitre.org/software/S1087) can be deployed via batch script.[^5]  |
| [[T1106-native_api\|T1106]] | Native API | [AsyncRAT](https://attack.mitre.org/software/S1087) has the ability to use OS APIs including `CheckRemoteDebuggerPresent`.[^3]  |
| [[T1124-system_time_discovery\|T1124]] | System Time Discovery | [AsyncRAT](https://attack.mitre.org/software/S1087) can check whether the current system hour and day of the week are within operating hours defined it its configuration.[^5]  |
| [[T1568.002-domain_generation_algorithms\|T1568.002]] | Domain Generation Algorithms | [AsyncRAT](https://attack.mitre.org/software/S1087) use a DGA to generate a C2 domains.[^5]  |
| [[T1090.003-multi_hop_proxy\|T1090.003]] | Multi-hop Proxy | [AsyncRAT](https://attack.mitre.org/software/S1087) can proxy C2 through a [Tor](https://attack.mitre.org/software/S0183) client.[^5]  |
| [[T1680-local_storage_discovery\|T1680]] | Local Storage Discovery | [AsyncRAT](https://attack.mitre.org/software/S1087) can check the disk size through the values obtained with `DeviceInfo.`[^3]  |
| [[T1033-system_owner_user_discovery\|T1033]] | System Owner／User Discovery | [AsyncRAT](https://attack.mitre.org/software/S1087) can check if the current user of a compromised system is an administrator. [^3]  |
| [[T1566.001-spearphishing_attachment\|T1566.001]] | Spearphishing Attachment | [AsyncRAT](https://attack.mitre.org/software/S1087) has been delivered via malicious email attachments.[^6]  |
| [[T1568-dynamic_resolution\|T1568]] | Dynamic Resolution | [AsyncRAT](https://attack.mitre.org/software/S1087) can be configured to use dynamic DNS.[^2]  |
| [[T1564.003-hidden_window\|T1564.003]] | Hidden Window | <br>[AsyncRAT](https://attack.mitre.org/software/S1087) can hide the execution of scheduled tasks using `ProcessWindowStyle.Hidden`.[^3]  |
| [[T1497.001-system_checks\|T1497.001]] | System Checks | [AsyncRAT](https://attack.mitre.org/software/S1087) can identify strings such as Virtual, vmware, or VirtualBox to detect virtualized environments.[^3]  |
| [[T1125-video_capture\|T1125]] | Video Capture | [AsyncRAT](https://attack.mitre.org/software/S1087) can record screen content on targeted systems.[^2]  |
| [[T1105-ingress_tool_transfer\|T1105]] | Ingress Tool Transfer | [AsyncRAT](https://attack.mitre.org/software/S1087) has the ability to download files including over SFTP.[^2] [^5]  |
| [[T1204.002-malicious_file\|T1204.002]] | Malicious File | [AsyncRAT](https://attack.mitre.org/software/S1087) has been executed through victims opening malicious file attachments.[^6]  |
| [[T1057-process_discovery\|T1057]] | Process Discovery | [AsyncRAT](https://attack.mitre.org/software/S1087) can examine running processes to determine if a debugger is present.[^3]  |
| [[T1016-system_network_configuration_discovery\|T1016]] | System Network Configuration Discovery | [AsyncRAT](https://attack.mitre.org/software/S1087) can enumerate the NetBIOS name on targeted machines.[^5]  |
| [[T1113-screen_capture\|T1113]] | Screen Capture | [AsyncRAT](https://attack.mitre.org/software/S1087) has the ability to view the screen on compromised hosts.[^2]  |
| [[T1056.001-keylogging\|T1056.001]] | Keylogging | [AsyncRAT](https://attack.mitre.org/software/S1087) can capture keystrokes on the victim’s machine.[^2]  |
| [[T1053.005-scheduled_task\|T1053.005]] | Scheduled Task | [AsyncRAT](https://attack.mitre.org/software/S1087) can create a scheduled task to maintain persistence on system start-up.[^3]  |




## References

[^1]: [Cisco Operation Layover September 2021](https://blog.talosintelligence.com/operation-layover-how-we-tracked-attack/)


[^2]: [AsyncRAT GitHub](https://github.com/NYAN-x-CAT/AsyncRAT-C-Sharp/blob/master/README.md)


[^3]: [Telefonica Snip3 December 2021](https://telefonicatech.com/blog/snip3-investigacion-malware)


[^4]: [Morphisec Snip3 May 2021](https://blog.morphisec.com/revealing-the-snip3-crypter-a-highly-evasive-rat-loader)


[^5]: [ESET MirrorFace 2025](https://www.welivesecurity.com/en/eset-research/operation-akairyu-mirrorface-invites-europe-expo-2025-revives-anel-backdoor/)


[^6]: [Recorded Future TAG-144 AUG 2025](https://assets.recordedfuture.com/insikt-report-pdfs/2025/cta-2025-0826.pdf)

