---
aliases: 
    - S0358
    
mitre-attack: https://attack.mitre.org/software/S0358
---

## S0358

[Ruler](https://attack.mitre.org/software/S0358) is a tool to abuse Microsoft Exchange services. It is publicly available on GitHub and the tool is executed via the command line. The creators of [Ruler](https://attack.mitre.org/software/S0358) have also released a defensive tool, NotRuler, to detect its usage.[^1] [^2] 

### Techniques Used
| ID | Name | Use |
| --- | --- | --- |
| [[T1137.005-outlook_rules\|T1137.005]] | Outlook Rules | [Ruler](https://attack.mitre.org/software/S0358) can be used to automate the abuse of Outlook Rules to establish persistence.[^1]   |
| [[T1137.003-outlook_forms\|T1137.003]] | Outlook Forms | [Ruler](https://attack.mitre.org/software/S0358) can be used to automate the abuse of Outlook Forms to establish persistence.[^1]  |
| [[T1137.004-outlook_home_page\|T1137.004]] | Outlook Home Page | [Ruler](https://attack.mitre.org/software/S0358) can be used to automate the abuse of Outlook Home Pages to establish persistence.[^1]   |
| [[T1087.003-email_account\|T1087.003]] | Email Account | [Ruler](https://attack.mitre.org/software/S0358) can be used to enumerate Exchange users and dump the GAL.[^1]  |




## References

[^1]: [SensePost Ruler GitHub](https://github.com/sensepost/ruler)


[^2]: [SensePost NotRuler](https://github.com/sensepost/notruler)

