---
aliases: 
    - M1028
    
mitre-attack: https://attack.mitre.org/mitigations/M1028
---

## M1028

Operating System Configuration involves adjusting system settings and hardening the default configurations of an operating system (OS) to mitigate adversary exploitation and prevent abuse of system functionality. Proper OS configurations address security vulnerabilities, limit attack surfaces, and ensure robust defense against a wide range of techniques. This mitigation can be implemented through the following measures: <br><br>Disable Unused Features:<br><br>- Turn off SMBv1, LLMNR, and NetBIOS where not needed.<br>- Disable remote registry and unnecessary services.<br><br>Enforce OS-level Protections:<br><br>- Enable Data Execution Prevention (DEP), Address Space Layout Randomization (ASLR), and Control Flow Guard (CFG) on Windows.<br>- Use AppArmor or SELinux on Linux for mandatory access controls.<br><br>Secure Access Settings:<br><br>- Enable User Account Control (UAC) for Windows.<br>- Restrict root/sudo access on Linux/macOS and enforce strong permissions using sudoers files.<br><br>File System Hardening:<br><br>- Implement least-privilege access for critical files and system directories.<br>- Audit permissions regularly using tools like icacls (Windows) or getfacl/chmod (Linux/macOS).<br><br>Secure Remote Access:<br><br>- Restrict RDP, SSH, and VNC to authorized IPs using firewall rules.<br>- Enable NLA for RDP and enforce strong password/lockout policies.<br><br>Harden Boot Configurations:<br><br>- Enable Secure Boot and enforce UEFI/BIOS password protection.<br>- Use BitLocker or LUKS to encrypt boot drives.<br><br>Regular Audits:<br><br>- Periodically audit OS configurations using tools like CIS Benchmarks or SCAP tools.<br><br>*Tools for Implementation*<br><br>Windows:<br><br>- Microsoft Group Policy Objects (GPO): Centrally enforce OS security settings.<br>- Windows Defender Exploit Guard: Built-in OS protection against exploits.<br>- CIS-CAT Pro: Audit Windows security configurations based on CIS Benchmarks.<br><br>Linux/macOS:<br><br>- AppArmor/SELinux: Enforce mandatory access controls.<br>- Lynis: Perform comprehensive security audits.<br>- SCAP Security Guide: Automate configuration hardening using Security Content Automation Protocol.<br><br>Cross-Platform:<br><br>- Ansible or Chef/Puppet: Automate configuration hardening at scale.<br>- OpenSCAP: Perform compliance and configuration checks.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1574.006-dynamic_linker_hijacking\|T1574.006]] | [[T1574.006-dynamic_linker_hijacking\|Dynamic Linker Hijacking]] | When System Integrity Protection (SIP) is enabled in macOS, the aforementioned environment variables are ignored when executing protected binaries. Third-party applications can also leverage Apple’s Hardened Runtime, ensuring these environment variables are subject to imposed restrictions.[^10]  Admins can add restrictions to applications by setting the setuid and/or setgid bits, use entitlements, or have a __RESTRICT segment in the Mach-O binary. |
| [[T1087.001-local_account\|T1087.001]] | [[T1087.001-local_account\|Local Account]] | Prevent administrator accounts from being enumerated when an application is elevating through UAC since it can lead to the disclosure of account names. The Registry key is located at `HKLM\ SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\CredUI\EnumerateAdministrators`. It can be disabled through GPO: Computer Configuration > [Policies] > Administrative Templates > Windows Components > Credential User Interface: Enumerate administrator accounts on elevation.[^9]  |
| [[T1553-subvert_trust_controls\|T1553]] | [[T1553-subvert_trust_controls\|Subvert Trust Controls]] | Windows Group Policy can be used to manage root certificates and the `Flags` value of `HKLM\\SOFTWARE\\Policies\\Microsoft\\SystemCertificates\\Root\\ProtectedRoots` can be set to 1 to prevent non-administrator users from making further root installations into their own HKCU certificate store. [^18]  |
| [[T1053.002-at\|T1053.002]] | [[T1053.002-at\|At]] | Configure settings for scheduled tasks to force tasks to run under the context of the authenticated account instead of allowing them to run as SYSTEM. The associated Registry key is located at `HKLM\SYSTEM\CurrentControlSet\Control\Lsa\SubmitControl`. The setting can be configured through GPO: Computer Configuration > [Policies] > Windows Settings > Security Settings > Local Policies > Security Options: Domain Controller: Allow server operators to schedule tasks, set to disabled. [^8]   |
| [[T1543.003-windows_service\|T1543.003]] | [[T1543.003-windows_service\|Windows Service]] | Ensure that Driver Signature Enforcement is enabled to restrict unsigned drivers from being installed.  |
| [[T1548.001-setuid_and_setgid\|T1548.001]] | [[T1548.001-setuid_and_setgid\|Setuid and Setgid]] | Applications with known vulnerabilities or known shell escapes should not have the setuid or setgid bits set to reduce potential damage if an application is compromised. Additionally, the number of programs with setuid or setgid bits set should be minimized across a system. |
| [[T1542.005-tftp_boot\|T1542.005]] | [[T1542.005-tftp_boot\|TFTP Boot]] | Follow vendor device hardening best practices to disable unnecessary and unused features and services, avoid using default configurations and passwords, and introduce logging and auditing for detection. |
| [[T1021.001-remote_desktop_protocol\|T1021.001]] | [[T1021.001-remote_desktop_protocol\|Remote Desktop Protocol]] | Change GPOs to define shorter timeouts sessions and maximum amount of time any single session can be active. Change GPOs to specify the maximum amount of time that a disconnected session stays active on the RD session host server.[^2]  |
| [[T1003.001-lsass_memory\|T1003.001]] | [[T1003.001-lsass_memory\|LSASS Memory]] | Consider disabling or restricting NTLM.[^16]  Consider disabling WDigest authentication.[^4]  |
| [[T1552-unsecured_credentials\|T1552]] | [[T1552-unsecured_credentials\|Unsecured Credentials]] | There are multiple methods of preventing a user's command history from being flushed to their .bash_history file, including use of the following commands:<br>`set +o history` and `set -o history` to start logging again;<br>`unset HISTFILE` being added to a user's .bash_rc file; and<br>`ln -s /dev/null ~/.bash_history` to write commands to `/dev/null`instead. |
| [[T1548-abuse_elevation_control_mechanism\|T1548]] | [[T1548-abuse_elevation_control_mechanism\|Abuse Elevation Control Mechanism]] | Applications with known vulnerabilities or known shell escapes should not have the setuid or setgid bits set to reduce potential damage if an application is compromised. Additionally, the number of programs with setuid or setgid bits set should be minimized across a system. Ensuring that the sudo tty_tickets setting is enabled will prevent this leakage across tty sessions. |
| [[T1197-bits_jobs\|T1197]] | [[T1197-bits_jobs\|BITS Jobs]] | <br>Consider reducing the default BITS job lifetime in Group Policy or by editing the `JobInactivityTimeout` and `MaxDownloadTime` Registry values in ` HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\BITS`.[^6]  |
| [[T1563.002-rdp_hijacking\|T1563.002]] | [[T1563.002-rdp_hijacking\|RDP Hijacking]] | Change GPOs to define shorter timeouts sessions and maximum amount of time any single session can be active. Change GPOs to specify the maximum amount of time that a disconnected session stays active on the RD session host server.[^2]  |
| [[T1543-create_or_modify_system_process\|T1543]] | [[T1543-create_or_modify_system_process\|Create or Modify System Process]] | Ensure that Driver Signature Enforcement is enabled to restrict unsigned drivers from being installed.  |
| [[T1087-account_discovery\|T1087]] | [[T1087-account_discovery\|Account Discovery]] | Prevent administrator accounts from being enumerated when an application is elevating through UAC since it can lead to the disclosure of account names. The Registry key is located `HKLM\ SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\CredUI\EnumerateAdministrators`. It can be disabled through GPO: Computer Configuration > [Policies] > Administrative Templates > Windows Components > Credential User Interface: E numerate administrator accounts on elevation. [^9]  |
| [[T1053-scheduled_task_job\|T1053]] | [[T1053-scheduled_task_job\|Scheduled Task／Job]] | Configure settings for scheduled tasks to force tasks to run under the context of the authenticated account instead of allowing them to run as SYSTEM. The associated Registry key is located at `HKLM\SYSTEM\CurrentControlSet\Control\Lsa\SubmitControl`. The setting can be configured through GPO: Computer Configuration > [Policies] > Windows Settings > Security Settings > Local Policies > Security Options: Domain Controller: Allow server operators to schedule tasks, set to disabled. [^8]  |
| [[T1136-create_account\|T1136]] | [[T1136-create_account\|Create Account]] | Protect domain controllers by ensuring proper security configuration for critical servers. |
| [[T1011-exfiltration_over_other_network_medium\|T1011]] | [[T1011-exfiltration_over_other_network_medium\|Exfiltration Over Other Network Medium]] | Prevent the creation of new network adapters where possible.[^5] [^17]  |
| [[T1556.002-password_filter_dll\|T1556.002]] | [[T1556.002-password_filter_dll\|Password Filter DLL]] | Ensure only valid password filters are registered. Filter DLLs must be present in Windows installation directory (C:\Windows\System32\ by default) of a domain controller and/or local computer with a corresponding entry in HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa\Notification Packages. |
| [[T1087.002-domain_account\|T1087.002]] | [[T1087.002-domain_account\|Domain Account]] | Prevent administrator accounts from being enumerated when an application is elevating through UAC since it can lead to the disclosure of account names. The Registry key is located at `HKLM\ SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\CredUI\EnumerateAdministrators`. It can be disabled through GPO: Computer Configuration > [Policies] > Administrative Templates > Windows Components > Credential User Interface: Enumerate administrator accounts on elevation.[^9]  |
| [[T1003.005-cached_domain_credentials\|T1003.005]] | [[T1003.005-cached_domain_credentials\|Cached Domain Credentials]] | Consider limiting the number of cached credentials (HKLM\SOFTWARE\Microsoft\Windows NT\Current Version\Winlogon\cachedlogonscountvalue)[^15]  |
| [[T1564.002-hidden_users\|T1564.002]] | [[T1564.002-hidden_users\|Hidden Users]] | If the computer is domain joined, then group policy can help restrict the ability to create or hide users. Similarly, preventing the modification of the `/Library/Preferences/com.apple.loginwindow` `Hide500Users` value will force all users to be visible. |
| [[T1552.003-shell_history\|T1552.003]] | [[T1552.003-shell_history\|Shell History]] | There are multiple methods of preventing a user's command history from being flushed to their .bash_history file, including use of the following commands:<br>`set +o history` and `set -o history` to start logging again;<br>`unset HISTFILE` being added to a user's .bash_rc file; and<br>`ln -s /dev/null ~/.bash_history` to write commands to `/dev/null` instead.<br><br>In Zsh, `fc -p` can be used to create a private history session. However, previous history will be unavailable to the user until the session ends. Using `unset HISTFILE` and writing commands to `/dev/null` can also be used, similarly to Bash.<br><br>In PowerShell, users can utilize `Set-PSReadLineOption` to modify how commands are saved into history. Setting `-HistorySaveStyle SaveNothing` prevents command history from being saved onto the file. Note that setting it from `SaveNothing` to `SaveIncrementally` in the same session will cause all commands from that session to be saved. Alternatively, `-AddToHistoryHandler` can be used to filter certain commands from being saved into the history file. |
| [[T1135-network_share_discovery\|T1135]] | [[T1135-network_share_discovery\|Network Share Discovery]] | Enable Windows Group Policy “Do Not Allow Anonymous Enumeration of SAM Accounts and Shares” security setting to limit users who can enumerate network shares.[^1]  |
| [[T1553.004-install_root_certificate\|T1553.004]] | [[T1553.004-install_root_certificate\|Install Root Certificate]] | Windows Group Policy can be used to manage root certificates and the `Flags` value of `HKLM\\SOFTWARE\\Policies\\Microsoft\\SystemCertificates\\Root\\ProtectedRoots` can be set to 1 to prevent non-administrator users from making further root installations into their own HKCU certificate store. [^18]  |
| [[T1003.002-security_account_manager\|T1003.002]] | [[T1003.002-security_account_manager\|Security Account Manager]] | Consider disabling or restricting NTLM.[^16]  |
| [[T1548.003-sudo_and_sudo_caching\|T1548.003]] | [[T1548.003-sudo_and_sudo_caching\|Sudo and Sudo Caching]] | Ensuring that the `tty_tickets` setting is enabled will prevent this leakage across tty sessions. |
| [[T1136.002-domain_account\|T1136.002]] | [[T1136.002-domain_account\|Domain Account]] | Protect domain controllers by ensuring proper security configuration for critical servers. |
| [[T1092-communication_through_removable_media\|T1092]] | [[T1092-communication_through_removable_media\|Communication Through Removable Media]] | Disallow or restrict removable media at an organizational policy level if they are not required for business operations.[^3]  |
| [[T1490-inhibit_system_recovery\|T1490]] | [[T1490-inhibit_system_recovery\|Inhibit System Recovery]] | Consider technical controls to prevent the disabling of services or deletion of files involved in system recovery. Additionally, ensure that WinRE is enabled using the following command: `reagentc /enable`.[^13]  |
| [[T1011.001-exfiltration_over_bluetooth\|T1011.001]] | [[T1011.001-exfiltration_over_bluetooth\|Exfiltration Over Bluetooth]] | Prevent the creation of new network adapters where possible. |
| [[T1036.007-double_file_extension\|T1036.007]] | [[T1036.007-double_file_extension\|Double File Extension]] | Disable the default to “hide file extensions for known file types” in Windows OS.[^11] [^14]  |
| [[T1546.008-accessibility_features\|T1546.008]] | [[T1546.008-accessibility_features\|Accessibility Features]] | To use this technique remotely, an adversary must use it in conjunction with RDP. Ensure that Network Level Authentication is enabled to force the remote desktop session to authenticate before the session is created and the login screen displayed. It is enabled by default on Windows Vista and later.[^12]  |
| [[T1690-prevent_command_history_logging\|T1690]] | [[T1690-prevent_command_history_logging\|Prevent Command History Logging]] | Make sure that the `HISTCONTROL` environment variable is set to “ignoredups” instead of “ignoreboth” or “ignorespace”. |
| [[T1053.005-scheduled_task\|T1053.005]] | [[T1053.005-scheduled_task\|Scheduled Task]] | Configure settings for scheduled tasks to force tasks to run under the context of the authenticated account instead of allowing them to run as SYSTEM. The associated Registry key is located at HKLM\SYSTEM\CurrentControlSet\Control\Lsa\SubmitControl. The setting can be configured through GPO: Computer Configuration > [Policies] > Windows Settings > Security Settings > Local Policies > Security Options: Domain Controller: Allow server operators to schedule tasks, set to disabled. [^8]  |
| [[T1556.008-network_provider_dll\|T1556.008]] | [[T1556.008-network_provider_dll\|Network Provider DLL]] | Starting in Windows 11 22H2, the `EnableMPRNotifications` policy can be disabled through Group Policy or through a configuration service provider to prevent Winlogon from sending credentials to network providers.[^7]  |
| [[T1556-modify_authentication_process\|T1556]] | [[T1556-modify_authentication_process\|Modify Authentication Process]] | Ensure only valid password filters are registered. Filter DLLs must be present in Windows installation directory (`C:\Windows\System32\` by default) of a domain controller and/or local computer with a corresponding entry in `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa\Notification Packages`. <br><br>Starting in Windows 11 22H2, the `EnableMPRNotifications` policy can be disabled through Group Policy or through a configuration service provider to prevent Winlogon from sending credentials to network providers.[^7]  |
| [[T1003-os_credential_dumping\|T1003]] | [[T1003-os_credential_dumping\|OS Credential Dumping]] | <br>Consider disabling or restricting NTLM.[^16]  Consider disabling WDigest authentication.[^4]  |
| [[T1098-account_manipulation\|T1098]] | [[T1098-account_manipulation\|Account Manipulation]] | Protect domain controllers by ensuring proper security configuration for critical servers to limit access by potentially unnecessary protocols and services, such as SMB file sharing. |


## References

[^1]: [Windows Anonymous Enumeration of SAM Accounts](https://docs.microsoft.com/en-us/windows/security/threat-protection/security-policy-settings/network-access-do-not-allow-anonymous-enumeration-of-sam-accounts-and-shares)


[^2]: [Windows RDP Sessions](https://technet.microsoft.com/en-us/library/cc754272(v=ws.11).aspx)


[^3]: [TechNet Removable Media Control](https://technet.microsoft.com/en-us/library/cc772540(v=ws.10).aspx)


[^4]: [Microsoft WDigest Mit](https://support.microsoft.com/en-us/help/2871997/microsoft-security-advisory-update-to-improve-credentials-protection-a)


[^5]: [Microsoft GPO Bluetooth FEB 2009](https://technet.microsoft.com/library/dd252791.aspx)


[^6]: [Microsoft BITS](https://msdn.microsoft.com/library/windows/desktop/bb968799.aspx)


[^7]: [EnableMPRNotifications](https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-windowslogon)


[^8]: [TechNet Server Operator Scheduled Task](https://technet.microsoft.com/library/jj852168.aspx)


[^9]: [UCF STIG Elevation Account Enumeration](https://www.stigviewer.com/stig/microsoft_windows_server_2012_member_server/2013-07-25/finding/WN12-CC-000077)


[^10]: [Apple Developer Doco Hardened Runtime](https://developer.apple.com/documentation/security/hardened_runtime)


[^11]: [Seqrite DoubleExtension](https://www.seqrite.com/blog/how-to-avoid-dual-attack-and-vulnerable-files-with-double-extension/)


[^12]: [TechNet RDP NLA](https://technet.microsoft.com/en-us/library/cc732713.aspx)


[^13]: [reagentc_cmd](https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/reagentc-command-line-options?view=windows-11)


[^14]: [HowToGeek ShowExtension](https://www.howtogeek.com/205086/beginner-how-to-make-windows-show-file-extensions/)


[^15]: [Tilbury Windows Credentials](https://www.first.org/resources/papers/conf2017/Windows-Credentials-Attacks-and-Mitigation-Techniques.pdf)


[^16]: [Microsoft Disable NTLM Nov 2012](https://technet.microsoft.com/library/jj865668.aspx)


[^17]: [TechRepublic Wireless GPO FEB 2009](https://www.techrepublic.com/blog/data-center/configuring-wireless-settings-via-group-policy/)


[^18]: [SpectorOps Code Signing Dec 2017](https://posts.specterops.io/code-signing-certificate-cloning-attacks-and-defenses-6f98657fc6ec)

