---
aliases: 
    - M1030
    
mitre-attack: https://attack.mitre.org/mitigations/M1030
---

## M1030

Network segmentation involves dividing a network into smaller, isolated segments to control and limit the flow of traffic between devices, systems, and applications. By segmenting networks, organizations can reduce the attack surface, restrict lateral movement by adversaries, and protect critical assets from compromise.<br><br>Effective network segmentation leverages a combination of physical boundaries, logical separation through VLANs, and access control policies enforced by network appliances like firewalls, routers, and cloud-based configurations. This mitigation can be implemented through the following measures:<br><br>Segment Critical Systems:<br><br>- Identify and group systems based on their function, sensitivity, and risk. Examples include payment systems, HR databases, production systems, and internet-facing servers.<br>- Use VLANs, firewalls, or routers to enforce logical separation.<br><br>Implement DMZ for Public-Facing Services:<br><br>- Host web servers, DNS servers, and email servers in a DMZ to limit their access to internal systems.<br>- Apply strict firewall rules to filter traffic between the DMZ and internal networks.<br><br>Use Cloud-Based Segmentation:<br><br>- In cloud environments, use VPCs, subnets, and security groups to isolate applications and enforce traffic rules.<br>- Apply AWS Transit Gateway or Azure VNet peering for controlled connectivity between cloud segments.<br><br>Apply Microsegmentation for Workloads:<br><br>- Use software-defined networking (SDN) tools to implement workload-level segmentation and prevent lateral movement.<br><br>Restrict Traffic with ACLs and Firewalls:<br><br>- Apply Access Control Lists (ACLs) to network devices to enforce "deny by default" policies.<br>- Use firewalls to restrict both north-south (external-internal) and east-west (internal-internal) traffic.<br><br>Monitor and Audit Segmented Networks:<br><br>- Regularly review firewall rules, ACLs, and segmentation policies.<br>- Monitor network flows for anomalies to ensure segmentation is effective.<br><br>Test Segmentation Effectiveness:<br><br>- Perform periodic penetration tests to verify that unauthorized access is blocked between network segments.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1565.003-runtime_data_manipulation\|T1565.003]] | [[T1565.003-runtime_data_manipulation\|Runtime Data Manipulation]] | Identify critical business and system processes that may be targeted by adversaries and work to isolate and secure those systems against unauthorized access and tampering. |
| [[T1613-container_and_resource_discovery\|T1613]] | [[T1613-container_and_resource_discovery\|Container and Resource Discovery]] | Deny direct remote access to internal systems through the use of network proxies, gateways, and firewalls. |
| [[T1098-account_manipulation\|T1098]] | [[T1098-account_manipulation\|Account Manipulation]] | Configure access controls and firewalls to limit access to critical systems and domain controllers. Most cloud environments support separate virtual private cloud (VPC) instances that enable further segmentation of cloud systems. |
| [[T1136-create_account\|T1136]] | [[T1136-create_account\|Create Account]] | Configure access controls and firewalls to limit access to domain controllers and systems used to create and manage accounts. |
| [[T1021.001-remote_desktop_protocol\|T1021.001]] | [[T1021.001-remote_desktop_protocol\|Remote Desktop Protocol]] | Do not leave RDP accessible from the internet. Enable firewall rules to block RDP traffic between network security zones within a network. |
| [[T1190-exploit_public_facing_application\|T1190]] | [[T1190-exploit_public_facing_application\|Exploit Public-Facing Application]] | Segment externally facing servers and services from the rest of the network with a DMZ or on separate hosting infrastructure. |
| [[T1602.002-network_device_configuration_dump\|T1602.002]] | [[T1602.002-network_device_configuration_dump\|Network Device Configuration Dump]] | Segregate SNMP traffic on a separate management network.[^4]   |
| [[T1136.003-cloud_account\|T1136.003]] | [[T1136.003-cloud_account\|Cloud Account]] | Configure access controls and firewalls to limit access to critical systems and domain controllers. Most cloud environments support separate virtual private cloud (VPC) instances that enable further segmentation of cloud systems. |
| [[T1563.002-rdp_hijacking\|T1563.002]] | [[T1563.002-rdp_hijacking\|RDP Hijacking]] | Enable firewall rules to block RDP traffic between network security zones within a network. |
| [[T1489-service_stop\|T1489]] | [[T1489-service_stop\|Service Stop]] | Operate intrusion detection, analysis, and response systems on a separate network from the production environment to lessen the chances that an adversary can see and interfere with critical response functions. |
| [[T1210-exploitation_of_remote_services\|T1210]] | [[T1210-exploitation_of_remote_services\|Exploitation of Remote Services]] | Segment networks and systems appropriately to reduce access to critical systems and services to controlled methods. |
| [[T1048-exfiltration_over_alternative_protocol\|T1048]] | [[T1048-exfiltration_over_alternative_protocol\|Exfiltration Over Alternative Protocol]] | Follow best practices for network firewall configurations to allow only necessary ports and traffic to enter and exit the network.[^1]  |
| [[T1612-build_image_on_host\|T1612]] | [[T1612-build_image_on_host\|Build Image on Host]] | Deny direct remote access to internal systems through the use of network proxies, gateways, and firewalls. |
| [[T1482-domain_trust_discovery\|T1482]] | [[T1482-domain_trust_discovery\|Domain Trust Discovery]] | Employ network segmentation for sensitive domains.[^3] . |
| [[T1098.001-additional_cloud_credentials\|T1098.001]] | [[T1098.001-additional_cloud_credentials\|Additional Cloud Credentials]] | Configure access controls and firewalls to limit access to critical systems and domain controllers. Most cloud environments support separate virtual private cloud (VPC) instances that enable further segmentation of cloud systems. |
| [[T1610-deploy_container\|T1610]] | [[T1610-deploy_container\|Deploy Container]] | Deny direct remote access to internal systems through the use of network proxies, gateways, and firewalls. |
| [[T1046-network_service_discovery\|T1046]] | [[T1046-network_service_discovery\|Network Service Discovery]] | Ensure proper network segmentation is followed to protect critical servers and devices. |
| [[T1563-remote_service_session_hijacking\|T1563]] | [[T1563-remote_service_session_hijacking\|Remote Service Session Hijacking]] | Enable firewall rules to block unnecessary traffic between network security zones within a network. |
| [[T1571-non_standard_port\|T1571]] | [[T1571-non_standard_port\|Non-Standard Port]] | Properly configure firewalls and proxies to limit outgoing traffic to only necessary ports for that particular network segment. |
| [[T1133-external_remote_services\|T1133]] | [[T1133-external_remote_services\|External Remote Services]] | Deny direct remote access to internal systems through the use of network proxies, gateways, and firewalls. |
| [[T1072-software_deployment_tools\|T1072]] | [[T1072-software_deployment_tools\|Software Deployment Tools]] | Ensure proper system isolation for critical network systems through use of firewalls. |
| [[T1669-wi_fi_networks\|T1669]] | [[T1669-wi_fi_networks\|Wi-Fi Networks]] | Network segmentation can be used to isolate infrastructure components that do not require broad network access. Separate networking environments for Wi-Fi and Ethernet-wired networks, particularly where Ethernet-based networks allow for access to sensitive resources. |
| [[T1021.003-distributed_component_object_model\|T1021.003]] | [[T1021.003-distributed_component_object_model\|Distributed Component Object Model]] | Enable Windows firewall, which prevents DCOM instantiation by default. |
| [[T1048.002-exfiltration_over_asymmetric_encrypted_non_c2_protocol\|T1048.002]] | [[T1048.002-exfiltration_over_asymmetric_encrypted_non_c2_protocol\|Exfiltration Over Asymmetric Encrypted Non-C2 Protocol]] | Follow best practices for network firewall configurations to allow only necessary ports and traffic to enter and exit the network.[^1]  |
| [[T1557-adversary_in_the_middle\|T1557]] | [[T1557-adversary_in_the_middle\|Adversary-in-the-Middle]] | Network segmentation can be used to isolate infrastructure components that do not require broad network access. This may mitigate, or at least alleviate, the scope of AiTM activity. |
| [[T1552.007-container_api\|T1552.007]] | [[T1552.007-container_api\|Container API]] | Deny direct remote access to internal systems through the use of network proxies, gateways, and firewalls. |
| [[T1602-data_from_configuration_repository\|T1602]] | [[T1602-data_from_configuration_repository\|Data from Configuration Repository]] | Segregate SNMP traffic on a separate management network.[^4]  |
| [[T1048.003-exfiltration_over_unencrypted_non_c2_protocol\|T1048.003]] | [[T1048.003-exfiltration_over_unencrypted_non_c2_protocol\|Exfiltration Over Unencrypted Non-C2 Protocol]] | Follow best practices for network firewall configurations to allow only necessary ports and traffic to enter and exit the network.[^1]  |
| [[T1095-non_application_layer_protocol\|T1095]] | [[T1095-non_application_layer_protocol\|Non-Application Layer Protocol]] | Properly configure firewalls and proxies to limit outgoing traffic to only necessary ports and through proper network gateway systems. Also ensure hosts are only provisioned to communicate over authorized interfaces. |
| [[T1565-data_manipulation\|T1565]] | [[T1565-data_manipulation\|Data Manipulation]] | Identify critical business and system processes that may be targeted by adversaries and work to isolate and secure those systems against unauthorized access and tampering. |
| [[T1602.001-snmp_mib_dump\|T1602.001]] | [[T1602.001-snmp_mib_dump\|SNMP (MIB Dump)]] | Segregate SNMP traffic on a separate management network.[^4]  |
| [[T1557.001-name_resolution_poisoning_and_smb_relay\|T1557.001]] | [[T1557.001-name_resolution_poisoning_and_smb_relay\|Name Resolution Poisoning and SMB Relay]] | Network segmentation can be used to isolate infrastructure components that do not require broad network access. This may mitigate, or at least alleviate, the scope of AiTM activity. |
| [[T1021.006-windows_remote_management\|T1021.006]] | [[T1021.006-windows_remote_management\|Windows Remote Management]] | If the service is necessary, lock down critical enclaves with separate WinRM infrastructure and follow WinRM best practices on use of host firewalls to restrict WinRM access to allow communication only to/from specific devices.[^2]  |
| [[T1048.001-exfiltration_over_symmetric_encrypted_non_c2_protocol\|T1048.001]] | [[T1048.001-exfiltration_over_symmetric_encrypted_non_c2_protocol\|Exfiltration Over Symmetric Encrypted Non-C2 Protocol]] | Follow best practices for network firewall configurations to allow only necessary ports and traffic to enter and exit the network.[^1]  |
| [[T1136.002-domain_account\|T1136.002]] | [[T1136.002-domain_account\|Domain Account]] | Configure access controls and firewalls to limit access to domain controllers and systems used to create and manage accounts. |
| [[T1040-network_sniffing\|T1040]] | [[T1040-network_sniffing\|Network Sniffing]] | Deny direct access of broadcasts and multicast sniffing, and prevent attacks such as [Name Resolution Poisoning and SMB Relay](https://attack.mitre.org/techniques/T1557/001) |
| [[T1199-trusted_relationship\|T1199]] | [[T1199-trusted_relationship\|Trusted Relationship]] | Network segmentation can be used to isolate infrastructure components that do not require broad network access. |


## References

[^1]: [TechNet Firewall Design](https://technet.microsoft.com/en-us/library/cc700828.aspx)


[^2]: [NSA Spotting](https://massarobi.wordpress.com/wp-content/uploads/2017/03/spotting-the-adversary-with-windows-event-log-monitoring.pdf)


[^3]: [Harmj0y Domain Trusts](https://posts.specterops.io/a-guide-to-attacking-domain-trusts-971e52cb2944)


[^4]: [US-CERT TA17-156A SNMP Abuse 2017](https://us-cert.cisa.gov/ncas/alerts/TA17-156A)

