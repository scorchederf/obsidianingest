# ATT&CK Mitigations

| ID | Name |
| --- | --- |
| M1013 | [[M1013-application_developer_guidance\|Application Developer Guidance]] |
| M1015 | [[M1015-active_directory_configuration\|Active Directory Configuration]] |
| M1016 | [[M1016-vulnerability_scanning\|Vulnerability Scanning]] |
| M1017 | [[M1017-user_training\|User Training]] |
| M1018 | [[M1018-user_account_management\|User Account Management]] |
| M1019 | [[M1019-threat_intelligence_program\|Threat Intelligence Program]] |
| M1020 | [[M1020-ssl_tls_inspection\|SSL／TLS Inspection]] |
| M1021 | [[M1021-restrict_web_based_content\|Restrict Web-Based Content]] |
| M1022 | [[M1022-restrict_file_and_directory_permissions\|Restrict File and Directory Permissions]] |
| M1024 | [[M1024-restrict_registry_permissions\|Restrict Registry Permissions]] |
| M1025 | [[M1025-privileged_process_integrity\|Privileged Process Integrity]] |
| M1026 | [[M1026-privileged_account_management\|Privileged Account Management]] |
| M1027 | [[M1027-password_policies\|Password Policies]] |
| M1028 | [[M1028-operating_system_configuration\|Operating System Configuration]] |
| M1029 | [[M1029-remote_data_storage\|Remote Data Storage]] |
| M1030 | [[M1030-network_segmentation\|Network Segmentation]] |
| M1031 | [[M1031-network_intrusion_prevention\|Network Intrusion Prevention]] |
| M1032 | [[M1032-multi_factor_authentication\|Multi-factor Authentication]] |
| M1033 | [[M1033-limit_software_installation\|Limit Software Installation]] |
| M1034 | [[M1034-limit_hardware_installation\|Limit Hardware Installation]] |
| M1035 | [[M1035-limit_access_to_resource_over_network\|Limit Access to Resource Over Network]] |
| M1036 | [[M1036-account_use_policies\|Account Use Policies]] |
| M1037 | [[M1037-filter_network_traffic\|Filter Network Traffic]] |
| M1038 | [[M1038-execution_prevention\|Execution Prevention]] |
| M1039 | [[M1039-environment_variable_permissions\|Environment Variable Permissions]] |
| M1040 | [[M1040-behavior_prevention_on_endpoint\|Behavior Prevention on Endpoint]] |
| M1041 | [[M1041-encrypt_sensitive_information\|Encrypt Sensitive Information]] |
| M1042 | [[M1042-disable_or_remove_feature_or_program\|Disable or Remove Feature or Program]] |
| M1043 | [[M1043-credential_access_protection\|Credential Access Protection]] |
| M1044 | [[M1044-restrict_library_loading\|Restrict Library Loading]] |
| M1045 | [[M1045-code_signing\|Code Signing]] |
| M1046 | [[M1046-boot_integrity\|Boot Integrity]] |
| M1047 | [[M1047-audit\|Audit]] |
| M1048 | [[M1048-application_isolation_and_sandboxing\|Application Isolation and Sandboxing]] |
| M1049 | [[M1049-antivirus_antimalware\|Antivirus／Antimalware]] |
| M1050 | [[M1050-exploit_protection\|Exploit Protection]] |
| M1051 | [[M1051-update_software\|Update Software]] |
| M1052 | [[M1052-user_account_control\|User Account Control]] |
| M1053 | [[M1053-data_backup\|Data Backup]] |
| M1054 | [[M1054-software_configuration\|Software Configuration]] |
| M1055 | [[M1055-do_not_mitigate\|Do Not Mitigate]] |
| M1056 | [[M1056-pre_compromise\|Pre-compromise]] |
| M1057 | [[M1057-data_loss_prevention\|Data Loss Prevention]] |
| M1060 | [[M1060-out_of_band_communications_channel\|Out-of-Band Communications Channel]] |
