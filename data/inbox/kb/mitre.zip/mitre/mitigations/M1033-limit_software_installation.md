---
aliases: 
    - M1033
    
mitre-attack: https://attack.mitre.org/mitigations/M1033
---

## M1033

Prevent users or groups from installing unauthorized or unapproved software to reduce the risk of introducing malicious or vulnerable applications. This can be achieved through allowlists, software restriction policies, endpoint management tools, and least privilege access principles. This mitigation can be implemented through the following measures:<br><br>Application Whitelisting<br><br>- Implement Microsoft AppLocker or Windows Defender Application Control (WDAC) to create and enforce allowlists for approved software.<br>- Whitelist applications based on file hash, path, or digital signatures.<br><br>Restrict User Permissions<br><br>- Remove local administrator rights for all non-IT users.<br>- Use Role-Based Access Control (RBAC) to restrict installation permissions to privileged accounts only.<br><br>Software Restriction Policies (SRP)<br><br>- Use GPO to configure SRP to deny execution of binaries from directories such as `%AppData%`, `%Temp%`, and external drives.<br>- Restrict specific file types (`.exe`, `.bat`, `.msi`, `.js`, `.vbs`) to trusted directories only.<br><br>Endpoint Management Solutions<br><br>- Deploy tools like Microsoft Intune, SCCM, or Jamf for centralized software management.<br>- Maintain a list of approved software, versions, and updates across the enterprise.<br><br>Monitor Software Installation Events<br><br>- Enable logging of software installation events and monitor Windows Event ID 4688 and Event ID 11707 for software installs.<br>- Use SIEM or EDR tools to alert on attempts to install unapproved software.<br><br>Implement Software Inventory Management<br><br>- Use tools like OSQuery or Wazuh to scan for unauthorized software on endpoints and servers.<br>- Conduct regular audits to detect and remove unapproved software.<br><br>*Tools for Implementation*<br><br>Application Whitelisting:<br><br>- Microsoft AppLocker<br>- Windows Defender Application Control (WDAC)<br><br>Endpoint Management:<br><br>- Microsoft Intune<br>- SCCM (System Center Configuration Manager)<br>- Jamf Pro (macOS)<br>- Puppet or Ansible for automation<br><br>Software Restriction Policies:<br><br>- Group Policy Object (GPO)<br>- Microsoft Software Restriction Policies (SRP)<br><br>Monitoring and Logging:<br><br>- Splunk<br>- OSQuery<br>- Wazuh (open-source SIEM and XDR)<br>- EDRs<br><br>Inventory Management and Auditing:<br><br>- OSQuery<br>- Wazuh

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1176.001-browser_extensions\|T1176.001]] | [[T1176.001-browser_extensions\|Browser Extensions]] | Only install browser extensions from trusted sources that can be verified. Browser extensions for some browsers can be controlled through Group Policy. Change settings to prevent the browser from installing extensions without sufficient permissions. |
| [[T1204.005-malicious_library\|T1204.005]] | [[T1204.005-malicious_library\|Malicious Library]] | Where possible, consider requiring developers to pull from internal repositories containing verified and approved packages rather than from external ones.  |
| [[T1195.001-compromise_software_dependencies_and_development_tools\|T1195.001]] | [[T1195.001-compromise_software_dependencies_and_development_tools\|Compromise Software Dependencies and Development Tools]] | Where possible, consider requiring developers to pull from internal repositories containing verified and approved packages rather than from external ones.[^1]  |
| [[T1059-command_and_scripting_interpreter\|T1059]] | [[T1059-command_and_scripting_interpreter\|Command and Scripting Interpreter]] | Prevent user installation of unrequired command and scripting interpreters. |
| [[T1564-hide_artifacts\|T1564]] | [[T1564-hide_artifacts\|Hide Artifacts]] | Restrict the installation of software that may be abused to create hidden desktops, such as hVNC, to user groups that require it. |
| [[T1059.011-lua\|T1059.011]] | [[T1059.011-lua\|Lua]] | Prevent users from installing Lua where not required. |
| [[T1176-software_extensions\|T1176]] | [[T1176-software_extensions\|Software Extensions]] | Only install extensions from trusted sources that can be verified. |
| [[T1543-create_or_modify_system_process\|T1543]] | [[T1543-create_or_modify_system_process\|Create or Modify System Process]] | Restrict software installation to trusted repositories only and be cautious of orphaned software packages. |
| [[T1564.003-hidden_window\|T1564.003]] | [[T1564.003-hidden_window\|Hidden Window]] | Restrict the installation of software that may be abused to create hidden desktops, such as hVNC, to user groups that require it. |
| [[T1072-software_deployment_tools\|T1072]] | [[T1072-software_deployment_tools\|Software Deployment Tools]] | Restrict the use of third-party software suites installed within an enterprise network.  |
| [[T1547.013-xdg_autostart_entries\|T1547.013]] | [[T1547.013-xdg_autostart_entries\|XDG Autostart Entries]] | Restrict software installation to trusted repositories only and be cautious of orphaned software packages. |
| [[T1176.002-ide_extensions\|T1176.002]] | [[T1176.002-ide_extensions\|IDE Extensions]] | Only install IDE extensions from trusted sources that can be verified.   |
| [[T1059.006-python\|T1059.006]] | [[T1059.006-python\|Python]] | Prevent users from installing Python where not required. |
| [[T1204-user_execution\|T1204]] | [[T1204-user_execution\|User Execution]] | Where possible, consider requiring developers to pull from internal repositories containing verified and approved packages rather than from external ones. |
| [[T1195-supply_chain_compromise\|T1195]] | [[T1195-supply_chain_compromise\|Supply Chain Compromise]] | Where possible, consider requiring developers to pull from internal repositories containing verified and approved packages rather than from external ones.[^1]  |
| [[T1543.002-systemd_service\|T1543.002]] | [[T1543.002-systemd_service\|Systemd Service]] | Restrict software installation to trusted repositories only and be cautious of orphaned software packages. |
| [[T1021.005-vnc\|T1021.005]] | [[T1021.005-vnc\|VNC]] | Restrict software installation to user groups that require it. A VNC server must be manually installed by the user or adversary. |


## References

[^1]: [Cider Security Top 10 CICD Security Risks](https://web.archive.org/web/20220316130828/https://www.cidersecurity.io/top-10-cicd-security-risks/)

