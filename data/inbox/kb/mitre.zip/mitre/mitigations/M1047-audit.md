---
aliases: 
    - M1047
    
mitre-attack: https://attack.mitre.org/mitigations/M1047
---

## M1047

Auditing is the process of recording activity and systematically reviewing and analyzing the activity and system configurations. The primary purpose of auditing is to detect anomalies and identify potential threats or weaknesses in the environment. Proper auditing configurations can also help to meet compliance requirements. The process of auditing encompasses regular analysis of user behaviors and system logs in support of proactive security measures.<br><br>Auditing is applicable to all systems used within an organization, from the front door of a building to accessing a file on a fileserver. It is considered more critical for regulated industries such as, healthcare, finance and government where compliance requirements demand stringent tracking of user and system activates.This mitigation can be implemented through the following measures: <br><br>System Audit:<br><br>- Use Case: Regularly assess system configurations to ensure compliance with organizational security policies.<br>- Implementation: Use tools to scan for deviations from established benchmarks.<br><br>Permission Audits:<br><br>- Use Case: Review file and folder permissions to minimize the risk of unauthorized access or privilege escalation.<br>- Implementation: Run access reviews to identify users or groups with excessive permissions.<br><br>Software Audits:<br><br>- Use Case: Identify outdated, unsupported, or insecure software that could serve as an attack vector.<br>- Implementation: Use inventory and vulnerability scanning tools to detect outdated versions and recommend secure alternatives.<br><br>Configuration Audits:<br><br>- Use Case: Evaluate system and network configurations to ensure secure settings (e.g., disabled SMBv1, enabled MFA).<br>- Implementation: Implement automated configuration scanning tools like SCAP (Security Content Automation Protocol) to identify non-compliant systems.<br><br>Network Audits:<br><br>- Use Case: Examine network traffic, firewall rules, and endpoint communications to identify unauthorized or insecure connections.<br>- Implementation: Utilize tools such as Wireshark, or Zeek to monitor and log suspicious network behavior.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1484-domain_or_tenant_policy_modification\|T1484]] | [[T1484-domain_or_tenant_policy_modification\|Domain or Tenant Policy Modification]] | Identify and correct GPO permissions abuse opportunities (ex: GPO modification privileges) using auditing tools such as [BloodHound](https://attack.mitre.org/software/S0521) (version 1.5.1 and later)[^27] . |
| [[T1059.006-python\|T1059.006]] | [[T1059.006-python\|Python]] | Inventory systems for unauthorized Python installations. |
| [[T1036-masquerading\|T1036]] | [[T1036-masquerading\|Masquerading]] | Audit user accounts to ensure that each one has a defined purpose. |
| [[T1482-domain_trust_discovery\|T1482]] | [[T1482-domain_trust_discovery\|Domain Trust Discovery]] | Map the trusts within existing domains/forests and keep trust relationships to a minimum. |
| [[T1053.003-cron\|T1053.003]] | [[T1053.003-cron\|Cron]] | Review changes to the `cron` schedule. `cron` execution can be reviewed within the `/var/log` directory. To validate the location of the `cron` log file, check the syslog config at `/etc/rsyslog.conf` or `/etc/syslog.conf`. |
| [[T1574.005-executable_installer_file_permissions_weakness\|T1574.005]] | [[T1574.005-executable_installer_file_permissions_weakness\|Executable Installer File Permissions Weakness]] | Use auditing tools capable of detecting file system permissions abuse opportunities on systems within an enterprise and correct them. Toolkits like the PowerSploit framework contain PowerUp modules that can be used to explore systems for service file system permissions weaknesses.[^17]  |
| [[T1505.005-terminal_services_dll\|T1505.005]] | [[T1505.005-terminal_services_dll\|Terminal Services DLL]] | Regularly check component software on critical services that adversaries may target for persistence to verify the integrity of the systems and identify if unexpected changes have been made. |
| [[T1686.001-cloud_firewall\|T1686.001]] | [[T1686.001-cloud_firewall\|Cloud Firewall]] | Routinely check account role permissions to ensure only expected users and roles have permission to modify cloud firewalls.  |
| [[T1176.001-browser_extensions\|T1176.001]] | [[T1176.001-browser_extensions\|Browser Extensions]] |  Ensure extensions that are installed are the intended ones, as many malicious extensions will masquerade as legitimate ones. |
| [[T1505-server_software_component\|T1505]] | [[T1505-server_software_component\|Server Software Component]] | Regularly check component software on critical services that adversaries may target for persistence to verify the integrity of the systems and identify if unexpected changes have been made. |
| [[T1542-pre_os_boot\|T1542]] | [[T1542-pre_os_boot\|Pre-OS Boot]] | Perform audits or scans of systems, permissions, insecure software, insecure configurations, etc. to identify potential weaknesses. |
| [[T1566-phishing\|T1566]] | [[T1566-phishing\|Phishing]] | Perform audits or scans of systems, permissions, insecure software, insecure configurations, etc. to identify potential weaknesses. |
| [[T1484.001-group_policy_modification\|T1484.001]] | [[T1484.001-group_policy_modification\|Group Policy Modification]] | Identify and correct GPO permissions abuse opportunities (ex: GPO modification privileges) using auditing tools such as [BloodHound](https://attack.mitre.org/software/S0521) (version 1.5.1 and later).[^27]  |
| [[T1539-steal_web_session_cookie\|T1539]] | [[T1539-steal_web_session_cookie\|Steal Web Session Cookie]] | Implement auditing for authentication activities and user logins to detect the use of stolen session cookies. Monitor for impossible travel scenarios and anomalous behavior that could indicate the use of compromised session tokens or cookies. |
| [[T1505.001-sql_stored_procedures\|T1505.001]] | [[T1505.001-sql_stored_procedures\|SQL Stored Procedures]] | Regularly check component software on critical services that adversaries may target for persistence to verify the integrity of the systems and identify if unexpected changes have been made.  |
| [[T1564.006-run_virtual_instance\|T1564.006]] | [[T1564.006-run_virtual_instance\|Run Virtual Instance]] | Periodically audit virtual machines for abnormalities. On ESXi servers, periodically compare the output of `vim-cmd vmsvc/getallvms`, which lists all VMs in vCenter, and `escxli vm process list | grep Display`, which lists all VMs hosted on ESXi.[^30]  |
| [[T1686-disable_or_modify_system_firewall\|T1686]] | [[T1686-disable_or_modify_system_firewall\|Disable or Modify System Firewall]] | Routinely check account role permissions to ensure only expected users and roles have permission to modify system firewalls. |
| [[T1686.002-network_device_firewall\|T1686.002]] | [[T1686.002-network_device_firewall\|Network Device Firewall]] | Routinely check account role permissions to ensure only expected users and roles have permission to modify system firewalls. |
| [[T1574.009-path_interception_by_unquoted_path\|T1574.009]] | [[T1574.009-path_interception_by_unquoted_path\|Path Interception by Unquoted Path]] | Find and eliminate path interception weaknesses in program configuration files, scripts, the PATH environment variable, services, and in shortcuts by surrounding PATH variables with quotation marks when functions allow for them. Be aware of the search order Windows uses for executing or loading binaries and use fully qualified paths wherever appropriate.<br><br>Clean up old Windows Registry keys when software is uninstalled to avoid keys with no associated legitimate binaries. Periodically search for and correct or report path interception weaknesses on systems that may have been introduced using custom or available tools that report software using insecure path configurations.[^21] [^38] [^14]  |
| [[T1685.001-disable_or_modify_windows_event_log\|T1685.001]] | [[T1685.001-disable_or_modify_windows_event_log\|Disable or Modify Windows Event Log]] | Consider periodic review of `auditpol` settings for Administrator accounts and perform dynamic baselining on SIEM(s) to investigate potential malicious activity. Also ensure that the EventLog service and its threads are properly running. |
| [[T1021.001-remote_desktop_protocol\|T1021.001]] | [[T1021.001-remote_desktop_protocol\|Remote Desktop Protocol]] | Audit the Remote Desktop Users group membership regularly. Remove unnecessary accounts and groups from Remote Desktop Users groups. |
| [[T1564.008-email_hiding_rules\|T1564.008]] | [[T1564.008-email_hiding_rules\|Email Hiding Rules]] | Enterprise email solutions may have monitoring mechanisms that may include the ability to audit inbox rules on a regular basis. <br><br>In an Exchange environment, Administrators can use `Get-InboxRule` / `Remove-InboxRule` and `Get-TransportRule` / `Remove-TransportRule` to discover and remove potentially malicious inbox and transport rules.[^40] [^1]  |
| [[T1548.002-bypass_user_account_control\|T1548.002]] | [[T1548.002-bypass_user_account_control\|Bypass User Account Control]] | Check for common UAC bypass weaknesses on Windows systems to be aware of the risk posture and address issues where appropriate.[^12]  |
| [[T1558.004-as_rep_roasting\|T1558.004]] | [[T1558.004-as_rep_roasting\|AS-REP Roasting]] | Kerberos preauthentication is enabled by default. Older protocols might not support preauthentication therefore it is possible to have this setting disabled. Make sure that all accounts have preauthentication whenever possible and audit changes to setting. Windows tools such as PowerShell may be used to easily find which accounts have preauthentication disabled.  [^2] [^8]  |
| [[T1027.011-fileless_storage\|T1027.011]] | [[T1027.011-fileless_storage\|Fileless Storage]] | Consider periodic review of common fileless storage locations (such as the Registry or WMI repository) to potentially identify abnormal and malicious data. |
| [[T1053.002-at\|T1053.002]] | [[T1053.002-at\|At]] | Toolkits like the PowerSploit framework contain PowerUp modules that can be used to explore systems for permission weaknesses in scheduled tasks that could be used to escalate privileges. [^17]  Windows operating system also creates a registry key specifically associated with the creation of a scheduled task on the destination host at: Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\At1. [^3]  In Linux and macOS environments, scheduled tasks using `[at](https://attack.mitre.org/software/S0110)` can be audited locally, or through centrally collected logging, using syslog, or auditd events from the host. [^11]  |
| [[T1543.003-windows_service\|T1543.003]] | [[T1543.003-windows_service\|Windows Service]] | Use auditing tools capable of detecting privilege and service abuse opportunities on systems within an enterprise and correct them.  |
| [[T1671-cloud_application_integration\|T1671]] | [[T1671-cloud_application_integration\|Cloud Application Integration]] | Periodically review SaaS integrations for unapproved or potentially malicious applications.   |
| [[T1550-use_alternate_authentication_material\|T1550]] | [[T1550-use_alternate_authentication_material\|Use Alternate Authentication Material]] | Perform audits or scans of systems, permissions, insecure software, insecure configurations, etc. to identify potential weaknesses. |
| [[T1552.006-group_policy_preferences\|T1552.006]] | [[T1552.006-group_policy_preferences\|Group Policy Preferences]] | Search SYSVOL for any existing GGPs that may contain credentials and remove them.[^25]  |
| [[T1685-disable_or_modify_tools\|T1685]] | [[T1685-disable_or_modify_tools\|Disable or Modify Tools]] | Periodically verify that tools are functioning appropriately – for example, that all expected hosts with EDRs or monitoring agents are checking in to the central console. Check EDRs to ensure that no unexpected exclusion paths have been added. In Microsoft Defender for Endpoint, exclusions can be reviewed with the `Get-MpPreference` cmdlet.[^5]  |
| [[T1528-steal_application_access_token\|T1528]] | [[T1528-steal_application_access_token\|Steal Application Access Token]] | Administrators should audit all cloud and container accounts to ensure that they are necessary and that the permissions granted to them are appropriate.  Additionally, administrators should perform an audit of all OAuth applications and the permissions they have been granted to access organizational data. This should be done extensively on all applications in order to establish a baseline, followed up on with periodic audits of new or updated applications. Suspicious applications should be investigated and removed. |
| [[T1574-hijack_execution_flow\|T1574]] | [[T1574-hijack_execution_flow\|Hijack Execution Flow]] | Use auditing tools capable of detecting hijacking opportunities on systems within an enterprise and correct them. Toolkits like the PowerSploit framework contain PowerUp modules that can be used to explore systems for hijacking weaknesses.[^17] <br><br>Use the program sxstrace.exe that is included with Windows along with manual inspection to check manifest files for side-loading vulnerabilities in software.<br><br>Find and eliminate path interception weaknesses in program configuration files, scripts, the PATH environment variable, services, and in shortcuts by surrounding PATH variables with quotation marks when functions allow for them. Be aware of the search order Windows uses for executing or loading binaries and use fully qualified paths wherever appropriate.<br><br>Clean up old Windows Registry keys when software is uninstalled to avoid keys with no associated legitimate binaries. Periodically search for and correct or report path interception weaknesses on systems that may have been introduced using custom or available tools that report software using insecure path configurations.[^21] [^38] [^14]  |
| [[T1610-deploy_container\|T1610]] | [[T1610-deploy_container\|Deploy Container]] | Scan images before deployment, and block those that are not in compliance with security policies. In Kubernetes environments, the admission controller can be used to validate images after a container deployment request is authenticated but before the container is deployed.[^28]  |
| [[T1606.001-web_cookies\|T1606.001]] | [[T1606.001-web_cookies\|Web Cookies]] | Administrators should perform an audit of all access lists and the permissions they have been granted to access web applications and services. This should be done extensively on all resources in order to establish a baseline, followed up on with periodic audits of new or updated resources. Suspicious accounts/credentials should be investigated and removed. |
| [[T1213.001-confluence\|T1213.001]] | [[T1213.001-confluence\|Confluence]] | Consider periodic review of accounts and privileges for critical and sensitive Confluence repositories. |
| [[T1213.005-messaging_applications\|T1213.005]] | [[T1213.005-messaging_applications\|Messaging Applications]] | Preemptively search through communication services to find inappropriately shared data, and take actions to reduce exposure when found.  |
| [[T1566.002-spearphishing_link\|T1566.002]] | [[T1566.002-spearphishing_link\|Spearphishing Link]] | Audit applications and their permissions to ensure access to data and resources are limited based upon necessity and principle of least privilege. |
| [[T1546.006-lc_load_dylib_addition\|T1546.006]] | [[T1546.006-lc_load_dylib_addition\|LC_LOAD_DYLIB Addition]] | Binaries can also be baselined for what dynamic libraries they require, and if an app requires a new dynamic library that wasn't included as part of an update, it should be investigated. |
| [[T1564-hide_artifacts\|T1564]] | [[T1564-hide_artifacts\|Hide Artifacts]] | Periodically audit virtual machines for abnormalities. |
| [[T1543-create_or_modify_system_process\|T1543]] | [[T1543-create_or_modify_system_process\|Create or Modify System Process]] | Use auditing tools capable of detecting privilege and service abuse opportunities on systems within an enterprise and correct them. |
| [[T1558.005-ccache_files\|T1558.005]] | [[T1558.005-ccache_files\|Ccache Files]] | Enable and perform audits or scans of systems, permissions, insecure software, insecure configurations, etc. to identify potential weaknesses.[^4]  For example, use `auditd` to audit access to hashes, machine tickets, or `/tmp` files. If using sssd and Vintela, ensure kerberos is disabled if not being used.[^31]  |
| [[T1213.002-sharepoint\|T1213.002]] | [[T1213.002-sharepoint\|Sharepoint]] | Consider periodic review of accounts and privileges for critical and sensitive SharePoint repositories. |
| [[T1556.008-network_provider_dll\|T1556.008]] | [[T1556.008-network_provider_dll\|Network Provider DLL]] | Periodically review for new and unknown network provider DLLs within the Registry (`HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\<NetworkProviderName>\NetworkProvider\ProviderPath`).<br><br>Ensure only valid network provider DLLs are registered. The name of these can be found in the Registry key at `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\NetworkProvider\Order`, and have corresponding service subkey pointing to a DLL at `HKEY_LOCAL_MACHINE\SYSTEM\CurrentC ontrolSet\Services\<NetworkProviderName>\NetworkProvider`. |
| [[T1563.002-rdp_hijacking\|T1563.002]] | [[T1563.002-rdp_hijacking\|RDP Hijacking]] | Audit the Remote Desktop Users group membership regularly. Remove unnecessary accounts and groups from Remote Desktop Users groups. |
| [[T1021-remote_services\|T1021]] | [[T1021-remote_services\|Remote Services]] | Perform audits or scans of systems, permissions, insecure software, insecure configurations, etc. to identify potential weaknesses. |
| [[T1578.001-create_snapshot\|T1578.001]] | [[T1578.001-create_snapshot\|Create Snapshot]] | Routinely check user permissions to ensure only the expected users have the capability to create snapshots and backups. |
| [[T1021.005-vnc\|T1021.005]] | [[T1021.005-vnc\|VNC]] | Inventory workstations for unauthorized VNC server software. |
| [[T1176.002-ide_extensions\|T1176.002]] | [[T1176.002-ide_extensions\|IDE Extensions]] | Ensure extensions that are installed are the intended ones, as many malicious extensions may masquerade as legitimate ones.  |
| [[T1552.008-chat_messages\|T1552.008]] | [[T1552.008-chat_messages\|Chat Messages]] | Preemptively search through communication services to find shared unsecured credentials. Searching for common patterns like "`password is `", “`password=`” and take actions to reduce exposure when found.  |
| [[T1566.001-spearphishing_attachment\|T1566.001]] | [[T1566.001-spearphishing_attachment\|Spearphishing Attachment]] | Enable auditing and monitoring for email attachments and file transfers to detect and investigate suspicious activity. Regularly review logs for anomalies related to attachments containing potentially malicious content, as well as any attempts to execute or interact with these files. This practice helps identify spearphishing attempts before they can lead to further compromise. |
| [[T1070.008-clear_mailbox_data\|T1070.008]] | [[T1070.008-clear_mailbox_data\|Clear Mailbox Data]] | In an Exchange environment, Administrators can use `Get-TransportRule` / `Remove-TransportRule` to discover and remove potentially malicious transport rules.[^1]  |
| [[T1059.011-lua\|T1059.011]] | [[T1059.011-lua\|Lua]] | Inventory systems for unauthorized Lua installations. |
| [[T1550.001-application_access_token\|T1550.001]] | [[T1550.001-application_access_token\|Application Access Token]] | Administrators should audit all cloud and container accounts to ensure that they are necessary and that the permissions granted to them are appropriate. Where possible, the ability to request temporary account tokens on behalf of another accounts should be disabled. Additionally, administrators can leverage audit tools to monitor actions that can be conducted as a result of OAuth 2.0 access. For instance, audit reports enable admins to identify privilege escalation actions such as role creations or policy modifications, which could be actions performed after initial access. |
| [[T1684-social_engineering\|T1684]] | [[T1684-social_engineering\|Social Engineering]] | Enables correlation of email/identity/SaaS/endpoint activity that appears legitimate.[^10] [^35]  |
| [[T1606.002-saml_tokens\|T1606.002]] | [[T1606.002-saml_tokens\|SAML Tokens]] | Enable advanced auditing on AD FS. Check the success and failure audit options in the AD FS Management snap-in. Enable Audit Application Generated events on the AD FS farm via Group Policy Object.[^18]  |
| [[T1095-non_application_layer_protocol\|T1095]] | [[T1095-non_application_layer_protocol\|Non-Application Layer Protocol]] | Periodically investigate ESXi hosts for open VMCI ports. Running the `lsof -A` command and inspecting results with a type of `SOCKET_VMCI` will reveal processes that have open VMCI ports.[^20]  |
| [[T1087.004-cloud_account\|T1087.004]] | [[T1087.004-cloud_account\|Cloud Account]] | Routinely check user permissions to ensure only the expected users have the ability to list IAM identities or otherwise discover cloud accounts. |
| [[T1556.006-multi_factor_authentication\|T1556.006]] | [[T1556.006-multi_factor_authentication\|Multi-Factor Authentication]] | Review MFA actions alongside authentication logs to ensure that MFA-based logins are functioning as intended. Review user accounts to ensure that all accounts have MFA enabled.[^33]  |
| [[T1578-modify_cloud_compute_infrastructure\|T1578]] | [[T1578-modify_cloud_compute_infrastructure\|Modify Cloud Compute Infrastructure]] | Routinely monitor user permissions to ensure only the expected users have the capability to modify cloud compute infrastructure components. |
| [[T1560.001-archive_via_utility\|T1560.001]] | [[T1560.001-archive_via_utility\|Archive via Utility]] | System scans can be performed to identify unauthorized archival utilities. |
| [[T1548-abuse_elevation_control_mechanism\|T1548]] | [[T1548-abuse_elevation_control_mechanism\|Abuse Elevation Control Mechanism]] | Check for common UAC bypass weaknesses on Windows systems to be aware of the risk posture and address issues where appropriate.[^12]  |
| [[T1036.012-browser_fingerprint\|T1036.012]] | [[T1036.012-browser_fingerprint\|Browser Fingerprint]] | Review and limit the fingerprinting surface to only necessary information on each browser to make the browser less unique. For example, the available fonts may be limited to a standard font list. [^24]  |
| [[T1213.003-code_repositories\|T1213.003]] | [[T1213.003-code_repositories\|Code Repositories]] | Consider periodic reviews of accounts and privileges for critical and sensitive code repositories. Scan code repositories for exposed credentials or other sensitive information. |
| [[T1685.004-disable_or_modify_linux_audit_system_log\|T1685.004]] | [[T1685.004-disable_or_modify_linux_audit_system_log\|Disable or Modify Linux Audit System Log]] | Routinely check account role permissions to ensure only expected users and roles have permission to modify logging settings.<br><br>To ensure Audit rules can not be modified at runtime, add the `auditctl -e 2` as the last command in the audit.rules files. Once started, any attempt to change the configuration in this mode will be audited and denied. The configuration can only be changed by rebooting the machine. |
| [[T1578.005-modify_cloud_compute_configurations\|T1578.005]] | [[T1578.005-modify_cloud_compute_configurations\|Modify Cloud Compute Configurations]] | Routinely monitor user permissions to ensure only the expected users have the capability to request quota adjustments or modify tenant-level compute settings. |
| [[T1566.003-spearphishing_via_service\|T1566.003]] | [[T1566.003-spearphishing_via_service\|Spearphishing via Service]] | Implement auditing and logging for interactions with third-party messaging services or collaboration platforms. Monitor user activity and review logs for signs of suspicious links, downloads, or file exchanges that could indicate spearphishing attempts. Effective auditing allows for the quick identification of malicious activity originating from compromised service accounts. |
| [[T1552.002-credentials_in_registry\|T1552.002]] | [[T1552.002-credentials_in_registry\|Credentials in Registry]] | Proactively search for credentials within the Registry and attempt to remediate the risk. |
| [[T1053-scheduled_task_job\|T1053]] | [[T1053-scheduled_task_job\|Scheduled Task／Job]] | Toolkits like the PowerSploit framework contain PowerUp modules that can be used to explore systems for permission weaknesses in scheduled tasks that could be used to escalate privileges. [^17]  |
| [[T1574.010-services_file_permissions_weakness\|T1574.010]] | [[T1574.010-services_file_permissions_weakness\|Services File Permissions Weakness]] | Use auditing tools capable of detecting file system permissions abuse opportunities on systems within an enterprise and correct them. Toolkits like the PowerSploit framework contain PowerUp modules that can be used to explore systems for service file system permissions weaknesses.[^17]  |
| [[T1560-archive_collected_data\|T1560]] | [[T1560-archive_collected_data\|Archive Collected Data]] | System scans can be performed to identify unauthorized archival utilities. |
| [[T1027-obfuscated_files_or_information\|T1027]] | [[T1027-obfuscated_files_or_information\|Obfuscated Files or Information]] | Consider periodic review of common fileless storage locations (such as the Registry or WMI repository) to potentially identify abnormal and malicious data. |
| [[T1505.004-iis_components\|T1505.004]] | [[T1505.004-iis_components\|IIS Components]] | Regularly check installed IIS components to verify the integrity of the web server and identify if unexpected changes have been made. |
| [[T1176-software_extensions\|T1176]] | [[T1176-software_extensions\|Software Extensions]] | Ensure extensions that are installed are the intended ones, as many malicious extensions may masquerade as legitimate ones.  |
| [[T1213.004-customer_relationship_management_software\|T1213.004]] | [[T1213.004-customer_relationship_management_software\|Customer Relationship Management Software]] | Consider periodic review of accounts and privileges for critical and sensitive CRM data. |
| [[T1556.007-hybrid_identity\|T1556.007]] | [[T1556.007-hybrid_identity\|Hybrid Identity]] | Periodically review the hybrid identity solution in use for any discrepancies. For example, review all PTA agents in the Entra ID Management Portal to identify any unwanted or unapproved ones.[^26]  If ADFS is in use, review DLLs and executable files in the AD FS and Global Assembly Cache directories to ensure that they are signed by Microsoft. Note that in some cases binaries may be catalog-signed, which may cause the file to appear unsigned when viewing file properties.[^34]  |
| [[T1552-unsecured_credentials\|T1552]] | [[T1552-unsecured_credentials\|Unsecured Credentials]] | Preemptively search for files containing passwords or other credentials and take actions to reduce the exposure risk when found. |
| [[T1578.002-create_cloud_instance\|T1578.002]] | [[T1578.002-create_cloud_instance\|Create Cloud Instance]] | Routinely check user permissions to ensure only the expected users have the capability to create new instances. |
| [[T1574.008-path_interception_by_search_order_hijacking\|T1574.008]] | [[T1574.008-path_interception_by_search_order_hijacking\|Path Interception by Search Order Hijacking]] | Find and eliminate path interception weaknesses in program configuration files, scripts, the PATH environment variable, services, and in shortcuts by surrounding PATH variables with quotation marks when functions allow for them. Be aware of the search order Windows uses for executing or loading binaries and use fully qualified paths wherever appropriate.<br><br>Clean up old Windows Registry keys when software is uninstalled to avoid keys with no associated legitimate binaries. Periodically search for and correct or report path interception weaknesses on systems that may have been introduced using custom or available tools that report software using insecure path configurations.[^21] [^38] [^14]  |
| [[T1542.004-rommonkit\|T1542.004]] | [[T1542.004-rommonkit\|ROMMONkit]] | Periodically check the integrity of system image to ensure it has not been modified. [^36]  [^39]  [^22]   |
| [[T1053.005-scheduled_task\|T1053.005]] | [[T1053.005-scheduled_task\|Scheduled Task]] | Toolkits like the PowerSploit framework contain PowerUp modules that can be used to explore systems for permission weaknesses in scheduled tasks that could be used to escalate privileges. [^17]  |
| [[T1574.001-dll\|T1574.001]] | [[T1574.001-dll\|DLL]] | Use auditing tools capable of detecting DLL search order hijacking opportunities on systems within an enterprise and correct them. Toolkits like the PowerSploit framework contain PowerUp modules that can be used to explore systems for DLL hijacking weaknesses.[^17] <br><br>Use the program `sxstrace.exe` that is included with Windows, along with manual inspection, to check manifest files for side-by-side problems in software.[^37]  |
| [[T1204.003-malicious_image\|T1204.003]] | [[T1204.003-malicious_image\|Malicious Image]] | Audit images deployed within the environment to ensure they do not contain any malicious components. |
| [[T1578.003-delete_cloud_instance\|T1578.003]] | [[T1578.003-delete_cloud_instance\|Delete Cloud Instance]] | Routinely check user permissions to ensure only the expected users have the capability to delete new instances. |
| [[T1612-build_image_on_host\|T1612]] | [[T1612-build_image_on_host\|Build Image on Host]] | Audit images deployed within the environment to ensure they do not contain any malicious components. |
| [[T1505.002-transport_agent\|T1505.002]] | [[T1505.002-transport_agent\|Transport Agent]] | Regularly check component software on critical services that adversaries may target for persistence to verify the integrity of the systems and identify if unexpected changes have been made.  |
| [[T1059-command_and_scripting_interpreter\|T1059]] | [[T1059-command_and_scripting_interpreter\|Command and Scripting Interpreter]] | Inventory systems for unauthorized command and scripting interpreter installations. |
| [[T1653-power_settings\|T1653]] | [[T1653-power_settings\|Power Settings]] | Periodically inspect systems for abnormal and unexpected power settings that may indicate malicious activty. |
| [[T1666-modify_cloud_resource_hierarchy\|T1666]] | [[T1666-modify_cloud_resource_hierarchy\|Modify Cloud Resource Hierarchy]] | Periodically audit resource groups in the cloud management console to ensure that only expected items exist, especially close to the top of the hierarchy (e.g., AWS accounts and Azure subscriptions). Typically, top-level accounts (such as the AWS management account) should not contain any workloads or resources.[^32]  |
| [[T1574.007-path_interception_by_path_environment_variable\|T1574.007]] | [[T1574.007-path_interception_by_path_environment_variable\|Path Interception by PATH Environment Variable]] | Find and eliminate path interception weaknesses in program configuration files, scripts, the PATH environment variable, services, and in shortcuts by surrounding PATH variables with quotation marks when functions allow for them. Be aware of the search order Windows uses for executing or loading binaries and use fully qualified paths wherever appropriate.<br><br>Clean up old Windows Registry keys when software is uninstalled to avoid keys with no associated legitimate binaries. Periodically search for and correct or report path interception weaknesses on systems that may have been introduced using custom or available tools that report software using insecure path configurations.[^21] [^38] [^14]  |
| [[T1036.010-masquerade_account_name\|T1036.010]] | [[T1036.010-masquerade_account_name\|Masquerade Account Name]] | Audit user accounts to ensure that each one has a defined purpose.   |
| [[T1114.003-email_forwarding_rule\|T1114.003]] | [[T1114.003-email_forwarding_rule\|Email Forwarding Rule]] | Enterprise email solutions have monitoring mechanisms that may include the ability to audit auto-forwarding rules on a regular basis.<br><br>In an Exchange environment, Administrators can use `Get-InboxRule` / `Remove-InboxRule` and `Get-TransportRule` / `Remove-TransportRule` to discover and remove potentially malicious auto-fowarding and transport rules.[^6] [^1] [^40]  In addition to this, a MAPI Editor can be utilized to examine the underlying database structure and discover any modifications/tampering of the properties of auto-forwarding rules.[^23]  |
| [[T1649-steal_or_forge_authentication_certificates\|T1649]] | [[T1649-steal_or_forge_authentication_certificates\|Steal or Forge Authentication Certificates]] | Check and remediate unneeded existing authentication certificates as well as common abusable misconfigurations of CA settings and permissions, such as AD CS certificate enrollment permissions and published overly permissive certificate templates (which define available settings for created certificates). For example, available AD CS certificate templates can be checked via the Certificate Authority MMC snap-in (`certsrv.msc`). `certutil.exe` can also be used to examine various information within an AD CS CA database.[^13] [^29] [^16]  |
| [[T1114-email_collection\|T1114]] | [[T1114-email_collection\|Email Collection]] | Enterprise email solutions have monitoring mechanisms that may include the ability to audit auto-forwarding rules on a regular basis.<br><br>In an Exchange environment, Administrators can use Get-InboxRule to discover and remove potentially malicious auto-forwarding rules.[^6]   |
| [[T1606-forge_web_credentials\|T1606]] | [[T1606-forge_web_credentials\|Forge Web Credentials]] | Administrators should perform an audit of all access lists and the permissions they have been granted to access web applications and services. This should be done extensively on all resources in order to establish a baseline, followed up on with periodic audits of new or updated resources. Suspicious accounts/credentials should be investigated and removed.<br> <br>Enable advanced auditing on ADFS. Check the success and failure audit options in the ADFS Management snap-in. Enable Audit Application Generated events on the AD FS farm via Group Policy Object.[^18]  |
| [[T1552.001-credentials_in_files\|T1552.001]] | [[T1552.001-credentials_in_files\|Credentials In Files]] | Preemptively search for files containing passwords and take actions to reduce the exposure risk when found. |
| [[T1548.006-tcc_manipulation\|T1548.006]] | [[T1548.006-tcc_manipulation\|TCC Manipulation]] | Routinely check applications using Automation under Security & Privacy System Preferences. To reset permissions, user's can utilize the `tccutil reset` command. When using Mobile Device Management (MDM), review the list of enabled or disabled applications in the `MDMOverrides.plist` which overrides the TCC database.[^19]  |
| [[T1530-data_from_cloud_storage\|T1530]] | [[T1530-data_from_cloud_storage\|Data from Cloud Storage]] | Frequently check permissions on cloud storage to ensure proper permissions are set to deny open or unprivileged access to resources.[^9]  |
| [[T1543.004-launch_daemon\|T1543.004]] | [[T1543.004-launch_daemon\|Launch Daemon]] | Use auditing tools capable of detecting folder permissions abuse opportunities on systems, especially reviewing changes made to folders by third-party software. |
| [[T1593-search_open_websites_domains\|T1593]] | [[T1593-search_open_websites_domains\|Search Open Websites／Domains]] | Scan public code repositories for exposed credentials or other sensitive information before making commits. Ensure that any leaked credentials are removed from the commit history, not just the current latest version of the code. |
| [[T1213-data_from_information_repositories\|T1213]] | [[T1213-data_from_information_repositories\|Data from Information Repositories]] | Consider periodic review of accounts and privileges for critical and sensitive repositories. Ensure that repositories such as cloud-hosted databases are not unintentionally exposed to the public, and that security groups assigned to them permit only necessary and authorized hosts.[^15]  |
| [[T1552.004-private_keys\|T1552.004]] | [[T1552.004-private_keys\|Private Keys]] | Ensure only authorized keys are allowed access to critical resources and audit access lists regularly. |
| [[T1542.005-tftp_boot\|T1542.005]] | [[T1542.005-tftp_boot\|TFTP Boot]] | Periodically check the integrity of the running configuration and system image to ensure they have not been modified. [^39]  [^36]  [^22]   |
| [[T1556-modify_authentication_process\|T1556]] | [[T1556-modify_authentication_process\|Modify Authentication Process]] | Review authentication logs to ensure that mechanisms such as enforcement of MFA are functioning as intended.<br><br>Periodically review the hybrid identity solution in use for any discrepancies. For example, review all Pass Through Authentication (PTA) agents in the Azure Management Portal to identify any unwanted or unapproved ones.[^26]  If ADFS is in use, review DLLs and executable files in the AD FS and Global Assembly Cache directories to ensure that they are signed by Microsoft. Note that in some cases binaries may be catalog-signed, which may cause the file to appear unsigned when viewing file properties.[^34] <br><br>Periodically review for new and unknown network provider DLLs within the Registry (`HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\<NetworkProviderName>\NetworkProvider\ProviderPath`). Ensure only valid network provider DLLs are registered. The name of these can be found in the Registry key at `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\NetworkProvider\Order`, and have corresponding service subkey pointing to a DLL at `HKEY_LOCAL_MACHINE\SYSTEM\CurrentC ontrolSet\Services\<NetworkProviderName>\NetworkProvider`. |
| [[T1558-steal_or_forge_kerberos_tickets\|T1558]] | [[T1558-steal_or_forge_kerberos_tickets\|Steal or Forge Kerberos Tickets]] | Perform audits or scans of systems, permissions, insecure software, insecure configurations, etc. to identify potential weaknesses. |
| [[T1686.003-windows_host_firewall\|T1686.003]] | [[T1686.003-windows_host_firewall\|Windows Host Firewall]] | Routinely check account role permissions to ensure only expected users and roles have permission to modify system firewalls. |
| [[T1525-implant_internal_image\|T1525]] | [[T1525-implant_internal_image\|Implant Internal Image]] | Periodically check the integrity of images and containers used in cloud deployments to ensure they have not been modified to include malicious software. |
| [[T1213.006-databases\|T1213.006]] | [[T1213.006-databases\|Databases]] | Consider periodic review of accounts and privileges for critical and sensitive databases.  |
| [[T1505.006-vsphere_installation_bundles\|T1505.006]] | [[T1505.006-vsphere_installation_bundles\|vSphere Installation Bundles]] | Periodically audit ESXi hosts to ensure that only approved VIBs are installed. The command `esxcli software vib list` lists installed VIBs, while the command `esxcli software vib signature verify` verifies the signatures of installed VIBs.[^7]  |
| [[T1593.003-code_repositories\|T1593.003]] | [[T1593.003-code_repositories\|Code Repositories]] | Scan public code repositories for exposed credentials or other sensitive information before making commits. Ensure that any leaked credentials are removed from the commit history, not just the current latest version of the code. |


## References

[^1]: [Microsoft Manage Mail Flow Rules 2023](https://learn.microsoft.com/en-us/exchange/security-and-compliance/mail-flow-rules/manage-mail-flow-rules)


[^2]: [Microsoft Preauthentication Jul 2012](https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-2000-server/cc961961(v=technet.10)?redirectedfrom=MSDN)


[^3]: [Secureworks - AT.exe Scheduled Task](https://www.secureworks.com/blog/where-you-at-indicators-of-lateral-movement-using-at-exe-on-windows-7-systems)


[^4]: [Brining MimiKatz to Unix](https://labs.portcullis.co.uk/download/eu-18-Wadhwa-Brown-Where-2-worlds-collide-Bringing-Mimikatz-et-al-to-UNIX.pdf)


[^5]: [CodeX Microsoft Defender 2021](https://medium.com/codex/my-learnings-on-microsoft-defender-for-endpoint-and-exclusions-ddacf2fdd047)


[^6]: [Microsoft Tim McMichael Exchange Mail Forwarding 2](https://blogs.technet.microsoft.com/timmcmic/2015/06/08/exchange-and-office-365-mail-forwarding-2/)


[^7]: [Google Cloud Threat Intelligence ESXi VIBs 2022](https://cloud.google.com/blog/topics/threat-intelligence/esxi-hypervisors-malware-persistence)


[^8]: [Stealthbits Cracking AS-REP Roasting Jun 2019](https://blog.stealthbits.com/cracking-active-directory-passwords-with-as-rep-roasting/)


[^9]: [Amazon S3 Security, 2019](https://aws.amazon.com/premiumsupport/knowledge-center/secure-s3-resources/)


[^10]: [Proofpoint TA427 April 2024](https://www.proofpoint.com/us/blog/threat-insight/social-engineering-dmarc-abuse-ta427s-art-information-gathering)


[^11]: [Kifarunix - Task Scheduling in Linux](https://kifarunix.com/scheduling-tasks-using-at-command-in-linux/)


[^12]: [Github UACMe](https://github.com/hfiref0x/UACME)


[^13]: [SpecterOps Certified Pre Owned](https://web.archive.org/web/20220818094600/https://specterops.io/assets/resources/Certified_Pre-Owned.pdf)


[^14]: [Vulnerability and Exploit Detector](https://skanthak.homepage.t-online.de/sentinel.html)


[^15]: [AWS DB VPC](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_VPC.WorkingWithRDSInstanceinaVPC.html)


[^16]: [GitHub Certify](https://github.com/GhostPack/Certify/)


[^17]: [Powersploit](https://github.com/mattifestation/PowerSploit)


[^18]: [FireEye ADFS](https://www.troopers.de/troopers19/agenda/fpxwmn/)


[^19]: [TCC macOS bypass](https://www.sentinelone.com/labs/bypassing-macos-tcc-user-privacy-protections-by-accident-and-design/)


[^20]: [Google Cloud Threat Intelligence ESXi Hardening 2023](https://cloud.google.com/blog/topics/threat-intelligence/vmware-detection-containment-hardening)


[^21]: [Microsoft CreateProcess](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessa)


[^22]: [Cisco IOS Software Integrity Assurance - Change Control](https://tools.cisco.com/security/center/resources/integrity_assurance.html#31)


[^23]: [Pfammatter - Hidden Inbox Rules](https://blog.compass-security.com/2018/09/hidden-inbox-rules-in-microsoft-exchange/)


[^24]: [W3C](https://www.w3.org/TR/fingerprinting-guidance/)


[^25]: [ADSecurity Finding Passwords in SYSVOL](https://adsecurity.org/?p=2288)


[^26]: [Mandiant Azure AD Backdoors](https://www.mandiant.com/resources/detecting-microsoft-365-azure-active-directory-backdoors)


[^27]: [GitHub Bloodhound](https://github.com/BloodHoundAD/BloodHound)


[^28]: [Kubernetes Hardening Guide](https://media.defense.gov/2022/Aug/29/2003066362/-1/-1/0/CTR_KUBERNETES_HARDENING_GUIDANCE_1.2_20220829.PDF)


[^29]: [GitHub PSPKIAudit](https://github.com/GhostPack/PSPKIAudit)


[^30]: [MITRE VMware Abuse 2024](https://medium.com/mitre-engenuity/infiltrating-defenses-abusing-vmware-in-mitres-cyber-intrusion-4ea647b83f5b)


[^31]: [audits linikatz](https://github.com/CiscoCXSecurity/linikatz/blob/master/blue/audit/audit.rules)


[^32]: [AWS Management Account Best Practices](https://docs.aws.amazon.com/organizations/latest/userguide/orgs_best-practices_mgmt-acct.html)


[^33]: [Mandiant Cloudy Logs 2023](https://www.mandiant.com/resources/blog/cloud-bad-log-configurations)


[^34]: [MagicWeb](https://www.microsoft.com/security/blog/2022/08/24/magicweb-nobeliums-post-compromise-trick-to-authenticate-as-anyone/)


[^35]: [Unit 42 Global Incident Response Report 2026](https://www.paloaltonetworks.com/resources/research/unit-42-incident-response-report#:~:text=The%20Browser%20Attack%20Surface:%20Attacks%20at%20the%20Human%20Interface&text=The%20site%20used%20social-engineering,deployment%20and%20broader%20operational%20disruption)


[^36]: [Cisco IOS Software Integrity Assurance - Image File Integrity](https://tools.cisco.com/security/center/resources/integrity_assurance.html#30)


[^37]: [Microsoft Sxstrace](https://docs.microsoft.com/windows-server/administration/windows-commands/sxstrace)


[^38]: [Microsoft Dynamic-Link Library Security](https://docs.microsoft.com/en-us/windows/win32/dlls/dynamic-link-library-security?redirectedfrom=MSDN)


[^39]: [Cisco IOS Software Integrity Assurance - Image File Verification](https://tools.cisco.com/security/center/resources/integrity_assurance.html#7)


[^40]: [Microsoft Get-InboxRule](https://docs.microsoft.com/en-us/powershell/module/exchange/get-inboxrule?view=exchange-ps)

