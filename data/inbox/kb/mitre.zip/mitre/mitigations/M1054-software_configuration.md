---
aliases: 
    - M1054
    
mitre-attack: https://attack.mitre.org/mitigations/M1054
---

## M1054

Software configuration refers to making security-focused adjustments to the settings of applications, middleware, databases, or other software to mitigate potential threats. These changes help reduce the attack surface, enforce best practices, and protect sensitive data. This mitigation can be implemented through the following measures:<br><br>Conduct a Security Review of Application Settings:<br><br>- Review the software documentation to identify recommended security configurations.<br>- Compare default settings against organizational policies and compliance requirements.<br><br>Implement Access Controls and Permissions:<br><br>- Restrict access to sensitive features or data within the software.<br>- Enforce least privilege principles for all roles and accounts interacting with the software.<br><br>Enable Logging and Monitoring:<br><br>- Configure detailed logging for key application events such as authentication failures, configuration changes, or unusual activity.<br>- Integrate logs with a centralized monitoring solution, such as a SIEM.<br><br>Update and Patch Software Regularly:<br><br>- Ensure the software is kept up-to-date with the latest security patches to address known vulnerabilities.<br>- Use automated patch management tools to streamline the update process.<br><br>Disable Unnecessary Features or Services:<br><br>- Turn off unused functionality or components that could introduce vulnerabilities, such as debugging interfaces or deprecated APIs.<br><br>Test Configuration Changes:<br><br>- Perform configuration changes in a staging environment before applying them in production.<br>- Conduct regular audits to ensure that settings remain aligned with security policies.<br><br>*Tools for Implementation*<br><br>Configuration Management Tools:<br><br>- Ansible: Automates configuration changes across multiple applications and environments.<br>- Chef: Ensures consistent application settings through code-based configuration management.<br>- Puppet: Automates software configurations and audits changes for compliance.<br><br>Security Benchmarking Tools:<br><br>- CIS-CAT: Provides benchmarks and audits for secure software configurations.<br>- Aqua Security Trivy: Scans containerized applications for configuration issues.<br><br>Vulnerability Management Solutions:<br><br>- Nessus: Identifies misconfigurations and suggests corrective actions.<br><br>Logging and Monitoring Tools:<br><br>- Splunk: Aggregates and analyzes application logs to detect suspicious activity.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1566.002-spearphishing_link\|T1566.002]] | [[T1566.002-spearphishing_link\|Spearphishing Link]] | Use anti-spoofing and email authentication mechanisms to filter messages based on validity checks of the sender domain (using SPF) and integrity of messages (using DKIM). Enabling these mechanisms within an organization (through policies such as DMARC) may enable recipients (intra-org and cross domain) to perform similar message filtering and validation.[^2] [^18] .<br><br>Furthermore, policies may enforce / install browser extensions that protect against IDN and homograph attacks. |
| [[T1688-safe_mode_boot\|T1688]] | [[T1688-safe_mode_boot\|Safe Mode Boot]] | Ensure that endpoint defenses run in safe mode.[^14]  |
| [[T1550.004-web_session_cookie\|T1550.004]] | [[T1550.004-web_session_cookie\|Web Session Cookie]] | Configure browsers or tasks to regularly delete persistent cookies. |
| [[T1602.001-snmp_mib_dump\|T1602.001]] | [[T1602.001-snmp_mib_dump\|SNMP (MIB Dump)]] | Allowlist MIB objects and implement SNMP views.[^9]  |
| [[T1539-steal_web_session_cookie\|T1539]] | [[T1539-steal_web_session_cookie\|Steal Web Session Cookie]] | Configure browsers or tasks to regularly delete persistent cookies.<br><br>Additionally, minimize the length of time a web cookie is viable to potentially reduce the impact of stolen cookies while also increasing the needed frequency of cookie theft attempts – providing defenders with additional chances at detection.[^5]  For example, use non-persistent cookies to limit the duration a session ID will remain on the web client cache where an attacker could obtain it.[^11]  |
| [[T1553.004-install_root_certificate\|T1553.004]] | [[T1553.004-install_root_certificate\|Install Root Certificate]] | HTTP Public Key Pinning (HPKP) is one method to mitigate potential [Adversary-in-the-Middle](https://attack.mitre.org/techniques/T1557) situations where and adversary uses a mis-issued or fraudulent certificate to intercept encrypted communications by enforcing use of an expected certificate. [^4]  |
| [[T1137.002-office_test\|T1137.002]] | [[T1137.002-office_test\|Office Test]] | Create the Registry key used to execute it and set the permissions to "Read Control" to prevent easy access to the key without administrator permissions or requiring Privilege Escalation.[^3]  |
| [[T1559-inter_process_communication\|T1559]] | [[T1559-inter_process_communication\|Inter-Process Communication]] | Consider disabling embedded files in Office programs, such as OneNote, that do not work with Protected View.[^15] [^1]  |
| [[T1666-modify_cloud_resource_hierarchy\|T1666]] | [[T1666-modify_cloud_resource_hierarchy\|Modify Cloud Resource Hierarchy]] | In Azure environments, consider setting a policy to block subscription transfers.[^7]  In AWS environments, consider using Service Control Policies to prevent the use of the `LeaveOrganization` API call.[^16]  |
| [[T1685-disable_or_modify_tools\|T1685]] | [[T1685-disable_or_modify_tools\|Disable or Modify Tools]] | Consider automatically relaunching forwarding mechanisms at recurring intervals (ex: temporal, on-logon, etc.) as well as applying appropriate change management to firewall rules and other related system configurations. |
| [[T1684.002-email_spoofing\|T1684.002]] | [[T1684.002-email_spoofing\|Email Spoofing]] | Use anti-spoofing and email authentication mechanisms to filter messages based on validity checks of the sender domain (using SPF) and integrity of messages (using DKIM). Enabling these mechanisms within an organization (through policies such as DMARC) may enable recipients (intra-org and cross domain) to perform similar message filtering and validation.[^2] [^18]  |
| [[T1213-data_from_information_repositories\|T1213]] | [[T1213-data_from_information_repositories\|Data from Information Repositories]] | Consider implementing data retention policies to automate periodically archiving and/or deleting data that is no longer needed.   |
| [[T1535-unused_unsupported_cloud_regions\|T1535]] | [[T1535-unused_unsupported_cloud_regions\|Unused／Unsupported Cloud Regions]] | Cloud service providers may allow customers to deactivate unused regions.[^10]  |
| [[T1598-phishing_for_information\|T1598]] | [[T1598-phishing_for_information\|Phishing for Information]] | Use anti-spoofing and email authentication mechanisms to filter messages based on validity checks of the sender domain (using SPF) and integrity of messages (using DKIM). Enabling these mechanisms within an organization (through policies such as DMARC) may enable recipients (intra-org and cross domain) to perform similar message filtering and validation.[^2] [^18]  |
| [[T1566-phishing\|T1566]] | [[T1566-phishing\|Phishing]] | Use anti-spoofing and email authentication mechanisms to filter messages based on validity checks of the sender domain (using SPF) and integrity of messages (using DKIM). Enabling these mechanisms within an organization (through policies such as DMARC) may enable recipients (intra-org and cross domain) to perform similar message filtering and validation.[^2] [^18]  |
| [[T1537-transfer_data_to_cloud_account\|T1537]] | [[T1537-transfer_data_to_cloud_account\|Transfer Data to Cloud Account]] | Configure appropriate data sharing restrictions in cloud services. For example, external sharing in Microsoft SharePoint and Google Drive can be turned off altogether, blocked for certain domains, or restricted to certain users.[^17]  [^6]  |
| [[T1677-poisoned_pipeline_execution\|T1677]] | [[T1677-poisoned_pipeline_execution\|Poisoned Pipeline Execution]] | Where possible, avoid allowing pipelines to run unreviewed code. Where this is necessary, ensure that these pipelines are executed on isolated nodes without access to secrets. In GitHub, avoid using the `pull_request_target` trigger if possible, do not treat user-controlled inputs (such as branch names) as trusted, and do not use self-hosted runners on public repositories.   |
| [[T1602-data_from_configuration_repository\|T1602]] | [[T1602-data_from_configuration_repository\|Data from Configuration Repository]] | Allowlist MIB objects and implement SNMP views.[^9]  |
| [[T1213.004-customer_relationship_management_software\|T1213.004]] | [[T1213.004-customer_relationship_management_software\|Customer Relationship Management Software]] | Consider implementing data retention policies to automate periodically archiving and/or deleting data that is no longer needed.    |
| [[T1543.005-container_service\|T1543.005]] | [[T1543.005-container_service\|Container Service]] | Where possible, consider enforcing the use of container services in rootless mode to limit the possibility of privilege escalation or malicious effects on the host running the container.   |
| [[T1689-downgrade_attack\|T1689]] | [[T1689-downgrade_attack\|Downgrade Attack]] | Consider implementing policies on internal web servers, such HTTP Strict Transport Security, that enforce the use of HTTPS/network traffic encryption to prevent insecure connections.[^13]  |
| [[T1602.002-network_device_configuration_dump\|T1602.002]] | [[T1602.002-network_device_configuration_dump\|Network Device Configuration Dump]] | Allowlist MIB objects and implement SNMP views. Disable Smart Install (SMI) if not used.[^9] [^8]   |
| [[T1566.001-spearphishing_attachment\|T1566.001]] | [[T1566.001-spearphishing_attachment\|Spearphishing Attachment]] | Use anti-spoofing and email authentication mechanisms to filter messages based on validity checks of the sender domain (using SPF) and integrity of messages (using DKIM). Enabling these mechanisms within an organization (through policies such as DMARC) may enable recipients (intra-org and cross domain) to perform similar message filtering and validation.[^2] [^18]  |
| [[T1559.002-dynamic_data_exchange\|T1559.002]] | [[T1559.002-dynamic_data_exchange\|Dynamic Data Exchange]] | Consider disabling embedded files in Office programs, such as OneNote, that do not work with Protected View.[^15] [^1]  |
| [[T1543-create_or_modify_system_process\|T1543]] | [[T1543-create_or_modify_system_process\|Create or Modify System Process]] | Where possible, consider enforcing the use of container services in rootless mode to limit the possibility of privilege escalation or malicious effects on the host running the container. |
| [[T1590.002-dns\|T1590.002]] | [[T1590.002-dns\|DNS]] | Consider implementing policies for DNS servers, such as Zone Transfer Policies, that enforce a list of validated servers permitted for zone transfers.[^12]  |
| [[T1213.006-databases\|T1213.006]] | [[T1213.006-databases\|Databases]] | Consider implementing data retention policies to automate periodically archiving and/or deleting data that is no longer needed.  |
| [[T1546.013-powershell_profile\|T1546.013]] | [[T1546.013-powershell_profile\|PowerShell Profile]] | Avoid PowerShell profiles if not needed. Use the -No Profile flag with when executing PowerShell scripts remotely to prevent local profiles and scripts from being executed. |
| [[T1555.005-password_managers\|T1555.005]] | [[T1555.005-password_managers\|Password Managers]] | Consider re-locking password managers after a short timeout to limit the time plaintext credentials live in memory from decrypted databases. |
| [[T1606-forge_web_credentials\|T1606]] | [[T1606-forge_web_credentials\|Forge Web Credentials]] | Configure browsers/applications to regularly delete persistent web credentials (such as cookies). |
| [[T1553-subvert_trust_controls\|T1553]] | [[T1553-subvert_trust_controls\|Subvert Trust Controls]] | HTTP Public Key Pinning (HPKP) is one method to mitigate potential [Adversary-in-the-Middle](https://attack.mitre.org/techniques/T1557) situations where and adversary uses a mis-issued or fraudulent certificate to intercept encrypted communications by enforcing use of an expected certificate. [^4]  |
| [[T1606.001-web_cookies\|T1606.001]] | [[T1606.001-web_cookies\|Web Cookies]] | Configure browsers/applications to regularly delete persistent web cookies. |
| [[T1667-email_bombing\|T1667]] | [[T1667-email_bombing\|Email Bombing]] | Use anti-spoofing and email authentication mechanisms to filter messages based on validity checks of the sender domain (using SPF) and integrity of messages (using DKIM). Enabling these mechanisms within an organization (through policies such as DMARC) may enable recipients (intra-org and cross domain) to perform similar message filtering and validation.[^2] [^18]  Note that additional filtering may be necessary if emails are coming from legitimate sources.  |
| [[T1137-office_application_startup\|T1137]] | [[T1137-office_application_startup\|Office Application Startup]] | For the Office Test method, create the Registry key used to execute it and set the permissions to "Read Control" to prevent easy access to the key without administrator permissions or requiring Privilege Escalation. [^3]  |
| [[T1598.002-spearphishing_attachment\|T1598.002]] | [[T1598.002-spearphishing_attachment\|Spearphishing Attachment]] | Use anti-spoofing and email authentication mechanisms to filter messages based on validity checks of the sender domain (using SPF) and integrity of messages (using DKIM). Enabling these mechanisms within an organization (through policies such as DMARC) may enable recipients (intra-org and cross domain) to perform similar message filtering and validation.[^2] [^18]  |
| [[T1598.003-spearphishing_link\|T1598.003]] | [[T1598.003-spearphishing_link\|Spearphishing Link]] | Use anti-spoofing and email authentication mechanisms to filter messages based on validity checks of the sender domain (using SPF) and integrity of messages (using DKIM). Enabling these mechanisms within an organization (through policies such as DMARC) may enable recipients (intra-org and cross domain) to perform similar message filtering and validation.[^2] [^18] <br><br>Furthermore, policies may enforce / install browser extensions that protect against IDN and homograph attacks. Browser password managers may also be configured to only populate credential fields when the URL matches that of the original, legitimate site.  |


## References

[^1]: [GitHub Disable DDEAUTO Oct 2017](https://gist.github.com/wdormann/732bb88d9b5dd5a66c9f1e1498f31a1b)


[^2]: [Microsoft Anti Spoofing](https://docs.microsoft.com/en-us/microsoft-365/security/office-365-security/anti-spoofing-protection?view=o365-worldwide)


[^3]: [Palo Alto Office Test Sofacy](https://researchcenter.paloaltonetworks.com/2016/07/unit42-technical-walkthrough-office-test-persistence-method-used-in-recent-sofacy-attacks/)


[^4]: [Wikipedia HPKP](https://en.wikipedia.org/wiki/HTTP_Public_Key_Pinning)


[^5]: [Token tactics](https://www.microsoft.com/en-us/security/blog/2022/11/16/token-tactics-how-to-prevent-detect-and-respond-to-cloud-token-theft/)


[^6]: [Microsoft 365 External Sharing](https://learn.microsoft.com/en-us/sharepoint/turn-external-sharing-on-or-off)


[^7]: [Azure Subscription Policies](https://learn.microsoft.com/en-us/azure/cost-management-billing/manage/manage-azure-subscription-policy)


[^8]: [US-CERT TA18-106A Network Infrastructure Devices 2018](https://us-cert.cisa.gov/ncas/alerts/TA18-106A)


[^9]: [Cisco Securing SNMP](https://www.cisco.com/c/en/us/support/docs/ip/simple-network-management-protocol-snmp/20370-snmpsecurity-20370.html)


[^10]: [CloudSploit - Unused AWS Regions](https://medium.com/cloudsploit/the-danger-of-unused-aws-regions-af0bf1b878fc)


[^11]: [Session Management Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html)


[^12]: [DNS-msft](https://learn.microsoft.com/en-us/windows-server/networking/dns/deploy/dns-policies-overview)


[^13]: [Chromium HSTS](https://www.chromium.org/hsts/)


[^14]: [CyberArk Labs Safe Mode 2016](https://www.cyberark.com/resources/blog/cyberark-labs-from-safe-mode-to-domain-compromise)


[^15]: [Enigma Reviving DDE Jan 2018](https://posts.specterops.io/reviving-dde-using-onenote-and-excel-for-code-execution-d7226864caee)


[^16]: [AWS RE:Inforce Threat Detection 2024](https://reinforce.awsevents.com/content/dam/reinforce/2024/slides/TDR432_New-tactics-and-techniques-for-proactive-threat-detection.pdf)


[^17]: [Google Workspace External Sharing](https://support.google.com/a/answer/60781)


[^18]: [ACSC Email Spoofing](https://web.archive.org/web/20210708014107/https://www.cyber.gov.au/sites/default/files/2019-03/spoof_email_sender_policy_framework.pdf)

