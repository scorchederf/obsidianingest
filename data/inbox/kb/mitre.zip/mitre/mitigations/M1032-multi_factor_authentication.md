---
aliases: 
    - M1032
    
mitre-attack: https://attack.mitre.org/mitigations/M1032
---

## M1032

Multi-Factor Authentication (MFA) enhances security by requiring users to provide at least two forms of verification to prove their identity before granting access. These factors typically include:<br><br>- *Something you know*: Passwords, PINs.<br>- *Something you have*: Physical tokens, smartphone authenticator apps.<br>- *Something you are*: Biometric data such as fingerprints, facial recognition, or retinal scans.<br><br>Implementing MFA across all critical systems and services ensures robust protection against account takeover and unauthorized access. This mitigation can be implemented through the following measures:<br><br>Identity and Access Management (IAM):<br><br>- Use IAM solutions like Azure Active Directory, Okta, or AWS IAM to enforce MFA policies for all user logins, especially for privileged roles.<br>- Enable conditional access policies to enforce MFA for risky sign-ins (e.g., unfamiliar devices, geolocations).<br>- Enable Conditional Access policies to only allow logins from trusted devices, such as those enrolled in Intune or joined via Hybrid/Entra.<br><br>Authentication Tools and Methods:<br><br>- Use authenticator applications such as Google Authenticator, Microsoft Authenticator, or Authy for time-based one-time passwords (TOTP).<br>- Deploy hardware-based tokens like YubiKey, RSA SecurID, or smart cards for additional security.<br>- Enforce biometric authentication for compatible devices and applications.<br><br>Secure Legacy Systems:<br><br>- Integrate MFA solutions with older systems using third-party tools like Duo Security or Thales SafeNet.<br>- Enable RADIUS/NPS servers to facilitate MFA for VPNs, RDP, and other network logins.<br><br>Monitoring and Alerting:<br><br>- Use SIEM tools to monitor failed MFA attempts, login anomalies, or brute-force attempts against MFA systems.<br>- Implement alerts for suspicious MFA activities, such as repeated failed codes or new device registrations.<br><br>Training and Policy Enforcement:<br><br>- Educate employees on the importance of MFA and secure authenticator usage.<br>- Enforce policies that require MFA on all critical systems, especially for remote access, privileged accounts, and cloud applications.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1098.001-additional_cloud_credentials\|T1098.001]] | [[T1098.001-additional_cloud_credentials\|Additional Cloud Credentials]] | Use multi-factor authentication for user and privileged accounts. Consider enforcing multi-factor authentication for the `CreateKeyPair` and `ImportKeyPair` API calls through IAM policies.[^5]  |
| [[T1040-network_sniffing\|T1040]] | [[T1040-network_sniffing\|Network Sniffing]] | Use multi-factor authentication wherever possible. |
| [[T1136.001-local_account\|T1136.001]] | [[T1136.001-local_account\|Local Account]] | Use multi-factor authentication for user and privileged accounts. |
| [[T1669-wi_fi_networks\|T1669]] | [[T1669-wi_fi_networks\|Wi-Fi Networks]] | Harden access requirements for Wi-Fi networks through using two or more pieces of evidence to authenticate, such as a username and password in addition to a token from a physical smart card or token generator. |
| [[T1556.003-pluggable_authentication_modules\|T1556.003]] | [[T1556.003-pluggable_authentication_modules\|Pluggable Authentication Modules]] | Integrating multi-factor authentication (MFA) as part of organizational policy can greatly reduce the risk of an adversary gaining control of valid credentials that may be used for additional tactics such as initial access, lateral movement, and collecting information. |
| [[T1556-modify_authentication_process\|T1556]] | [[T1556-modify_authentication_process\|Modify Authentication Process]] | Integrating multi-factor authentication (MFA) as part of organizational policy can greatly reduce the risk of an adversary gaining control of valid credentials that may be used for additional tactics such as initial access, lateral movement, and collecting information. MFA can also be used to restrict access to cloud resources and APIs.  |
| [[T1213-data_from_information_repositories\|T1213]] | [[T1213-data_from_information_repositories\|Data from Information Repositories]] | Use two or more pieces of evidence to authenticate to a system; such as username and password in addition to a token from a physical smart card or token generator. |
| [[T1599-network_boundary_bridging\|T1599]] | [[T1599-network_boundary_bridging\|Network Boundary Bridging]] | Use multi-factor authentication for user and privileged accounts. Most embedded network devices support TACACS+ and/or RADIUS.  Follow vendor prescribed best practices for hardening access control.[^4]  |
| [[T1114-email_collection\|T1114]] | [[T1114-email_collection\|Email Collection]] | Use of multi-factor authentication for public-facing webmail servers is a recommended best practice to minimize the usefulness of usernames and passwords to adversaries. |
| [[T1621-multi_factor_authentication_request_generation\|T1621]] | [[T1621-multi_factor_authentication_request_generation\|Multi-Factor Authentication Request Generation]] | Implement more secure 2FA/MFA mechanisms in replacement of simple push or one-click 2FA/MFA options. For example, having users enter a one-time code provided by the login screen into the 2FA/MFA application or utilizing other out-of-band 2FA/MFA mechanisms (such as rotating code-based hardware tokens providing rotating codes that need an accompanying user pin) may be more secure. Furthermore, change default configurations and implement limits upon the maximum number of 2FA/MFA request prompts that can be sent to users in period of time.[^3]  |
| [[T1078.001-default_accounts\|T1078.001]] | [[T1078.001-default_accounts\|Default Accounts]] | Implement multi-factor authentication (MFA) for default accounts whenever possible to prevent unauthorized access, even if credentials for these accounts are compromised. MFA adds an additional layer of security that requires more than just a username and password, making it significantly harder for adversaries to exploit these accounts for initial access or lateral movement. |
| [[T1601-modify_system_image\|T1601]] | [[T1601-modify_system_image\|Modify System Image]] | Use multi-factor authentication for user and privileged accounts. Most embedded network devices support TACACS+ and/or RADIUS.  Follow vendor prescribed best practices for hardening access control.[^4]  |
| [[T1078.002-domain_accounts\|T1078.002]] | [[T1078.002-domain_accounts\|Domain Accounts]] | Integrating multi-factor authentication (MFA) as part of organizational policy can greatly reduce the risk of an adversary gaining control of valid credentials that may be used for additional tactics such as initial access, lateral movement, and collecting information. MFA can also be used to restrict access to cloud resources and APIs. |
| [[T1136.002-domain_account\|T1136.002]] | [[T1136.002-domain_account\|Domain Account]] | Use multi-factor authentication for user and privileged accounts. |
| [[T1136.003-cloud_account\|T1136.003]] | [[T1136.003-cloud_account\|Cloud Account]] | Use multi-factor authentication for user and privileged accounts. |
| [[T1078.003-local_accounts\|T1078.003]] | [[T1078.003-local_accounts\|Local Accounts]] | Enable multi-factor authentication (MFA) for local accounts to add an extra layer of protection against credential theft and misuse. MFA can be implemented using methods like mobile-based authenticators or hardware tokens, even in environments that do not rely on domain controllers or cloud services. This additional security measure can help reduce the risk of adversaries gaining unauthorized access to local systems and resources. |
| [[T1098.005-device_registration\|T1098.005]] | [[T1098.005-device_registration\|Device Registration]] | Require multi-factor authentication to register devices in Entra ID.[^7]  Configure multi-factor authentication systems to disallow enrolling new devices for inactive accounts.[^10]  When first enrolling MFA, use conditional access policies to restrict device enrollment to trusted locations or devices, and consider using temporary access passes as an initial MFA solution to enroll a device.[^9]  |
| [[T1110.003-password_spraying\|T1110.003]] | [[T1110.003-password_spraying\|Password Spraying]] | Use multi-factor authentication. Where possible, also enable multi-factor authentication on externally facing services. |
| [[T1078.004-cloud_accounts\|T1078.004]] | [[T1078.004-cloud_accounts\|Cloud Accounts]] | Use multi-factor authentication for cloud accounts, especially privileged accounts. This can be implemented in a variety of forms (e.g. hardware, virtual, SMS), and can also be audited using administrative reporting features.[^2]  |
| [[T1601.002-downgrade_system_image\|T1601.002]] | [[T1601.002-downgrade_system_image\|Downgrade System Image]] | Use multi-factor authentication for user and privileged accounts. Most embedded network devices support TACACS+ and/or RADIUS.  Follow vendor prescribed best practices for hardening access control.[^4]  |
| [[T1098-account_manipulation\|T1098]] | [[T1098-account_manipulation\|Account Manipulation]] | Use multi-factor authentication for user and privileged accounts. |
| [[T1556.007-hybrid_identity\|T1556.007]] | [[T1556.007-hybrid_identity\|Hybrid Identity]] | Integrating multi-factor authentication (MFA) as part of organizational policy can greatly reduce the risk of an adversary gaining control of valid credentials that may be used for additional tactics such as initial access, lateral movement, and collecting information. MFA can also be used to restrict access to cloud resources and APIs.  |
| [[T1021.004-ssh\|T1021.004]] | [[T1021.004-ssh\|SSH]] | Require multi-factor authentication for SSH connections wherever possible, such as password protected SSH keys. |
| [[T1539-steal_web_session_cookie\|T1539]] | [[T1539-steal_web_session_cookie\|Steal Web Session Cookie]] | Deploy hardware-based token (e.g., YubiKey or FIDO key), which incorporates the target login domain as part of the negotiation protocol, will prevent session cookie theft through proxy methods.<br><br>Implement Conditional Access policies to only allow logins from trusted devices, such as those enrolled in Intune or joined via Hybrid/Entra. This mitigates the risk of session cookie replay attacks by ensuring that stolen tokens cannot be reused on unauthorized devices. |
| [[T1599.001-network_address_translation_traversal\|T1599.001]] | [[T1599.001-network_address_translation_traversal\|Network Address Translation Traversal]] | Use multi-factor authentication for user and privileged accounts. Most embedded network devices support TACACS+ and/or RADIUS.  Follow vendor prescribed best practices for hardening access control. [^4]  |
| [[T1098.003-additional_cloud_roles\|T1098.003]] | [[T1098.003-additional_cloud_roles\|Additional Cloud Roles]] | Use multi-factor authentication for user and privileged accounts. |
| [[T1110.001-password_guessing\|T1110.001]] | [[T1110.001-password_guessing\|Password Guessing]] | Use multi-factor authentication. Where possible, also enable multi-factor authentication on externally facing services. |
| [[T1114.002-remote_email_collection\|T1114.002]] | [[T1114.002-remote_email_collection\|Remote Email Collection]] | Use of multi-factor authentication for public-facing webmail servers is a recommended best practice to minimize the usefulness of usernames and passwords to adversaries. |
| [[T1199-trusted_relationship\|T1199]] | [[T1199-trusted_relationship\|Trusted Relationship]] | Require MFA for all delegated administrator accounts.[^1]  |
| [[T1021.001-remote_desktop_protocol\|T1021.001]] | [[T1021.001-remote_desktop_protocol\|Remote Desktop Protocol]] | Use multi-factor authentication for remote logins.[^8]  |
| [[T1078-valid_accounts\|T1078]] | [[T1078-valid_accounts\|Valid Accounts]] | Implement multi-factor authentication (MFA) across all account types, including default, local, domain, and cloud accounts, to prevent unauthorized access, even if credentials are compromised. MFA provides a critical layer of security by requiring multiple forms of verification beyond just a password. This measure significantly reduces the risk of adversaries abusing valid accounts to gain initial access, escalate privileges, maintain persistence, or evade defenses within your network. |
| [[T1136-create_account\|T1136]] | [[T1136-create_account\|Create Account]] | Use multi-factor authentication for user and privileged accounts. |
| [[T1556.001-domain_controller_authentication\|T1556.001]] | [[T1556.001-domain_controller_authentication\|Domain Controller Authentication]] | Integrating multi-factor authentication (MFA) as part of organizational policy can greatly reduce the risk of an adversary gaining control of valid credentials that may be used for additional tactics such as initial access, lateral movement, and collecting information. MFA can also be used to restrict access to cloud resources and APIs.  |
| [[T1485-data_destruction\|T1485]] | [[T1485-data_destruction\|Data Destruction]] | Implement multi-factor authentication (MFA) delete for cloud storage resources, such as AWS S3 buckets, to prevent unauthorized deletion of critical data and infrastructure. MFA delete requires additional authentication steps, making it significantly more difficult for adversaries to destroy data without proper credentials. This additional security layer helps protect against the impact of data destruction in cloud environments by ensuring that only authenticated actions can irreversibly delete storage or machine images. |
| [[T1098.006-additional_container_cluster_roles\|T1098.006]] | [[T1098.006-additional_container_cluster_roles\|Additional Container Cluster Roles]] | Require multi-factor authentication for user accounts integrated into container clusters through cloud deployments or via authentication protocols such as LDAP or SAML.  |
| [[T1021.007-cloud_services\|T1021.007]] | [[T1021.007-cloud_services\|Cloud Services]] | Use multi-factor authentication on cloud services whenever possible. |
| [[T1072-software_deployment_tools\|T1072]] | [[T1072-software_deployment_tools\|Software Deployment Tools]] | Ensure proper system and access isolation for critical network systems through use of multi-factor authentication. |
| [[T1110-brute_force\|T1110]] | [[T1110-brute_force\|Brute Force]] | Use multi-factor authentication. Where possible, also enable multi-factor authentication on externally facing services. |
| [[T1110.004-credential_stuffing\|T1110.004]] | [[T1110.004-credential_stuffing\|Credential Stuffing]] | Use multi-factor authentication. Where possible, also enable multi-factor authentication on externally facing services. |
| [[T1110.002-password_cracking\|T1110.002]] | [[T1110.002-password_cracking\|Password Cracking]] | Use multi-factor authentication. Where possible, also enable multi-factor authentication on externally facing services. |
| [[T1021-remote_services\|T1021]] | [[T1021-remote_services\|Remote Services]] | Use multi-factor authentication on remote service logons where possible. |
| [[T1133-external_remote_services\|T1133]] | [[T1133-external_remote_services\|External Remote Services]] | Use strong two-factor or multi-factor authentication for remote service accounts to mitigate an adversary's ability to leverage stolen credentials, but be aware of [Multi-Factor Authentication Interception](https://attack.mitre.org/techniques/T1111) techniques for some two-factor authentication implementations. |
| [[T1098.002-additional_email_delegate_permissions\|T1098.002]] | [[T1098.002-additional_email_delegate_permissions\|Additional Email Delegate Permissions]] | Use multi-factor authentication for user and privileged accounts. |
| [[T1556.006-multi_factor_authentication\|T1556.006]] | [[T1556.006-multi_factor_authentication\|Multi-Factor Authentication]] | Ensure that MFA and MFA policies and requirements are properly implemented for existing and deactivated or dormant accounts and devices. If possible, consider configuring MFA solutions to "fail closed" rather than grant access in case of serious errors. |
| [[T1530-data_from_cloud_storage\|T1530]] | [[T1530-data_from_cloud_storage\|Data from Cloud Storage]] | Consider using multi-factor authentication to restrict access to resources and cloud storage APIs.[^6]  |
| [[T1601.001-patch_system_image\|T1601.001]] | [[T1601.001-patch_system_image\|Patch System Image]] | Use multi-factor authentication for user and privileged accounts. Most embedded network devices support TACACS+ and/or RADIUS.  Follow vendor prescribed best practices for hardening access control.[^4]  |
| [[T1213.003-code_repositories\|T1213.003]] | [[T1213.003-code_repositories\|Code Repositories]] | Use multi-factor authentication for logons to code repositories. |
| [[T1556.004-network_device_authentication\|T1556.004]] | [[T1556.004-network_device_authentication\|Network Device Authentication]] | Use multi-factor authentication for user and privileged accounts. Most embedded network devices support TACACS+ and/or RADIUS.  Follow vendor prescribed best practices for hardening access control. [^4]  |


## References

[^1]: [Microsoft Nobelium Admin Privileges](https://www.microsoft.com/security/blog/2021/10/25/nobelium-targeting-delegated-administrative-privileges-to-facilitate-broader-attacks)


[^2]: [AWS - IAM Console Best Practices](https://aws.amazon.com/blogs/security/newly-updated-features-in-the-aws-iam-console-help-you-adhere-to-iam-best-practices/)


[^3]: [MFA Fatigue Attacks - PortSwigger](https://portswigger.net/daily-swig/mfa-fatigue-attacks-users-tricked-into-allowing-device-access-due-to-overload-of-push-notifications)


[^4]: [Cisco IOS Software Integrity Assurance - TACACS](https://tools.cisco.com/security/center/resources/integrity_assurance.html#39)


[^5]: [Expel IO Evil in AWS](https://expel.io/blog/finding-evil-in-aws/)


[^6]: [Amazon S3 Security, 2019](https://aws.amazon.com/premiumsupport/knowledge-center/secure-s3-resources/)


[^7]: [Microsoft - Device Registration](https://www.microsoft.com/security/blog/2022/01/26/evolved-phishing-device-registration-trick-adds-to-phishers-toolbox-for-victims-without-mfa)


[^8]: [Berkley Secure](https://security.berkeley.edu/node/94)


[^9]: [Mandiant APT29 Microsoft 365 2022](https://www.mandiant.com/resources/blog/apt29-continues-targeting-microsoft)


[^10]: [CISA MFA PrintNightmare](https://www.cisa.gov/uscert/ncas/alerts/aa22-074a)

