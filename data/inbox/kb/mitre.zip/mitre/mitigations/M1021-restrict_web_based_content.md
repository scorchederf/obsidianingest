---
aliases: 
    - M1021
    
mitre-attack: https://attack.mitre.org/mitigations/M1021
---

## M1021

Restricting web-based content involves enforcing policies and technologies that limit access to potentially malicious websites, unsafe downloads, and unauthorized browser behaviors. This can include URL filtering, download restrictions, script blocking, and extension control to protect against exploitation, phishing, and malware delivery. This mitigation can be implemented through the following measures:<br><br>Deploy Web Proxy Filtering:<br><br>- Use solutions to filter web traffic based on categories, reputation, and content types.<br>- Enforce policies that block unsafe websites or file types at the gateway level.<br><br>Enable DNS-Based Filtering:<br><br>- Implement tools to restrict access to domains associated with malware or phishing campaigns.<br>- Use public DNS filtering services to enhance protection.<br><br>Enforce Content Security Policies (CSP):<br><br>- Configure CSP headers on internal and external web applications to restrict script execution, iframe embedding, and cross-origin requests.<br><br>Control Browser Features:<br><br>- Disable unapproved browser features like automatic downloads, developer tools, or unsafe scripting.<br>- Enforce policies through tools like Group Policy Management to control browser settings.<br><br>Monitor and Alert on Web-Based Threats:<br><br>- Use SIEM tools to collect and analyze web proxy logs for signs of anomalous or malicious activity.<br>- Configure alerts for access attempts to blocked domains or repeated file download failures.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1659-content_injection\|T1659]] | [[T1659-content_injection\|Content Injection]] | Consider blocking download/transfer and execution of potentially uncommon file types known to be used in adversary campaigns. |
| [[T1102.002-bidirectional_communication\|T1102.002]] | [[T1102.002-bidirectional_communication\|Bidirectional Communication]] | Web proxies can be used to enforce external network communication policy that prevents use of unauthorized external services. |
| [[T1566.002-spearphishing_link\|T1566.002]] | [[T1566.002-spearphishing_link\|Spearphishing Link]] | Determine if certain websites that can be used for spearphishing are necessary for business operations and consider blocking access if activity cannot be monitored well or if it poses a significant risk. |
| [[T1528-steal_application_access_token\|T1528]] | [[T1528-steal_application_access_token\|Steal Application Access Token]] | Administrators can block end-user consent to OAuth applications, disabling users from authorizing third-party apps through OAuth 2.0 and forcing administrative consent for all requests. They can also block end-user registration of applications by their users, to reduce risk. A Cloud Access Security Broker can also be used to ban applications.<br><br>Azure offers a couple of enterprise policy settings in the Azure Management Portal that may help:<br><br>"Users -> User settings -> App registrations: Users can register applications" can be set to "no" to prevent users from registering new applications. <br>"Enterprise applications -> User settings -> Enterprise applications: Users can consent to apps accessing company data on their behalf" can be set to "no" to prevent users from consenting to allow third-party multi-tenant applications |
| [[T1539-steal_web_session_cookie\|T1539]] | [[T1539-steal_web_session_cookie\|Steal Web Session Cookie]] | Restrict or block web-based content that could be used to extract session cookies or credentials stored in browsers. Use browser security settings, such as disabling third-party cookies and restricting browser extensions, to limit the attack surface. |
| [[T1218.001-compiled_html_file\|T1218.001]] | [[T1218.001-compiled_html_file\|Compiled HTML File]] | Consider blocking download/transfer and execution of potentially uncommon file types known to be used in adversary campaigns, such as CHM files |
| [[T1568-dynamic_resolution\|T1568]] | [[T1568-dynamic_resolution\|Dynamic Resolution]] | In some cases a local DNS sinkhole may be used to help prevent behaviors associated with dynamic resolution. |
| [[T1102.001-dead_drop_resolver\|T1102.001]] | [[T1102.001-dead_drop_resolver\|Dead Drop Resolver]] | Web proxies can be used to enforce external network communication policy that prevents use of unauthorized external services. |
| [[T1204-user_execution\|T1204]] | [[T1204-user_execution\|User Execution]] | If a link is being visited by a user, block unknown or unused files in transit by default that should not be downloaded or by policy from suspicious sites as a best practice to prevent some vectors, such as .scr, .exe, .pif, .cpl, etc. Some download scanning devices can open and analyze compressed and encrypted formats, such as zip and rar that may be used to conceal malicious files. |
| [[T1133-external_remote_services\|T1133]] | [[T1133-external_remote_services\|External Remote Services]] | Restrict all traffic to and from public Tor nodes. [^1]  |
| [[T1189-drive_by_compromise\|T1189]] | [[T1189-drive_by_compromise\|Drive-by Compromise]] | Adblockers can help prevent malicious code served through ads from executing in the first place. Script blocking extensions can also help to prevent the execution of JavaScript. <br><br>Consider disabling browser push notifications from certain applications and browsers.[^5] [^3] [^6]  |
| [[T1566.003-spearphishing_via_service\|T1566.003]] | [[T1566.003-spearphishing_via_service\|Spearphishing via Service]] | Determine if certain social media sites, personal webmail services, or other service that can be used for spearphishing is necessary for business operations and consider blocking access if activity cannot be monitored well or if it poses a significant risk. |
| [[T1567-exfiltration_over_web_service\|T1567]] | [[T1567-exfiltration_over_web_service\|Exfiltration Over Web Service]] | Web proxies can be used to enforce an external network communication policy that prevents use of unauthorized external services. |
| [[T1568.002-domain_generation_algorithms\|T1568.002]] | [[T1568.002-domain_generation_algorithms\|Domain Generation Algorithms]] | In some cases a local DNS sinkhole may be used to help prevent DGA-based command and control at a reduced cost. |
| [[T1550.001-application_access_token\|T1550.001]] | [[T1550.001-application_access_token\|Application Access Token]] | Update corporate policies to restrict what types of third-party applications may be added to any online service or tool that is linked to the company's information, accounts or network (e.g., Google, Microsoft, Dropbox, Basecamp, GitHub). However, rather than providing high-level guidance on this, be extremely specific—include a list of per-approved applications and deny all others not on the list. Administrators may also block end-user consent through administrative portals, such as the Azure Portal, disabling users from authorizing third-party apps through OAuth and forcing administrative consent.[^4]  |
| [[T1102-web_service\|T1102]] | [[T1102-web_service\|Web Service]] | Web proxies can be used to enforce external network communication policy that prevents use of unauthorized external services. |
| [[T1566-phishing\|T1566]] | [[T1566-phishing\|Phishing]] | Determine if certain websites or attachment types (ex: .scr, .exe, .pif, .cpl, etc.) that can be used for phishing are necessary for business operations and consider blocking access if activity cannot be monitored well or if it poses a significant risk. |
| [[T1204.004-malicious_copy_and_paste\|T1204.004]] | [[T1204.004-malicious_copy_and_paste\|Malicious Copy and Paste]] | If a link is being requested by a user, block unknown or unused files in transit by default that should not be downloaded or by policy from suspicious sites as a best practice to prevent some vectors, such as `.scr`, `.exe`, `.pif`, `.cpl`, etc.   |
| [[T1059.005-visual_basic\|T1059.005]] | [[T1059.005-visual_basic\|Visual Basic]] | Script blocking extensions can help prevent the execution of scripts and HTA files that may commonly be used during the exploitation process. For malicious code served up through ads, adblockers can help prevent that code from executing in the first place. |
| [[T1102.003-one_way_communication\|T1102.003]] | [[T1102.003-one_way_communication\|One-Way Communication]] | Web proxies can be used to enforce external network communication policy that prevents use of unauthorized external services. |
| [[T1127-trusted_developer_utilities_proxy_execution\|T1127]] | [[T1127-trusted_developer_utilities_proxy_execution\|Trusted Developer Utilities Proxy Execution]] | Consider disabling software installation or execution from the internet via developer utilities. |
| [[T1059.007-javascript\|T1059.007]] | [[T1059.007-javascript\|JavaScript]] | Script blocking extensions can help prevent the execution of JavaScript and HTA files that may commonly be used during the exploitation process. For malicious code served up through ads, adblockers can help prevent that code from executing in the first place. |
| [[T1555.003-credentials_from_web_browsers\|T1555.003]] | [[T1555.003-credentials_from_web_browsers\|Credentials from Web Browsers]] | Restrict or block web-based content that could be used to extract session cookies or credentials stored in browsers. Use browser security settings, such as disabling third-party cookies and restricting browser extensions, to limit the attack surface. |
| [[T1567.002-exfiltration_to_cloud_storage\|T1567.002]] | [[T1567.002-exfiltration_to_cloud_storage\|Exfiltration to Cloud Storage]] | Web proxies can be used to enforce an external network communication policy that prevents use of unauthorized external services. |
| [[T1059-command_and_scripting_interpreter\|T1059]] | [[T1059-command_and_scripting_interpreter\|Command and Scripting Interpreter]] | Script blocking extensions can help prevent the execution of scripts and HTA files that may commonly be used during the exploitation process. For malicious code served up through ads, adblockers can help prevent that code from executing in the first place. |
| [[T1218-system_binary_proxy_execution\|T1218]] | [[T1218-system_binary_proxy_execution\|System Binary Proxy Execution]] | Restrict use of certain websites, block downloads/attachments, block Javascript, restrict browser extensions, etc. |
| [[T1567.001-exfiltration_to_code_repository\|T1567.001]] | [[T1567.001-exfiltration_to_code_repository\|Exfiltration to Code Repository]] | Web proxies can be used to enforce an external network communication policy that prevents use of unauthorized external services. |
| [[T1127.002-clickonce\|T1127.002]] | [[T1127.002-clickonce\|ClickOnce]] | Disable ClickOnce installations from the internet using the following registry key: <br>`\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\.NETFramework\Security\TrustManager\PromptingLevel — Internet:Disabled`[^2]  |
| [[T1567.003-exfiltration_to_text_storage_sites\|T1567.003]] | [[T1567.003-exfiltration_to_text_storage_sites\|Exfiltration to Text Storage Sites]] | Web proxies can be used to enforce an external network communication policy that prevents use of unauthorized external services. |
| [[T1204.001-malicious_link\|T1204.001]] | [[T1204.001-malicious_link\|Malicious Link]] | If a link is being visited by a user, block unknown or unused files in transit by default that should not be downloaded or by policy from suspicious sites as a best practice to prevent some vectors, such as .scr, .exe, .pif, .cpl, etc. Some download scanning devices can open and analyze compressed and encrypted formats, such as zip and rar that may be used to conceal malicious files. |
| [[T1566.001-spearphishing_attachment\|T1566.001]] | [[T1566.001-spearphishing_attachment\|Spearphishing Attachment]] | Block unknown or unused attachments by default that should not be transmitted over email as a best practice to prevent some vectors, such as .scr, .exe, .pif, .cpl, etc. Some email scanning devices can open and analyze compressed and encrypted formats, such as zip and rar that may be used to conceal malicious attachments. |


## References

[^1]: [Defending Against Malicious Cyber Activity Originating from Tor](https://www.cisa.gov/sites/default/files/publications/AA20-183A_Defending_Against_Malicious_Cyber_Activity_Originating_from_Tor_S508C.pdf)


[^2]: [NetSPI ClickOnce](https://www.netspi.com/blog/technical-blog/adversary-simulation/all-you-need-is-one-a-clickonce-love-story/)


[^3]: [push notifications -infosecinstitute](https://www.infosecinstitute.com/resources/security-awareness/malicious-push-notifications-is-that-a-real-or-fake-windows-defender-update/)


[^4]: [Microsoft Azure AD Admin Consent](https://docs.microsoft.com/en-us/azure/security/fundamentals/steps-secure-identity#block-end-user-consent)


[^5]: [mac security virus popup](https://macsecurity.net/view/543-remove-guroshied-mac)


[^6]: [site notifications - krebsonsecurity](https://krebsonsecurity.com/2020/11/be-very-sparing-in-allowing-site-notifications/)

