---
aliases: 
    - M1057
    
mitre-attack: https://attack.mitre.org/mitigations/M1057
---

## M1057

Data Loss Prevention (DLP) involves implementing strategies and technologies to identify, categorize, monitor, and control the movement of sensitive data within an organization. This includes protecting data formats indicative of Personally Identifiable Information (PII), intellectual property, or financial data from unauthorized access, transmission, or exfiltration. DLP solutions integrate with network, endpoint, and cloud platforms to enforce security policies and prevent accidental or malicious data leaks. [^1]  This mitigation can be implemented through the following measures:<br><br>Sensitive Data Categorization:<br><br>- Use Case: Identify and classify data based on sensitivity (e.g., PII, financial data, trade secrets).<br>- Implementation: Use DLP solutions to scan and tag files containing sensitive information using predefined patterns, such as Social Security Numbers or credit card details.<br><br>Exfiltration Restrictions:<br><br>- Use Case: Prevent unauthorized transmission of sensitive data.<br>- Implementation: Enforce policies to block unapproved email attachments, unauthorized USB usage, or unencrypted data uploads to cloud storage.<br><br>Data-in-Transit Monitoring:<br><br>- Use Case: Detect and prevent the transmission of sensitive data over unapproved channels.<br>- Implementation: Deploy network-based DLP tools to inspect outbound traffic for sensitive content (e.g., financial records or PII) and block unapproved transmissions.<br><br>Endpoint Data Protection:<br><br>- Use Case: Monitor and control sensitive data usage on endpoints.<br>- Implementation: Use endpoint-based DLP agents to block copy-paste actions of sensitive data and unauthorized printing or file sharing.<br><br>Cloud Data Security:<br><br>- Use Case: Protect data stored in cloud platforms.<br>- Implementation: Integrate DLP with cloud storage platforms like Google Drive, OneDrive, or AWS to monitor and restrict sensitive data sharing or downloads.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1052-exfiltration_over_physical_medium\|T1052]] | [[T1052-exfiltration_over_physical_medium\|Exfiltration Over Physical Medium]] | Data loss prevention can detect and block sensitive data being copied to physical mediums. |
| [[T1537-transfer_data_to_cloud_account\|T1537]] | [[T1537-transfer_data_to_cloud_account\|Transfer Data to Cloud Account]] | Data loss prevention can prevent and block sensitive data from being shared with individuals outside an organization.[^2]  [^3]  |
| [[T1005-data_from_local_system\|T1005]] | [[T1005-data_from_local_system\|Data from Local System]] | Data loss prevention can restrict access to sensitive data and detect sensitive data that is unencrypted. |
| [[T1048-exfiltration_over_alternative_protocol\|T1048]] | [[T1048-exfiltration_over_alternative_protocol\|Exfiltration Over Alternative Protocol]] | Data loss prevention can detect and block sensitive data being uploaded via web browsers. |
| [[T1567-exfiltration_over_web_service\|T1567]] | [[T1567-exfiltration_over_web_service\|Exfiltration Over Web Service]] | Data loss prevention can be detect and block sensitive data being uploaded to web services via web browsers. |
| [[T1048.003-exfiltration_over_unencrypted_non_c2_protocol\|T1048.003]] | [[T1048.003-exfiltration_over_unencrypted_non_c2_protocol\|Exfiltration Over Unencrypted Non-C2 Protocol]] | Data loss prevention can detect and block sensitive data being sent over unencrypted protocols. |
| [[T1041-exfiltration_over_c2_channel\|T1041]] | [[T1041-exfiltration_over_c2_channel\|Exfiltration Over C2 Channel]] | Data loss prevention can detect and block sensitive data being sent over unencrypted protocols. |
| [[T1025-data_from_removable_media\|T1025]] | [[T1025-data_from_removable_media\|Data from Removable Media]] | Data loss prevention can restrict access to sensitive data and detect sensitive data that is unencrypted. |
| [[T1052.001-exfiltration_over_usb\|T1052.001]] | [[T1052.001-exfiltration_over_usb\|Exfiltration over USB]] | Data loss prevention can detect and block sensitive data being copied to USB devices. |
| [[T1048.002-exfiltration_over_asymmetric_encrypted_non_c2_protocol\|T1048.002]] | [[T1048.002-exfiltration_over_asymmetric_encrypted_non_c2_protocol\|Exfiltration Over Asymmetric Encrypted Non-C2 Protocol]] | Data loss prevention can detect and block sensitive data being uploaded via web browsers. |
| [[T1567.004-exfiltration_over_webhook\|T1567.004]] | [[T1567.004-exfiltration_over_webhook\|Exfiltration Over Webhook]] | Data loss prevention can be detect and block sensitive data being uploaded to web services via web browsers. |
| [[T1020.001-traffic_duplication\|T1020.001]] | [[T1020.001-traffic_duplication\|Traffic Duplication]] | Implement Data Loss Prevention (DLP) solutions to monitor, detect, and control the flow of sensitive information. DLP tools can be configured to block unauthorized attempts to exfiltrate data, such as preventing emails from being forwarded to external recipients or monitoring for suspicious data transfers. By creating email flow rules and applying policies to detect anomalies, DLP solutions help mitigate the risk of data exfiltration over alternative protocols. |


## References

[^1]: [PurpleSec Data Loss Prevention](https://purplesec.us/data-loss-prevention/)


[^2]: [Microsoft Purview Data Loss Prevention](https://learn.microsoft.com/en-us/purview/dlp-learn-about-dlp)


[^3]: [Google Workspace Data Loss Prevention](https://support.google.com/a/answer/9646351)

