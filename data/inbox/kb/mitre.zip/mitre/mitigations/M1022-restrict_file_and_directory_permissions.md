---
aliases: 
    - M1022
    
mitre-attack: https://attack.mitre.org/mitigations/M1022
---

## M1022

Restricting file and directory permissions involves setting access controls at the file system level to limit which users, groups, or processes can read, write, or execute files. By configuring permissions appropriately, organizations can reduce the attack surface for adversaries seeking to access sensitive data, plant malicious code, or tamper with system files.<br><br>Enforce Least Privilege Permissions:<br><br>- Remove unnecessary write permissions on sensitive files and directories.<br>- Use file ownership and groups to control access for specific roles.<br><br>Example (Windows): Right-click the shared folder → Properties → Security tab → Adjust permissions for NTFS ACLs.<br><br>Harden File Shares:<br><br>- Disable anonymous access to shared folders.<br>- Enforce NTFS permissions for shared folders on Windows.<br><br>Example: Set permissions to restrict write access to critical files, such as system executables (e.g., `/bin` or `/sbin` on Linux). Use tools like `chown` and `chmod` to assign file ownership and limit access.<br><br>On Linux, apply:<br>`chmod 750 /etc/sensitive.conf`<br>`chown root:admin /etc/sensitive.conf`<br><br>File Integrity Monitoring (FIM):<br><br>- Use tools like Tripwire, Wazuh, or OSSEC to monitor changes to critical file permissions.<br><br>Audit File System Access:<br><br>- Enable auditing to track permission changes or unauthorized access attempts.<br>- Use auditd (Linux) or Event Viewer (Windows) to log activities.<br><br>Restrict Startup Directories:<br><br>- Configure permissions to prevent unauthorized writes to directories like `C:\ProgramData\Microsoft\Windows\Start Menu`.<br><br>Example: Restrict write access to critical directories like `/etc/`, `/usr/local/`, and Windows directories such as `C:\Windows\System32`.<br><br>- On Windows, use icacls to modify permissions: `icacls "C:\Windows\System32" /inheritance:r /grant:r SYSTEM:(OI)(CI)F`<br>- On Linux, monitor permissions using tools like `lsattr` or `auditd`.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1036.005-match_legitimate_resource_name_or_location\|T1036.005]] | [[T1036.005-match_legitimate_resource_name_or_location\|Match Legitimate Resource Name or Location]] | Use file system access controls to protect folders such as `C:\Windows\System32`. |
| [[T1565.001-stored_data_manipulation\|T1565.001]] | [[T1565.001-stored_data_manipulation\|Stored Data Manipulation]] | Ensure least privilege principles are applied to important information resources to reduce exposure to data manipulation risk. |
| [[T1037.004-rc_scripts\|T1037.004]] | [[T1037.004-rc_scripts\|RC Scripts]] | Limit privileges of user accounts so only authorized users can edit the `rc.common` file. |
| [[T1222.002-linux_and_mac_permissions\|T1222.002]] | [[T1222.002-linux_and_mac_permissions\|Linux and Mac Permissions]] | Applying more restrictive permissions to files and directories could prevent adversaries from modifying the access control lists. |
| [[T1037.005-startup_items\|T1037.005]] | [[T1037.005-startup_items\|Startup Items]] | Since StartupItems are deprecated, preventing all users from writing to the `/Library/StartupItems` directory would prevent any startup items from getting registered. |
| [[T1053.006-systemd_timers\|T1053.006]] | [[T1053.006-systemd_timers\|Systemd Timers]] | Restrict read/write access to systemd `.timer` unit files to only select privileged users who have a legitimate need to manage system services. |
| [[T1218.002-control_panel\|T1218.002]] | [[T1218.002-control_panel\|Control Panel]] | Restrict storage and execution of Control Panel items to protected directories, such as `C:\Windows`, rather than user directories. |
| [[T1547.003-time_providers\|T1547.003]] | [[T1547.003-time_providers\|Time Providers]] | Consider using Group Policy to configure and block additions/modifications to W32Time DLLs. [^1]  |
| [[T1574.004-dylib_hijacking\|T1574.004]] | [[T1574.004-dylib_hijacking\|Dylib Hijacking]] | Set directory access controls to prevent file writes to the search paths for applications, both in the folders where applications are run from and the standard dylib folders. |
| [[T1222.001-windows_permissions\|T1222.001]] | [[T1222.001-windows_permissions\|Windows Permissions]] | Applying more restrictive permissions to files and directories could prevent adversaries from modifying the access control lists. |
| [[T1037.003-network_logon_script\|T1037.003]] | [[T1037.003-network_logon_script\|Network Logon Script]] | Restrict write access to logon scripts to specific administrators. |
| [[T1686.003-windows_host_firewall\|T1686.003]] | [[T1686.003-windows_host_firewall\|Windows Host Firewall]] | Ensure proper process and file permissions are in place to prevent adversaries from disabling or modifying firewall settings. |
| [[T1098.004-ssh_authorized_keys\|T1098.004]] | [[T1098.004-ssh_authorized_keys\|SSH Authorized Keys]] | Restrict access to the `authorized_keys` file. |
| [[T1565.003-runtime_data_manipulation\|T1565.003]] | [[T1565.003-runtime_data_manipulation\|Runtime Data Manipulation]] | Prevent critical business and system processes from being replaced, overwritten, or reconfigured to load potentially malicious code. |
| [[T1552.004-private_keys\|T1552.004]] | [[T1552.004-private_keys\|Private Keys]] | Ensure permissions are properly set on folders containing sensitive private keys to prevent unintended access. Additionally, on Cisco devices, set the `nonexportable` flag during RSA key pair generation.[^6]  |
| [[T1055.009-proc_memory\|T1055.009]] | [[T1055.009-proc_memory\|Proc Memory]] | Restrict the permissions on sensitive files such as `/proc/[pid]/maps` or `/proc/[pid]/mem`.  |
| [[T1685-disable_or_modify_tools\|T1685]] | [[T1685-disable_or_modify_tools\|Disable or Modify Tools]] | Ensure proper process and file permissions are in place to prevent adversaries from disabling or interfering with security services. |
| [[T1686-disable_or_modify_system_firewall\|T1686]] | [[T1686-disable_or_modify_system_firewall\|Disable or Modify System Firewall]] | Ensure proper process and file permissions are in place to prevent adversaries from disabling or modifying firewall settings. |
| [[T1574.007-path_interception_by_path_environment_variable\|T1574.007]] | [[T1574.007-path_interception_by_path_environment_variable\|Path Interception by PATH Environment Variable]] | Ensure that proper permissions and directory access control are set to deny users the ability to write files to the top-level directory `C:` and system directories, such as `C:\Windows\`, to reduce places where malicious files could be placed for execution. Require that all executables be placed in write-protected directories. |
| [[T1547.013-xdg_autostart_entries\|T1547.013]] | [[T1547.013-xdg_autostart_entries\|XDG Autostart Entries]] | Restrict write access to XDG autostart entries to only select privileged users. |
| [[T1564.004-ntfs_file_attributes\|T1564.004]] | [[T1564.004-ntfs_file_attributes\|NTFS File Attributes]] | Consider adjusting read and write permissions for NTFS EA, though this should be tested to ensure routine OS operations are not impeded. [^4]  |
| [[T1543.001-launch_agent\|T1543.001]] | [[T1543.001-launch_agent\|Launch Agent]] | Set group policies to restrict file permissions to the `~/launchagents` folder.[^3]  |
| [[T1574.008-path_interception_by_search_order_hijacking\|T1574.008]] | [[T1574.008-path_interception_by_search_order_hijacking\|Path Interception by Search Order Hijacking]] | Ensure that proper permissions and directory access control are set to deny users the ability to write files to the top-level directory `C:` and system directories, such as `C:\Windows\`, to reduce places where malicious files could be placed for execution. Require that all executables be placed in write-protected directories. |
| [[T1546.013-powershell_profile\|T1546.013]] | [[T1546.013-powershell_profile\|PowerShell Profile]] | Making PowerShell profiles immutable and only changeable by certain administrators will limit the ability for adversaries to easily create user level persistence. |
| [[T1070-indicator_removal\|T1070]] | [[T1070-indicator_removal\|Indicator Removal]] | Protect generated event files that are stored locally with proper permissions and authentication and limit opportunities for adversaries to increase privileges by preventing Privilege Escalation opportunities. |
| [[T1098-account_manipulation\|T1098]] | [[T1098-account_manipulation\|Account Manipulation]] | Restrict access to potentially sensitive files that deal with authentication and/or authorization. |
| [[T1574-hijack_execution_flow\|T1574]] | [[T1574-hijack_execution_flow\|Hijack Execution Flow]] | Install software in write-protected locations. Set directory access controls to prevent file writes to the search paths for applications, both in the folders where applications are run from and the standard library folders. |
| [[T1036-masquerading\|T1036]] | [[T1036-masquerading\|Masquerading]] | Use file system access controls to protect folders such as C:\\Windows\\System32. |
| [[T1547.009-shortcut_modification\|T1547.009]] | [[T1547.009-shortcut_modification\|Shortcut Modification]] | Applying strict permissions to directories where shortcuts are stored, such as the startup folder, can prevent unauthorized modifications. |
| [[T1222-file_and_directory_permissions_modification\|T1222]] | [[T1222-file_and_directory_permissions_modification\|File and Directory Permissions Modification]] | Applying more restrictive permissions to files and directories could prevent adversaries from modifying their access control lists. Additionally, ensure that user settings regarding local and remote symbolic links are properly set or disabled where unneeded.[^5]  |
| [[T1053-scheduled_task_job\|T1053]] | [[T1053-scheduled_task_job\|Scheduled Task／Job]] | Restrict access by setting directory and file permissions that are not specific to users or privileged accounts. |
| [[T1563.001-ssh_hijacking\|T1563.001]] | [[T1563.001-ssh_hijacking\|SSH Hijacking]] | Ensure proper file permissions are set and harden system to prevent root privilege escalation opportunities. |
| [[T1070.008-clear_mailbox_data\|T1070.008]] | [[T1070.008-clear_mailbox_data\|Clear Mailbox Data]] | Protect generated event files that are stored locally with proper permissions and authentication and limit opportunities for adversaries to increase privileges by preventing Privilege Escalation opportunities.  |
| [[T1548.003-sudo_and_sudo_caching\|T1548.003]] | [[T1548.003-sudo_and_sudo_caching\|Sudo and Sudo Caching]] | The sudoers file should be strictly edited such that passwords are always required and that users can't spawn risky processes as users with higher privilege. |
| [[T1070.009-clear_persistence\|T1070.009]] | [[T1070.009-clear_persistence\|Clear Persistence]] | Protect generated event files that are stored locally with proper permissions and authentication and limit opportunities for adversaries to increase privileges by preventing Privilege Escalation opportunities.  |
| [[T1552-unsecured_credentials\|T1552]] | [[T1552-unsecured_credentials\|Unsecured Credentials]] | Restrict file shares to specific directories with access only to necessary users. |
| [[T1543.002-systemd_service\|T1543.002]] | [[T1543.002-systemd_service\|Systemd Service]] | Restrict read/write access to systemd unit files to only select privileged users who have a legitimate need to manage system services. |
| [[T1070.003-clear_command_history\|T1070.003]] | [[T1070.003-clear_command_history\|Clear Command History]] | Preventing users from deleting or writing to certain files can stop adversaries from maliciously altering their `~/.bash_history` or `ConsoleHost_history.txt` files. |
| [[T1543-create_or_modify_system_process\|T1543]] | [[T1543-create_or_modify_system_process\|Create or Modify System Process]] | Restrict read/write access to system-level process files to only select privileged users who have a legitimate need to manage system services. |
| [[T1037.002-login_hook\|T1037.002]] | [[T1037.002-login_hook\|Login Hook]] | Restrict write access to logon scripts to specific administrators. |
| [[T1685.006-clear_linux_or_mac_system_logs\|T1685.006]] | [[T1685.006-clear_linux_or_mac_system_logs\|Clear Linux or Mac System Logs]] | Protect generated event files that are stored locally with proper permissions and authentication and limit opportunities for adversaries to increase privileges by preventing Privilege Escalation opportunities. |
| [[T1556-modify_authentication_process\|T1556]] | [[T1556-modify_authentication_process\|Modify Authentication Process]] | Restrict write access to the `/Library/Security/SecurityAgentPlugins` directory. |
| [[T1548-abuse_elevation_control_mechanism\|T1548]] | [[T1548-abuse_elevation_control_mechanism\|Abuse Elevation Control Mechanism]] | The sudoers file should be strictly edited such that passwords are always required and that users can't spawn risky processes as users with higher privilege. |
| [[T1546.004-unix_shell_configuration_modification\|T1546.004]] | [[T1546.004-unix_shell_configuration_modification\|Unix Shell Configuration Modification]] | Making these files immutable and only changeable by certain administrators will limit the ability for adversaries to easily create user level persistence. |
| [[T1530-data_from_cloud_storage\|T1530]] | [[T1530-data_from_cloud_storage\|Data from Cloud Storage]] | Use access control lists on storage systems and objects. |
| [[T1574.014-appdomainmanager\|T1574.014]] | [[T1574.014-appdomainmanager\|AppDomainManager]] | Install .NET applications and related software in write-protected locations. Set directory access controls to prevent file writes to the search paths for .NET applications, both in the folders where applications are run from and the standard resources folders. |
| [[T1574.009-path_interception_by_unquoted_path\|T1574.009]] | [[T1574.009-path_interception_by_unquoted_path\|Path Interception by Unquoted Path]] | Ensure that proper permissions and directory access control are set to deny users the ability to write files to the top-level directory `C:` and system directories, such as `C:\Windows\`, to reduce places where malicious files could be placed for execution. Require that all executables be placed in write-protected directories. |
| [[T1565-data_manipulation\|T1565]] | [[T1565-data_manipulation\|Data Manipulation]] | Ensure least privilege principles are applied to important information resources to reduce exposure to data manipulation risk. |
| [[T1569-system_services\|T1569]] | [[T1569-system_services\|System Services]] | Ensure that high permission level service binaries cannot be replaced or modified by users with a lower permission level. |
| [[T1569.002-service_execution\|T1569.002]] | [[T1569.002-service_execution\|Service Execution]] | Ensure that high permission level service binaries cannot be replaced or modified by users with a lower permission level. |
| [[T1037-boot_or_logon_initialization_scripts\|T1037]] | [[T1037-boot_or_logon_initialization_scripts\|Boot or Logon Initialization Scripts]] | Restrict write access to logon scripts to specific administrators. |
| [[T1685.005-clear_windows_event_logs\|T1685.005]] | [[T1685.005-clear_windows_event_logs\|Clear Windows Event Logs]] | Protect generated event files that are stored locally with proper permissions and authentication and limit opportunities for adversaries to increase privileges by preventing Privilege Escalation opportunities. |
| [[T1489-service_stop\|T1489]] | [[T1489-service_stop\|Service Stop]] | Ensure proper process and file permissions are in place to inhibit adversaries from disabling or interfering with critical services. |
| [[T1048-exfiltration_over_alternative_protocol\|T1048]] | [[T1048-exfiltration_over_alternative_protocol\|Exfiltration Over Alternative Protocol]] | Use access control lists on cloud storage systems and objects.  |
| [[T1036.003-rename_legitimate_utilities\|T1036.003]] | [[T1036.003-rename_legitimate_utilities\|Rename Legitimate Utilities]] | Use file system access controls to protect folders such as `C:\Windows\System32`.  |
| [[T1080-taint_shared_content\|T1080]] | [[T1080-taint_shared_content\|Taint Shared Content]] | Protect shared folders by minimizing users who have write access. |
| [[T1553.003-sip_and_trust_provider_hijacking\|T1553.003]] | [[T1553.003-sip_and_trust_provider_hijacking\|SIP and Trust Provider Hijacking]] | Restrict storage and execution of SIP DLLs to protected directories, such as C:\\Windows, rather than user directories. |
| [[T1685.001-disable_or_modify_windows_event_log\|T1685.001]] | [[T1685.001-disable_or_modify_windows_event_log\|Disable or Modify Windows Event Log]] | Ensure proper process and file permissions are in place to prevent adversaries from disabling or interfering with logging or deleting or modifying .evtx logging files. Ensure .evtx files, which are located at `C:\Windows\system32\Winevt\Logs`[^2] , have the proper file permissions for limited, legitimate access and audit policies for detection.  |
| [[T1552.001-credentials_in_files\|T1552.001]] | [[T1552.001-credentials_in_files\|Credentials In Files]] | Restrict file shares to specific directories with access only to necessary users. |
| [[T1548.006-tcc_manipulation\|T1548.006]] | [[T1548.006-tcc_manipulation\|TCC Manipulation]] | When using an MDM, ensure the permissions granted are specific to the requirements of the binary. Full Disk Access should be restricted to only necessary binaries in alignment with policy.  |


## References

[^1]: [Microsoft W32Time May 2017](https://docs.microsoft.com/windows-server/networking/windows-time-service/windows-time-service-tools-and-settings)


[^2]: [win_xml_evt_log](https://forensicswiki.xyz/wiki/index.php?title=Windows_XML_Event_Log_(EVTX))


[^3]: [piazza launch agent mitigation](https://antman1p-30185.medium.com/defeating-malicious-launch-persistence-156e2b40fc67)


[^4]: [InsiderThreat NTFS EA Oct 2017](https://blog.stealthbits.com/attack-step-3-persistence-ntfs-extended-attributes-file-system-attacks)


[^5]: [create_sym_links](https://docs.microsoft.com/en-us/windows/security/threat-protection/security-policy-settings/create-symbolic-links)


[^6]: [cisco_deploy_rsa_keys](https://www.cisco.com/c/en/us/td/docs/ios-xml/ios/sec_conn_pki/configuration/xe-17/sec-pki-xe-17-book/sec-deploy-rsa-pki.html#GUID-1CB802D8-9DE3-447F-BECE-CF22F5E11436)

