---
aliases: 
    - M1053
    
mitre-attack: https://attack.mitre.org/mitigations/M1053
---

## M1053

Data Backup involves taking and securely storing backups of data from end-user systems and critical servers. It ensures that data remains available in the event of system compromise, ransomware attacks, or other disruptions. Backup processes should include hardening backup systems, implementing secure storage solutions, and keeping backups isolated from the corporate network to prevent compromise during active incidents. This mitigation can be implemented through the following measures:<br><br>Regular Backup Scheduling:<br>- Use Case: Ensure timely and consistent backups of critical data.<br>- Implementation: Schedule daily incremental backups and weekly full backups for all critical servers and systems.<br><br>Immutable Backups:<br>- Use Case: Protect backups from modification or deletion, even by attackers.<br>- Implementation: Use write-once-read-many (WORM) storage for backups, preventing ransomware from encrypting or deleting backup files.<br><br>Backup Encryption:<br>- Use Case: Protect data integrity and confidentiality during transit and storage.<br>- Implementation: Encrypt backups using strong encryption protocols (e.g., AES-256) before storing them in local, cloud, or remote locations.<br><br>Offsite Backup Storage:<br>- Use Case: Ensure data availability during physical disasters or onsite breaches.<br>- Implementation: Use cloud-based solutions like AWS S3, Azure Backup, or physical offsite storage to maintain a copy of critical data.<br><br>Backup Testing:<br>- Use Case: Validate backup integrity and ensure recoverability.<br>- Implementation: Regularly test data restoration processes to ensure that backups are not corrupted and can be recovered quickly.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1491.001-internal_defacement\|T1491.001]] | [[T1491.001-internal_defacement\|Internal Defacement]] | Consider implementing IT disaster recovery plans that contain procedures for taking regular data backups that can be used to restore organizational data.[^3]  Ensure backups are stored off system and is protected from common methods adversaries may use to gain access and destroy the backups to prevent recovery. |
| [[T1561.001-disk_content_wipe\|T1561.001]] | [[T1561.001-disk_content_wipe\|Disk Content Wipe]] | Consider implementing IT disaster recovery plans that contain procedures for taking regular data backups that can be used to restore organizational data.[^3]  Ensure backups are stored off system and is protected from common methods adversaries may use to gain access and destroy the backups to prevent recovery. |
| [[T1485.001-lifecycle_triggered_deletion\|T1485.001]] | [[T1485.001-lifecycle_triggered_deletion\|Lifecycle-Triggered Deletion]] | Consider implementing IT disaster recovery plans that contain procedures for taking regular data backups that can be used to restore organizational data.[^3]  Ensure backups are stored off system and protected from common methods adversaries may use to gain access and destroy the backups to prevent recovery. |
| [[T1485-data_destruction\|T1485]] | [[T1485-data_destruction\|Data Destruction]] | Consider implementing IT disaster recovery plans that contain procedures for taking regular data backups that can be used to restore organizational data.[^3]  Ensure backups are stored off system and protected from common methods adversaries may use to gain access and destroy the backups to prevent recovery. |
| [[T1491-defacement\|T1491]] | [[T1491-defacement\|Defacement]] | Consider implementing IT disaster recovery plans that contain procedures for taking regular data backups that can be used to restore organizational data.[^3]  Ensure backups are stored off system and is protected from common methods adversaries may use to gain access and destroy the backups to prevent recovery.<br> |
| [[T1561.002-disk_structure_wipe\|T1561.002]] | [[T1561.002-disk_structure_wipe\|Disk Structure Wipe]] | Consider implementing IT disaster recovery plans that contain procedures for taking regular data backups that can be used to restore organizational data.[^3]  Ensure backups are stored off system and is protected from common methods adversaries may use to gain access and destroy the backups to prevent recovery. |
| [[T1561-disk_wipe\|T1561]] | [[T1561-disk_wipe\|Disk Wipe]] | Consider implementing IT disaster recovery plans that contain procedures for taking regular data backups that can be used to restore organizational data.[^3]  Ensure backups are stored off system and is protected from common methods adversaries may use to gain access and destroy the backups to prevent recovery. |
| [[T1491.002-external_defacement\|T1491.002]] | [[T1491.002-external_defacement\|External Defacement]] | Consider implementing IT disaster recovery plans that contain procedures for taking regular data backups that can be used to restore organizational data.[^3]  Ensure backups are stored off system and is protected from common methods adversaries may use to gain access and destroy the backups to prevent recovery. |
| [[T1486-data_encrypted_for_impact\|T1486]] | [[T1486-data_encrypted_for_impact\|Data Encrypted for Impact]] | Consider implementing IT disaster recovery plans that contain procedures for regularly taking and testing data backups that can be used to restore organizational data.[^3]  Ensure backups are stored off system and is protected from common methods adversaries may use to gain access and destroy the backups to prevent recovery. Consider enabling versioning in cloud environments to maintain backup copies of storage objects.[^1]  |
| [[T1490-inhibit_system_recovery\|T1490]] | [[T1490-inhibit_system_recovery\|Inhibit System Recovery]] | Consider implementing IT disaster recovery plans that contain procedures for taking regular data backups that can be used to restore organizational data.[^3]  Ensure backups are stored off system and is protected from common methods adversaries may use to gain access and destroy the backups to prevent recovery. In cloud environments, enable versioning on storage objects where possible, and copy backups to other accounts or regions to isolate them from the original copies.[^2]  On ESXi servers, ensure that disk images and snapshots of virtual machines are regularly taken, with copies stored off system.[^4]  |


## References

[^1]: [Rhino S3 Ransomware Part 2](https://rhinosecuritylabs.com/aws/s3-ransomware-part-2-prevention-and-defense/)


[^2]: [Unit 42 Palo Alto Ransomware in Public Clouds 2022](https://unit42.paloaltonetworks.com/ransomware-in-public-clouds/)


[^3]: [Ready.gov IT DRP](https://www.ready.gov/business/implementation/IT)


[^4]: [Crowdstrike Hypervisor Jackpotting Pt 2 2021](https://www.crowdstrike.com/en-us/blog/hypervisor-jackpotting-ecrime-actors-increase-targeting-of-esxi-servers/)

