---
aliases: 
    - M1041
    
mitre-attack: https://attack.mitre.org/mitigations/M1041
---

## M1041

Protect sensitive information at rest, in transit, and during processing by using strong encryption algorithms. Encryption ensures the confidentiality and integrity of data, preventing unauthorized access or tampering. This mitigation can be implemented through the following measures:<br><br>Encrypt Data at Rest:<br><br>- Use Case: Use full-disk encryption or file-level encryption to secure sensitive data stored on devices.<br>- Implementation: Implement BitLocker for Windows systems or FileVault for macOS devices to encrypt hard drives.<br><br>Encrypt Data in Transit:<br><br>- Use Case: Use secure communication protocols (e.g., TLS, HTTPS) to encrypt sensitive data as it travels over networks.<br>- Implementation: Enable HTTPS for all web applications and configure mail servers to enforce STARTTLS for email encryption.<br><br>Encrypt Backups:<br><br>- Use Case: Ensure that backup data is encrypted both during storage and transfer to prevent unauthorized access.<br>- Implementation: Encrypt cloud backups using AES-256 before uploading them to Amazon S3 or Google Cloud.<br><br>Encrypt Application Secrets:<br><br>- Use Case: Store sensitive credentials, API keys, and configuration files in encrypted vaults.<br>- Implementation: Use HashiCorp Vault or AWS Secrets Manager to manage and encrypt secrets.<br><br>Database Encryption:<br><br>- Use Case: Enable Transparent Data Encryption (TDE) or column-level encryption in database management systems.<br>- Implementation: Use MySQL’s built-in encryption features to encrypt sensitive database fields such as social security numbers.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1659-content_injection\|T1659]] | [[T1659-content_injection\|Content Injection]] | Where possible, ensure that online traffic is appropriately encrypted through services such as trusted VPNs. |
| [[T1552-unsecured_credentials\|T1552]] | [[T1552-unsecured_credentials\|Unsecured Credentials]] | When possible, store keys on separate cryptographic hardware instead of on the local system.  |
| [[T1557.002-arp_cache_poisoning\|T1557.002]] | [[T1557.002-arp_cache_poisoning\|ARP Cache Poisoning]] | Ensure that all wired and/or wireless traffic is encrypted appropriately. Use best practices for authentication protocols, such as Kerberos, and ensure web traffic that may contain credentials is protected by SSL/TLS. |
| [[T1557-adversary_in_the_middle\|T1557]] | [[T1557-adversary_in_the_middle\|Adversary-in-the-Middle]] | Ensure that all wired and/or wireless traffic is encrypted appropriately. Use best practices for authentication protocols, such as Kerberos, and ensure web traffic that may contain credentials is protected by SSL/TLS. |
| [[T1070-indicator_removal\|T1070]] | [[T1070-indicator_removal\|Indicator Removal]] | Obfuscate/encrypt event files locally and in transit to avoid giving feedback to an adversary. |
| [[T1602.002-network_device_configuration_dump\|T1602.002]] | [[T1602.002-network_device_configuration_dump\|Network Device Configuration Dump]] | Configure SNMPv3 to use the highest level of security (authPriv) available.[^8]   |
| [[T1003-os_credential_dumping\|T1003]] | [[T1003-os_credential_dumping\|OS Credential Dumping]] | Ensure Domain Controller backups are properly secured. |
| [[T1565.002-transmitted_data_manipulation\|T1565.002]] | [[T1565.002-transmitted_data_manipulation\|Transmitted Data Manipulation]] | Encrypt all important data flows to reduce the impact of tailored modifications on data in transit. |
| [[T1565-data_manipulation\|T1565]] | [[T1565-data_manipulation\|Data Manipulation]] | Consider encrypting important information to reduce an adversary’s ability to perform tailored data modifications. |
| [[T1558-steal_or_forge_kerberos_tickets\|T1558]] | [[T1558-steal_or_forge_kerberos_tickets\|Steal or Forge Kerberos Tickets]] | Enable AES Kerberos encryption (or another stronger encryption algorithm), rather than RC4, where possible.[^5]  |
| [[T1530-data_from_cloud_storage\|T1530]] | [[T1530-data_from_cloud_storage\|Data from Cloud Storage]] | Encrypt data stored at rest in cloud storage.[^4] [^6]  Managed encryption keys can be rotated by most providers. At a minimum, ensure an incident response plan to storage breach includes rotating the keys and test for impact on client applications.[^1]  |
| [[T1213.006-databases\|T1213.006]] | [[T1213.006-databases\|Databases]] | Encrypt data stored at rest in databases. |
| [[T1040-network_sniffing\|T1040]] | [[T1040-network_sniffing\|Network Sniffing]] | Ensure that all wired and/or wireless traffic is encrypted appropriately. Use best practices for authentication protocols, such as Kerberos, and ensure web traffic that may contain credentials is protected by SSL/TLS. |
| [[T1114.002-remote_email_collection\|T1114.002]] | [[T1114.002-remote_email_collection\|Remote Email Collection]] | Use of encryption provides an added layer of security to sensitive information sent over email. Encryption using public key cryptography requires the adversary to obtain the private certificate along with an encryption key to decrypt messages. |
| [[T1602.001-snmp_mib_dump\|T1602.001]] | [[T1602.001-snmp_mib_dump\|SNMP (MIB Dump)]] | Configure SNMPv3 to use the highest level of security (authPriv) available.[^8]  |
| [[T1685.005-clear_windows_event_logs\|T1685.005]] | [[T1685.005-clear_windows_event_logs\|Clear Windows Event Logs]] | Obfuscate/encrypt event files locally and in transit to avoid giving feedback to an adversary. |
| [[T1119-automated_collection\|T1119]] | [[T1119-automated_collection\|Automated Collection]] | Encryption and off-system storage of sensitive information may be one way to mitigate collection of files, but may not stop an adversary from acquiring the information if an intrusion persists over a long period of time and the adversary is able to discover and access the data through other means. Strong passwords should be used on certain encrypted documents that use them to prevent offline cracking through [Brute Force](https://attack.mitre.org/techniques/T1110) techniques. |
| [[T1649-steal_or_forge_authentication_certificates\|T1649]] | [[T1649-steal_or_forge_authentication_certificates\|Steal or Forge Authentication Certificates]] | Ensure certificates as well as associated private keys are appropriately secured. Consider utilizing additional hardware credential protections such as trusted platform modules (TPM) or hardware security modules (HSM). Enforce HTTPS and enable Extended Protection for<br>Authentication.[^2]  |
| [[T1114.003-email_forwarding_rule\|T1114.003]] | [[T1114.003-email_forwarding_rule\|Email Forwarding Rule]] | Use of encryption provides an added layer of security to sensitive information sent over email. Encryption using public key cryptography requires the adversary to obtain the private certificate along with an encryption key to decrypt messages. |
| [[T1565.001-stored_data_manipulation\|T1565.001]] | [[T1565.001-stored_data_manipulation\|Stored Data Manipulation]] | Consider encrypting important information to reduce an adversary’s ability to perform tailored data modifications. |
| [[T1558.004-as_rep_roasting\|T1558.004]] | [[T1558.004-as_rep_roasting\|AS-REP Roasting]] | Enable AES Kerberos encryption (or another stronger encryption algorithm), rather than RC4, where possible.[^5]  |
| [[T1669-wi_fi_networks\|T1669]] | [[T1669-wi_fi_networks\|Wi-Fi Networks]] | Ensure that all wired and/or wireless traffic is encrypted appropriately. Use best practices for authentication protocols, such as Kerberos, and ensure that web traffic that may contain credentials is protected by SSL/TLS. |
| [[T1114-email_collection\|T1114]] | [[T1114-email_collection\|Email Collection]] | Use of encryption provides an added layer of security to sensitive information sent over email. Encryption using public key cryptography requires the adversary to obtain the private certificate along with an encryption key to decrypt messages. |
| [[T1558.003-kerberoasting\|T1558.003]] | [[T1558.003-kerberoasting\|Kerberoasting]] | Enable AES Kerberos encryption (or another stronger encryption algorithm), rather than RC4, where possible.[^5]  |
| [[T1020.001-traffic_duplication\|T1020.001]] | [[T1020.001-traffic_duplication\|Traffic Duplication]] | Ensure that all wired and/or wireless traffic is encrypted appropriately. Use best practices for authentication protocols, such as Kerberos, and ensure web traffic that may contain credentials is protected by SSL/TLS. |
| [[T1685.006-clear_linux_or_mac_system_logs\|T1685.006]] | [[T1685.006-clear_linux_or_mac_system_logs\|Clear Linux or Mac System Logs]] | Obfuscate/encrypt event files locally and in transit to avoid giving feedback to an adversary. |
| [[T1602-data_from_configuration_repository\|T1602]] | [[T1602-data_from_configuration_repository\|Data from Configuration Repository]] | Configure SNMPv3 to use the highest level of security (authPriv) available.[^8]  |
| [[T1003.003-ntds\|T1003.003]] | [[T1003.003-ntds\|NTDS]] | Ensure Domain Controller backups are properly secured.[^7]  |
| [[T1552.004-private_keys\|T1552.004]] | [[T1552.004-private_keys\|Private Keys]] | When possible, store keys on separate cryptographic hardware instead of on the local system. For example, on Windows systems use a TPM to secure keys and other sensitive credential material.[^3]  |
| [[T1550.001-application_access_token\|T1550.001]] | [[T1550.001-application_access_token\|Application Access Token]] | File encryption should be enforced across email communications containing sensitive information that may be obtained through access to email services. |
| [[T1114.001-local_email_collection\|T1114.001]] | [[T1114.001-local_email_collection\|Local Email Collection]] | Use of encryption provides an added layer of security to sensitive information sent over email. Encryption using public key cryptography requires the adversary to obtain the private certificate along with an encryption key to decrypt messages. |
| [[T1213-data_from_information_repositories\|T1213]] | [[T1213-data_from_information_repositories\|Data from Information Repositories]] | Encrypt data stored at rest in databases.  |
| [[T1558.002-silver_ticket\|T1558.002]] | [[T1558.002-silver_ticket\|Silver Ticket]] | Enable AES Kerberos encryption (or another stronger encryption algorithm), rather than RC4, where possible.[^5]  |


## References

[^1]: [Google Cloud Encryption Key Rotation](https://cloud.google.com/kms/docs/key-rotation)


[^2]: [SpecterOps Certified Pre Owned](https://web.archive.org/web/20220818094600/https://specterops.io/assets/resources/Certified_Pre-Owned.pdf)


[^3]: [Microsoft Primary Refresh Token](https://learn.microsoft.com/en-us/azure/active-directory/devices/concept-primary-refresh-token)


[^4]: [Amazon S3 Security, 2019](https://aws.amazon.com/premiumsupport/knowledge-center/secure-s3-resources/)


[^5]: [AdSecurity Cracking Kerberos Dec 2015](https://adsecurity.org/?p=2293)


[^6]: [Microsoft Azure Storage Security, 2019](https://docs.microsoft.com/en-us/azure/storage/common/storage-security-guide)


[^7]: [Metcalf 2015](http://adsecurity.org/?p=1275)


[^8]: [US-CERT TA17-156A SNMP Abuse 2017](https://us-cert.cisa.gov/ncas/alerts/TA17-156A)

