---
aliases: 
    - M1024
    
mitre-attack: https://attack.mitre.org/mitigations/M1024
---

## M1024

Restricting registry permissions involves configuring access control settings for sensitive registry keys and hives to ensure that only authorized users or processes can make modifications. By limiting access, organizations can prevent unauthorized changes that adversaries might use for persistence, privilege escalation, or defense evasion. This mitigation can be implemented through the following measures:<br><br>Review and Adjust Permissions on Critical Keys<br><br>- Regularly review permissions on keys such as `Run`, `RunOnce`, and `Services` to ensure only authorized users have write access.<br>- Use tools like `icacls` or `PowerShell` to automate permission adjustments.<br><br>Enable Registry Auditing<br><br>- Enable auditing on sensitive keys to log access attempts.<br>- Use Event Viewer or SIEM solutions to analyze logs and detect suspicious activity.<br>- Example Audit Policy: `auditpol /set /subcategory:"Registry" /success:enable /failure:enable`<br><br>Protect Credential-Related Hives<br><br>- Limit access to hives like `SAM`,`SECURITY`, and `SYSTEM` to prevent credential dumping or other unauthorized access.<br>- Use LSA Protection to add an additional security layer for credential storage.<br><br>Restrict Registry Editor Usage<br><br>- Use Group Policy to restrict access to regedit.exe for non-administrative users.<br>- Block execution of registry editing tools on endpoints where they are unnecessary.<br><br>Deploy Baseline Configuration Tools<br><br>- Use tools like Microsoft Security Compliance Toolkit or CIS Benchmarks to apply and maintain secure registry configurations.<br><br>*Tools for Implementation* <br><br>Registry Permission Tools:<br><br>- Registry Editor (regedit): Built-in tool to manage registry permissions.<br>- PowerShell: Automate permissions and manage keys. `Set-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run" -Name "KeyName" -Value "Value"`<br>- icacls: Command-line tool to modify ACLs.<br><br>Monitoring Tools:<br><br>- Sysmon: Monitor and log registry events.<br>- Event Viewer: View registry access logs.<br><br>Policy Management Tools:<br><br>- Group Policy Management Console (GPMC): Enforce registry permissions via GPOs.<br>- Microsoft Endpoint Manager: Deploy configuration baselines for registry permissions.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1547.003-time_providers\|T1547.003]] | [[T1547.003-time_providers\|Time Providers]] | Consider using Group Policy to configure and block modifications to W32Time parameters in the Registry. [^1]  |
| [[T1574.012-cor_profiler\|T1574.012]] | [[T1574.012-cor_profiler\|COR_PROFILER]] | Ensure proper permissions are set for Registry hives to prevent users from modifying keys associated with COR_PROFILER. |
| [[T1037.001-logon_script_windows\|T1037.001]] | [[T1037.001-logon_script_windows\|Logon Script (Windows)]] | Ensure proper permissions are set for Registry hives to prevent users from modifying keys for logon scripts that may lead to persistence. |
| [[T1556.008-network_provider_dll\|T1556.008]] | [[T1556.008-network_provider_dll\|Network Provider DLL]] | Restrict Registry permissions to disallow the modification of sensitive Registry keys such as `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\NetworkProvider\Order`. |
| [[T1556-modify_authentication_process\|T1556]] | [[T1556-modify_authentication_process\|Modify Authentication Process]] | Restrict Registry permissions to disallow the modification of sensitive Registry keys such as `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\NetworkProvider\Order`. |
| [[T1686-disable_or_modify_system_firewall\|T1686]] | [[T1686-disable_or_modify_system_firewall\|Disable or Modify System Firewall]] | Ensure proper Registry permissions are in place to prevent adversaries from disabling or modifying firewall settings. |
| [[T1505-server_software_component\|T1505]] | [[T1505-server_software_component\|Server Software Component]] | Consider using Group Policy to configure and block modifications to service and other critical server parameters in the Registry.[^2]  |
| [[T1505.005-terminal_services_dll\|T1505.005]] | [[T1505.005-terminal_services_dll\|Terminal Services DLL]] | Consider using Group Policy to configure and block modifications to Terminal Services parameters in the Registry.[^2]  |
| [[T1685.001-disable_or_modify_windows_event_log\|T1685.001]] | [[T1685.001-disable_or_modify_windows_event_log\|Disable or Modify Windows Event Log]] | Ensure proper Registry permissions are in place to prevent adversaries from disabling or interfering logging. The addition of the MiniNT registry key disables Event Viewer.[^3]  |
| [[T1574.011-services_registry_permissions_weakness\|T1574.011]] | [[T1574.011-services_registry_permissions_weakness\|Services Registry Permissions Weakness]] | Ensure proper permissions are set for Registry hives to prevent users from modifying keys for system components that may lead to privilege escalation.  |
| [[T1070.007-clear_network_connection_history_and_configurations\|T1070.007]] | [[T1070.007-clear_network_connection_history_and_configurations\|Clear Network Connection History and Configurations]] | Protect generated event files and logs that are stored locally with proper permissions and authentication and limit opportunities for adversaries to increase privileges by preventing Privilege Escalation opportunities. |
| [[T1112-modify_registry\|T1112]] | [[T1112-modify_registry\|Modify Registry]] | Ensure proper permissions are set for Registry hives to prevent users from modifying keys for system components that may lead to privilege escalation. |
| [[T1574-hijack_execution_flow\|T1574]] | [[T1574-hijack_execution_flow\|Hijack Execution Flow]] | Ensure proper permissions are set for Registry hives to prevent users from modifying keys for system components that may lead to privilege escalation. |
| [[T1553.003-sip_and_trust_provider_hijacking\|T1553.003]] | [[T1553.003-sip_and_trust_provider_hijacking\|SIP and Trust Provider Hijacking]] | Ensure proper permissions are set for Registry hives to prevent users from modifying keys related to SIP and trust provider components. Components may still be able to be hijacked to suitable functions already present on disk if malicious modifications to Registry keys are not prevented.  |
| [[T1037-boot_or_logon_initialization_scripts\|T1037]] | [[T1037-boot_or_logon_initialization_scripts\|Boot or Logon Initialization Scripts]] | Ensure proper permissions are set for Registry hives to prevent users from modifying keys for logon scripts that may lead to persistence. |
| [[T1553-subvert_trust_controls\|T1553]] | [[T1553-subvert_trust_controls\|Subvert Trust Controls]] | Ensure proper permissions are set for Registry hives to prevent users from modifying keys related to SIP and trust provider components. Components may still be able to be hijacked to suitable functions already present on disk if malicious modifications to Registry keys are not prevented. |
| [[T1685-disable_or_modify_tools\|T1685]] | [[T1685-disable_or_modify_tools\|Disable or Modify Tools]] | Ensure proper Registry permissions are in place to prevent adversaries from disabling or interfering with security services. |
| [[T1686.003-windows_host_firewall\|T1686.003]] | [[T1686.003-windows_host_firewall\|Windows Host Firewall]] | Ensure proper Registry permissions are in place to prevent adversaries from disabling or modifying firewall settings. |
| [[T1489-service_stop\|T1489]] | [[T1489-service_stop\|Service Stop]] | Ensure proper registry permissions are in place to inhibit adversaries from disabling or interfering with critical services. |
| [[T1553.006-code_signing_policy_modification\|T1553.006]] | [[T1553.006-code_signing_policy_modification\|Code Signing Policy Modification]] | Ensure proper permissions are set for the Registry to prevent users from modifying keys related to code signing policies. |


## References

[^1]: [Microsoft W32Time May 2017](https://docs.microsoft.com/windows-server/networking/windows-time-service/windows-time-service-tools-and-settings)


[^2]: [Microsoft System Services Fundamentals](https://social.technet.microsoft.com/wiki/contents/articles/12229.windows-system-services-fundamentals.aspx)


[^3]: [def_ev_win_event_logging](https://www.hackingarticles.in/defense-evasion-windows-event-logging-t1562-002/)

