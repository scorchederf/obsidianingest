---
aliases: 
    - M1015
    
mitre-attack: https://attack.mitre.org/mitigations/M1015
---

## M1015

Implement robust Active Directory (AD) configurations using group policies to secure user accounts, control access, and minimize the attack surface. AD configurations enable centralized control over account settings, logon policies, and permissions, reducing the risk of unauthorized access and lateral movement within the network. This mitigation can be implemented through the following measures:<br><br>Account Configuration:<br><br>- Implementation: Use domain accounts instead of local accounts to leverage AD’s centralized management, including group policies, auditing, and access control.<br>- Use Case: For IT staff managing shared resources, provision domain accounts that allow IT teams to log in centrally, reducing the risk of unmanaged, rogue local accounts on individual machines.<br><br>Interactive Logon Restrictions:<br><br>- Implementation: Configure group policies to restrict interactive logons (e.g., direct physical or RDP logons) for service accounts or privileged accounts that do not require such access.<br>- Use Case: Prevent service accounts, such as SQL Server accounts, from having interactive logon privileges. This reduces the risk of these accounts being leveraged for lateral movement if compromised.<br><br>Remote Desktop Settings:<br><br>- Implementation: Limit Remote Desktop Protocol (RDP) access to specific, authorized accounts. Use group policies to enforce this, allowing only necessary users to establish RDP sessions.<br>- Use Case: On sensitive servers (e.g., domain controllers or financial databases), restrict RDP access to administrative accounts only, while all other users are denied access.<br><br>Dedicated Administrative Accounts:<br><br>- Implementation: Create domain-wide administrative accounts that are restricted from interactive logons, designed solely for high-level tasks (e.g., software installation, patching).<br>- Use Case: Create separate administrative accounts for different purposes, such as one set of accounts for installations and another for managing repository access. This limits exposure and helps reduce attack vectors.<br><br>Authentication Silos:<br><br>- Implementation: Configure Authentication Silos in AD, using group policies to create access zones with restrictions based on membership, such as the Protected Users security group. This restricts access to critical accounts and minimizes exposure to potential threats.<br>- Use Case: Place high-risk or high-value accounts, such as executive or administrative accounts, in an Authentication Silo with extra controls, limiting their exposure to only necessary systems. This reduces the risk of credential misuse or abuse if these accounts are compromised.<br><br>**Tools for Implementation**:<br><br>- Active Directory Group Policies: Use Group Policy Management Console (GPMC) to configure, deploy, and enforce policies across AD environments.<br>- PowerShell: Automate account configuration, logon restrictions, and policy application using PowerShell scripts.<br>- AD Administrative Center: Manage Authentication Silos and configure high-level policies for critical user groups within AD.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1558-steal_or_forge_kerberos_tickets\|T1558]] | [[T1558-steal_or_forge_kerberos_tickets\|Steal or Forge Kerberos Tickets]] | For containing the impact of a previously generated golden ticket, reset the built-in KRBTGT account password twice, which will invalidate any existing golden tickets that have been created with the KRBTGT hash and other Kerberos tickets derived from it. For each domain, change the KRBTGT account password once, force replication, and then change the password a second time. Consider rotating the KRBTGT account password every 180 days.[^13]  |
| [[T1078.004-cloud_accounts\|T1078.004]] | [[T1078.004-cloud_accounts\|Cloud Accounts]] | Disable legacy authentication, which does not support MFA, and require the use of modern authentication protocols instead.  |
| [[T1072-software_deployment_tools\|T1072]] | [[T1072-software_deployment_tools\|Software Deployment Tools]] | Ensure proper system and access isolation for critical network systems through use of group policy. |
| [[T1552-unsecured_credentials\|T1552]] | [[T1552-unsecured_credentials\|Unsecured Credentials]] | Remove vulnerable Group Policy Preferences.[^12]  |
| [[T1134.005-sid_history_injection\|T1134.005]] | [[T1134.005-sid_history_injection\|SID-History Injection]] | Clean up SID-History attributes after legitimate account migration is complete.<br><br>Consider applying SID Filtering to interforest trusts, such as forest trusts and external trusts, to exclude SID-History from requests to access domain resources. SID Filtering ensures that any authentication requests over a trust only contain SIDs of security principals from the trusted domain (i.e preventing the trusted domain from claiming a user has membership in groups outside of the domain).<br><br>SID Filtering of forest trusts is enabled by default, but may have been disabled in some cases to allow a child domain to transitively access forest trusts. SID Filtering of external trusts is automatically enabled on all created external trusts using Server 2003 or later domain controllers. [^7]  [^4]  However note that SID Filtering is not automatically applied to legacy trusts or may have been deliberately disabled to allow inter-domain access to resources.<br><br>SID Filtering can be applied by: [^10] <br><br>* Disabling SIDHistory on forest trusts using the netdom tool (`netdom trust /domain: /EnableSIDHistory:no` on the domain controller)<br><br>* Applying SID Filter Quarantining to external trusts using the netdom tool (`netdom trust <TrustingDomainName> /domain:<TrustedDomainName> /quarantine:yes` on the domain controller)<br><br>* Applying SID Filtering to domain trusts within a single forest is not recommended as it is an unsupported configuration and can cause breaking changes. [^10]  [^5]  If a domain within a forest is untrustworthy then it should not be a member of the forest. In this situation it is necessary to first split the trusted and untrusted domains into separate forests where SID Filtering can be applied to an interforest trust |
| [[T1606.002-saml_tokens\|T1606.002]] | [[T1606.002-saml_tokens\|SAML Tokens]] | For containing the impact of a previously forged SAML token, rotate the token-signing AD FS certificate in rapid succession twice, which will invalidate any tokens generated using the previous certificate.[^8]  |
| [[T1649-steal_or_forge_authentication_certificates\|T1649]] | [[T1649-steal_or_forge_authentication_certificates\|Steal or Forge Authentication Certificates]] | Ensure certificate authorities (CA) are properly secured, including treating CA servers (and other resources hosting CA certificates) as tier 0 assets. Harden abusable CA settings and attributes.<br><br>For example, consider disabling the usage of AD CS certificate SANs within relevant authentication protocol settings to enforce strict user mappings and prevent certificates from authenticating as other identifies.[^1]  Also consider enforcing CA Certificate Manager approval for the templates that include SAN as an issuance requirement. |
| [[T1003.005-cached_domain_credentials\|T1003.005]] | [[T1003.005-cached_domain_credentials\|Cached Domain Credentials]] | Consider adding users to the "Protected Users" Active Directory security group. This can help limit the caching of users' plaintext credentials.[^6]  |
| [[T1003.006-dcsync\|T1003.006]] | [[T1003.006-dcsync\|DCSync]] | Manage the access control list for "Replicating Directory Changes" and other permissions associated with domain controller replication.[^9] [^2]  |
| [[T1550-use_alternate_authentication_material\|T1550]] | [[T1550-use_alternate_authentication_material\|Use Alternate Authentication Material]] | Configure Active Directory to prevent use of certain techniques; use SID Filtering, etc. |
| [[T1550.003-pass_the_ticket\|T1550.003]] | [[T1550.003-pass_the_ticket\|Pass the Ticket]] | To contain the impact of a previously generated golden ticket, reset the built-in KRBTGT account password twice, which will invalidate any existing golden tickets that have been created with the KRBTGT hash and other Kerberos tickets derived from it.[^11]  For each domain, change the KRBTGT account password once, force replication, and then change the password a second time. Consider rotating the KRBTGT account password every 180 days.[^13]  |
| [[T1552.006-group_policy_preferences\|T1552.006]] | [[T1552.006-group_policy_preferences\|Group Policy Preferences]] | Remove vulnerable Group Policy Preferences.[^12]  |
| [[T1078-valid_accounts\|T1078]] | [[T1078-valid_accounts\|Valid Accounts]] | Disable legacy authentication, which does not support MFA, and require the use of modern authentication protocols instead. |
| [[T1558.001-golden_ticket\|T1558.001]] | [[T1558.001-golden_ticket\|Golden Ticket]] | For containing the impact of a previously generated golden ticket, reset the built-in KRBTGT account password twice, which will invalidate any existing golden tickets that have been created with the KRBTGT hash and other Kerberos tickets derived from it. For each domain, change the KRBTGT account password once, force replication, and then change the password a second time. Consider rotating the KRBTGT account password every 180 days.[^13]  |
| [[T1003-os_credential_dumping\|T1003]] | [[T1003-os_credential_dumping\|OS Credential Dumping]] | <br>Manage the access control list for “Replicating Directory Changes All” and other permissions associated with domain controller replication. [^3]  [^2]  Consider adding users to the "Protected Users" Active Directory security group. This can help limit the caching of users' plaintext credentials.[^6]  |


## References

[^1]: [SpecterOps Certified Pre Owned](https://www.specterops.io/assets/resources/Certified_Pre-Owned.pdf)


[^2]: [Microsoft Replication ACL](https://support.microsoft.com/help/303972/how-to-grant-the-replicating-directory-changes-permission-for-the-micr)


[^3]: [AdSecurity DCSync Sept 2015](https://adsecurity.org/?p=1729)


[^4]: [Microsoft SID Filtering Quarantining Jan 2009](https://technet.microsoft.com/library/cc794757.aspx)


[^5]: [AdSecurity Kerberos GT Aug 2015](https://adsecurity.org/?p=1640)


[^6]: [Microsoft Protected Users Security Group](https://docs.microsoft.com/en-us/windows-server/security/credentials-protection-and-management/protected-users-security-group)


[^7]: [Microsoft Trust Considerations Nov 2014](https://technet.microsoft.com/library/cc755321.aspx)


[^8]: [Mandiant Defend UNC2452 White Paper](https://www.mandiant.com/resources/blog/remediation-and-hardening-strategies-for-microsoft-365-to-defend-against-unc2452)


[^9]: [ADSecurity Mimikatz DCSync](https://adsecurity.org/?p=1729)


[^10]: [Microsoft Netdom Trust Sept 2012](https://technet.microsoft.com/library/cc835085.aspx)


[^11]: [ADSecurity Kerberos and KRBTGT](https://adsecurity.org/?p=483)


[^12]: [Microsoft MS14-025](http://support.microsoft.com/kb/2962486)


[^13]: [STIG krbtgt reset](https://www.stigviewer.com/stig/windows_server_2016/2019-12-12/finding/V-91779)

