---
aliases: 
    - M1040
    
mitre-attack: https://attack.mitre.org/mitigations/M1040
---

## M1040

Behavior Prevention on Endpoint refers to the use of technologies and strategies to detect and block potentially malicious activities by analyzing the behavior of processes, files, API calls, and other endpoint events. Rather than relying solely on known signatures, this approach leverages heuristics, machine learning, and real-time monitoring to identify anomalous patterns indicative of an attack. This mitigation can be implemented through the following measures:<br><br>Suspicious Process Behavior:<br><br>- Implementation: Use Endpoint Detection and Response (EDR) tools to monitor and block processes exhibiting unusual behavior, such as privilege escalation attempts.<br>- Use Case: An attacker uses a known vulnerability to spawn a privileged process from a user-level application. The endpoint tool detects the abnormal parent-child process relationship and blocks the action.<br><br>Unauthorized File Access:<br><br>- Implementation: Leverage Data Loss Prevention (DLP) or endpoint tools to block processes attempting to access sensitive files without proper authorization.<br>- Use Case: A process tries to read or modify a sensitive file located in a restricted directory, such as /etc/shadow on Linux or the SAM registry hive on Windows. The endpoint tool identifies this anomalous behavior and prevents it.<br><br>Abnormal API Calls:<br><br>- Implementation: Implement runtime analysis tools to monitor API calls and block those associated with malicious activities.<br>- Use Case: A process dynamically injects itself into another process to hijack its execution. The endpoint detects the abnormal use of APIs like `OpenProcess` and `WriteProcessMemory` and terminates the offending process.<br><br>Exploit Prevention:<br><br>- Implementation: Use behavioral exploit prevention tools to detect and block exploits attempting to gain unauthorized access.<br>- Use Case: A buffer overflow exploit is launched against a vulnerable application. The endpoint detects the anomalous memory write operation and halts the process.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1036.008-masquerade_file_type\|T1036.008]] | [[T1036.008-masquerade_file_type\|Masquerade File Type]] | Implement security controls on the endpoint, such as a Host Intrusion Prevention System (HIPS), to identify and prevent execution of files with mismatching file signatures. |
| [[T1543.003-windows_service\|T1543.003]] | [[T1543.003-windows_service\|Windows Service]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent an application from writing a signed vulnerable driver to the system.[^4]  On Windows 10 and 11, enable Microsoft Vulnerable Driver Blocklist to assist in hardening against third party-developed service drivers.[^3]    |
| [[T1055.002-portable_executable_injection\|T1055.002]] | [[T1055.002-portable_executable_injection\|Portable Executable Injection]] | Some endpoint security solutions can be configured to block some types of process injection based on common sequences of behavior that occur during the injection process.  |
| [[T1055.004-asynchronous_procedure_call\|T1055.004]] | [[T1055.004-asynchronous_procedure_call\|Asynchronous Procedure Call]] | Some endpoint security solutions can be configured to block some types of process injection based on common sequences of behavior that occur during the injection process.  |
| [[T1027.014-polymorphic_code\|T1027.014]] | [[T1027.014-polymorphic_code\|Polymorphic Code]] | On Windows 10+, enable Attack Surface Reduction (ASR) rules to prevent execution of potentially obfuscated payloads |
| [[T1137.006-add_ins\|T1137.006]] | [[T1137.006-add_ins\|Add-ins]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent Office applications from creating child processes and from writing potentially malicious executable content to disk. [^2]  |
| [[T1055.009-proc_memory\|T1055.009]] | [[T1055.009-proc_memory\|Proc Memory]] | Some endpoint security solutions can be configured to block some types of process injection based on common sequences of behavior that occur during the injection process.  |
| [[T1027.010-command_obfuscation\|T1027.010]] | [[T1027.010-command_obfuscation\|Command Obfuscation]] | On Windows 10+, enable Attack Surface Reduction (ASR) rules to block execution of potentially obfuscated scripts.[^1]  |
| [[T1055.012-process_hollowing\|T1055.012]] | [[T1055.012-process_hollowing\|Process Hollowing]] | Some endpoint security solutions can be configured to block some types of process injection based on common sequences of behavior that occur during the injection process.  |
| [[T1047-windows_management_instrumentation\|T1047]] | [[T1047-windows_management_instrumentation\|Windows Management Instrumentation]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to block processes created by WMI commands from running. Note: many legitimate tools and applications utilize WMI for command execution. [^2]  |
| [[T1059.007-javascript\|T1059.007]] | [[T1059.007-javascript\|JavaScript]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent [JavaScript](https://attack.mitre.org/techniques/T1059/007) scripts from executing potentially malicious downloaded content [^2] . |
| [[T1204-user_execution\|T1204]] | [[T1204-user_execution\|User Execution]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent executable files from running unless they meet a prevalence, age, or trusted list criteria and to prevent Office applications from creating potentially malicious executable content by blocking malicious code from being written to disk. Note: cloud-delivered protection must be enabled to use certain rules. [^2]  |
| [[T1543-create_or_modify_system_process\|T1543]] | [[T1543-create_or_modify_system_process\|Create or Modify System Process]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent an application from writing a signed vulnerable driver to the system.[^4]  On Windows 10 and 11, enable Microsoft Vulnerable Driver Blocklist to assist in hardening against third party-developed drivers.[^3]    |
| [[T1559.002-dynamic_data_exchange\|T1559.002]] | [[T1559.002-dynamic_data_exchange\|Dynamic Data Exchange]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent DDE attacks and spawning of child processes from Office programs.[^9] [^8]  |
| [[T1574-hijack_execution_flow\|T1574]] | [[T1574-hijack_execution_flow\|Hijack Execution Flow]] | Some endpoint security solutions can be configured to block some types of behaviors related to process injection/memory tampering based on common sequences of indicators (ex: execution of specific API functions). |
| [[T1569.002-service_execution\|T1569.002]] | [[T1569.002-service_execution\|Service Execution]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to block processes created by [PsExec](https://attack.mitre.org/software/S0029) from running. [^2]  |
| [[T1055.014-vdso_hijacking\|T1055.014]] | [[T1055.014-vdso_hijacking\|VDSO Hijacking]] | Some endpoint security solutions can be configured to block some types of process injection based on common sequences of behavior that occur during the injection process.  |
| [[T1055.013-process_doppelg_nging\|T1055.013]] | [[T1055.013-process_doppelg_nging\|Process Doppelgänging]] | Some endpoint security solutions can be configured to block some types of process injection based on common sequences of behavior that occur during the injection process.  |
| [[T1216.001-pubprn\|T1216.001]] | [[T1216.001-pubprn\|PubPrn]] | On Windows 10, update Windows Defender Application Control policies to include rules that block the older, vulnerable versions of PubPrn.[^5]  |
| [[T1036-masquerading\|T1036]] | [[T1036-masquerading\|Masquerading]] | Implement security controls on the endpoint, such as a Host Intrusion Prevention System (HIPS), to identify and prevent execution of potentially malicious files (such as those with mismatching file signatures). |
| [[T1055.003-thread_execution_hijacking\|T1055.003]] | [[T1055.003-thread_execution_hijacking\|Thread Execution Hijacking]] | Some endpoint security solutions can be configured to block some types of process injection based on common sequences of behavior that occur during the injection process.  |
| [[T1137.004-outlook_home_page\|T1137.004]] | [[T1137.004-outlook_home_page\|Outlook Home Page]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent Office applications from creating child processes and from writing potentially malicious executable content to disk. [^2]  |
| [[T1137-office_application_startup\|T1137]] | [[T1137-office_application_startup\|Office Application Startup]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent Office applications from creating child processes and from writing potentially malicious executable content to disk. [^2]  |
| [[T1091-replication_through_removable_media\|T1091]] | [[T1091-replication_through_removable_media\|Replication Through Removable Media]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to block unsigned/untrusted executable files (such as .exe, .dll, or .scr) from running from USB removable drives. [^2]  |
| [[T1003-os_credential_dumping\|T1003]] | [[T1003-os_credential_dumping\|OS Credential Dumping]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to secure LSASS and prevent credential stealing. [^2]  |
| [[T1137.001-office_template_macros\|T1137.001]] | [[T1137.001-office_template_macros\|Office Template Macros]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent Office applications from creating child processes and from writing potentially malicious executable content to disk. [^2]  |
| [[T1137.002-office_test\|T1137.002]] | [[T1137.002-office_test\|Office Test]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent Office applications from creating child processes and from writing potentially malicious executable content to disk. [^2]  |
| [[T1574.013-kernelcallbacktable\|T1574.013]] | [[T1574.013-kernelcallbacktable\|KernelCallbackTable]] | Some endpoint security solutions can be configured to block some types of behaviors related to process injection/memory tampering based on common sequences of indicators (ex: execution of specific API functions). |
| [[T1059.005-visual_basic\|T1059.005]] | [[T1059.005-visual_basic\|Visual Basic]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent [Visual Basic](https://attack.mitre.org/techniques/T1059/005) scripts from executing potentially malicious downloaded content [^2] . |
| [[T1055.011-extra_window_memory_injection\|T1055.011]] | [[T1055.011-extra_window_memory_injection\|Extra Window Memory Injection]] | Some endpoint security solutions can be configured to block some types of process injection based on common sequences of behavior that occur during the injection process.  |
| [[T1564.014-extended_attributes\|T1564.014]] | [[T1564.014-extended_attributes\|Extended Attributes]] | During artifact review, packaging, or deployment stages, scan extended attributes alongside file contents to detect hidden payloads, obfuscated data, or suspicious attribute keys that may indicate malicious behavior. |
| [[T1027.012-lnk_icon_smuggling\|T1027.012]] | [[T1027.012-lnk_icon_smuggling\|LNK Icon Smuggling]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent execution of potentially obfuscated scripts or payloads. |
| [[T1486-data_encrypted_for_impact\|T1486]] | [[T1486-data_encrypted_for_impact\|Data Encrypted for Impact]] | On Windows 10, enable cloud-delivered protection and Attack Surface Reduction (ASR) rules to block the execution of files that resemble ransomware.[^2]  In AWS environments, create an IAM policy to restrict or block the use of SSE-C on S3 buckets.[^7]  |
| [[T1137.005-outlook_rules\|T1137.005]] | [[T1137.005-outlook_rules\|Outlook Rules]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent Office applications from creating child processes and from writing potentially malicious executable content to disk. [^2]  |
| [[T1204.002-malicious_file\|T1204.002]] | [[T1204.002-malicious_file\|Malicious File]] | On Windows 10, various Attack Surface Reduction (ASR) rules can be enabled to prevent the execution of potentially malicious executable files (such as those that have been downloaded and executed by Office applications/scripting interpreters/email clients or that do not meet specific prevalence, age, or trusted list criteria). Note: cloud-delivered protection must be enabled for certain rules. [^2]  |
| [[T1055.008-ptrace_system_calls\|T1055.008]] | [[T1055.008-ptrace_system_calls\|Ptrace System Calls]] | Some endpoint security solutions can be configured to block some types of process injection based on common sequences of behavior that occur during the injection process.  |
| [[T1106-native_api\|T1106]] | [[T1106-native_api\|Native API]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent Office VBA macros from calling Win32 APIs. [^2]  |
| [[T1055-process_injection\|T1055]] | [[T1055-process_injection\|Process Injection]] | Some endpoint security solutions can be configured to block some types of process injection based on common sequences of behavior that occur during the injection process. For example, on Windows 10, Attack Surface Reduction (ASR) rules may prevent Office applications from code injection. [^2]  |
| [[T1569-system_services\|T1569]] | [[T1569-system_services\|System Services]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to block processes created by [PsExec](https://attack.mitre.org/software/S0029) from running. [^2]  |
| [[T1006-direct_volume_access\|T1006]] | [[T1006-direct_volume_access\|Direct Volume Access]] | Some endpoint security solutions can be configured to block some types of behaviors related to efforts by an adversary to create backups, such as command execution or preventing API calls to backup related services. |
| [[T1559-inter_process_communication\|T1559]] | [[T1559-inter_process_communication\|Inter-Process Communication]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent DDE attacks and spawning of child processes from Office programs.[^9] [^8]  |
| [[T1027-obfuscated_files_or_information\|T1027]] | [[T1027-obfuscated_files_or_information\|Obfuscated Files or Information]] | On Windows 10+, enable Attack Surface Reduction (ASR) rules to prevent execution of potentially obfuscated payloads. [^2]  |
| [[T1027.009-embedded_payloads\|T1027.009]] | [[T1027.009-embedded_payloads\|Embedded Payloads]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent execution of potentially obfuscated scripts.[^2]  |
| [[T1137.003-outlook_forms\|T1137.003]] | [[T1137.003-outlook_forms\|Outlook Forms]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent Office applications from creating child processes and from writing potentially malicious executable content to disk. [^2]  |
| [[T1546.003-windows_management_instrumentation_event_subscription\|T1546.003]] | [[T1546.003-windows_management_instrumentation_event_subscription\|Windows Management Instrumentation Event Subscription]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent malware from abusing WMI to attain persistence.[^2]  |
| [[T1003.001-lsass_memory\|T1003.001]] | [[T1003.001-lsass_memory\|LSASS Memory]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to secure LSASS and prevent credential stealing. [^2]  |
| [[T1059-command_and_scripting_interpreter\|T1059]] | [[T1059-command_and_scripting_interpreter\|Command and Scripting Interpreter]] | On Windows 10, enable Attack Surface Reduction (ASR) rules to prevent [Visual Basic](https://attack.mitre.org/techniques/T1059/005) and [JavaScript](https://attack.mitre.org/techniques/T1059/007) scripts from executing potentially malicious downloaded content [^2] . |
| [[T1055.005-thread_local_storage\|T1055.005]] | [[T1055.005-thread_local_storage\|Thread Local Storage]] | Some endpoint security solutions can be configured to block some types of process injection based on common sequences of behavior that occur during the injection process.  |
| [[T1027.013-encrypted_encoded_file\|T1027.013]] | [[T1027.013-encrypted_encoded_file\|Encrypted／Encoded File]] | On Windows 10+, enable Attack Surface Reduction (ASR) rules to block execution of potentially obfuscated scripts.[^6] <br><br>Security tools should be configured to analyze the encoding properties of files and detect anomalies that deviate from standard encoding practices. |
| [[T1055.001-dynamic_link_library_injection\|T1055.001]] | [[T1055.001-dynamic_link_library_injection\|Dynamic-link Library Injection]] | Some endpoint security solutions can be configured to block some types of process injection based on common sequences of behavior that occur during the injection process.  |
| [[T1055.015-listplanting\|T1055.015]] | [[T1055.015-listplanting\|ListPlanting]] | Some endpoint security solutions can be configured to block some types of process injection based on common sequences of behavior that occur during the injection process. |


## References

[^1]: [Microsoft ASR Obfuscation](https://learn.microsoft.com/microsoft-365/security/defender-endpoint/attack-surface-reduction-rules-reference#block-execution-of-potentially-obfuscated-scripts)


[^2]: [win10_asr](https://docs.microsoft.com/microsoft-365/security/defender-endpoint/attack-surface-reduction)


[^3]: [Microsoft driver block rules](https://docs.microsoft.com/en-us/windows/security/threat-protection/windows-defender-application-control/microsoft-recommended-driver-block-rules)


[^4]: [Malicious Driver Reporting Center](https://www.microsoft.com/security/blog/2021/12/08/improve-kernel-security-with-the-new-microsoft-vulnerable-and-malicious-driver-reporting-center/)


[^5]: [Microsoft_rec_block_rules](https://docs.microsoft.com/en-us/windows/security/threat-protection/windows-defender-application-control/microsoft-recommended-block-rules)


[^6]: [Obfuscated scripts](https://learn.microsoft.com/en-us/microsoft-365/security/defender-endpoint/attack-surface-reduction-rules-reference?view=o365-worldwide#block-execution-of-potentially-obfuscated-scripts)


[^7]: [Halcyon AWS Ransomware 2025](https://www.halcyon.ai/blog/abusing-aws-native-services-ransomware-encrypting-s3-buckets-with-sse-c)


[^8]: [Enigma Reviving DDE Jan 2018](https://posts.specterops.io/reviving-dde-using-onenote-and-excel-for-code-execution-d7226864caee)


[^9]: [Microsoft ASR Nov 2017](https://docs.microsoft.com/windows/threat-protection/windows-defender-exploit-guard/enable-attack-surface-reduction)

