---
aliases: 
    - M1051
    
mitre-attack: https://attack.mitre.org/mitigations/M1051
---

## M1051

Software updates ensure systems are protected against known vulnerabilities by applying patches and upgrades provided by vendors. Regular updates reduce the attack surface and prevent adversaries from exploiting known security gaps. This includes patching operating systems, applications, drivers, and firmware. This mitigation can be implemented through the following measures:<br><br>Regular Operating System Updates<br><br>- Implementation: Apply the latest Windows security updates monthly using WSUS (Windows Server Update Services) or a similar patch management solution. Configure systems to check for updates automatically and schedule reboots during maintenance windows.<br>- Use Case: Prevents exploitation of OS vulnerabilities such as privilege escalation or remote code execution.<br><br>Application Patching<br><br>- Implementation: Monitor Apache's update release notes for security patches addressing vulnerabilities. Schedule updates for off-peak hours to avoid downtime while maintaining security compliance.<br>- Use Case: Prevents exploitation of web application vulnerabilities, such as those leading to unauthorized access or data breaches.<br><br>Firmware Updates<br><br>- Implementation: Regularly check the vendor’s website for firmware updates addressing vulnerabilities. Plan for update deployment during scheduled maintenance to minimize business disruption.<br>- Use Case: Protects against vulnerabilities that adversaries could exploit to gain access to network devices or inject malicious traffic.<br><br>Emergency Patch Deployment<br><br>- Implementation: Use the emergency patch deployment feature of the organization's patch management tool to apply updates to all affected Exchange servers within 24 hours.<br>- Use Case: Reduces the risk of exploitation by rapidly addressing critical vulnerabilities.<br><br>Centralized Patch Management<br><br>- Implementation: Implement a centralized patch management system, such as SCCM or ManageEngine, to automate and track patch deployment across all environments. Generate regular compliance reports to ensure all systems are updated.<br>- Use Case: Streamlines patching processes and ensures no critical systems are missed.<br><br>*Tools for Implementation*<br><br>Patch Management Tools:<br><br>- WSUS: Manage and deploy Microsoft updates across the organization.<br>- ManageEngine Patch Manager Plus: Automate patch deployment for OS and third-party apps.<br>- Ansible: Automate updates across multiple platforms, including Linux and Windows.<br><br>Vulnerability Scanning Tools:<br><br>- OpenVAS: Open-source vulnerability scanning to identify missing patches.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1550.002-pass_the_hash\|T1550.002]] | [[T1550.002-pass_the_hash\|Pass the Hash]] | Apply patch KB2871997 to Windows 7 and higher systems to limit the default access of accounts in the local administrator group.[^7]   |
| [[T1686.002-network_device_firewall\|T1686.002]] | [[T1686.002-network_device_firewall\|Network Device Firewall]] | Ensure the network firewall is up to date with security patches. |
| [[T1552-unsecured_credentials\|T1552]] | [[T1552-unsecured_credentials\|Unsecured Credentials]] | Apply patch KB2962486 which prevents credentials from being stored in GPPs.[^5] [^6]  |
| [[T1176.002-ide_extensions\|T1176.002]] | [[T1176.002-ide_extensions\|IDE Extensions]] | Ensure operating systems and IDEs are using the most current version.  |
| [[T1548.002-bypass_user_account_control\|T1548.002]] | [[T1548.002-bypass_user_account_control\|Bypass User Account Control]] | Consider updating Windows to the latest version and patch level to utilize the latest protective measures against UAC bypass.[^2]  |
| [[T1602.001-snmp_mib_dump\|T1602.001]] | [[T1602.001-snmp_mib_dump\|SNMP (MIB Dump)]] | Keep system images and software updated and migrate to SNMPv3.[^1]  |
| [[T1068-exploitation_for_privilege_escalation\|T1068]] | [[T1068-exploitation_for_privilege_escalation\|Exploitation for Privilege Escalation]] | Update software regularly by employing patch management for internal enterprise endpoints and servers. |
| [[T1555.005-password_managers\|T1555.005]] | [[T1555.005-password_managers\|Password Managers]] | Regularly update web browsers, password managers, and all related software to the latest versions. Keeping software up-to-date reduces the risk of vulnerabilities being exploited by attackers to extract stored credentials or session cookies. |
| [[T1495-firmware_corruption\|T1495]] | [[T1495-firmware_corruption\|Firmware Corruption]] | Patch the BIOS and other firmware as necessary to prevent successful use of known vulnerabilities. |
| [[T1110.001-password_guessing\|T1110.001]] | [[T1110.001-password_guessing\|Password Guessing]] | Upgrade management services to the latest supported and compatible version.  Specifically, any version providing increased password complexity or policy enforcement preventing default or weak passwords.  |
| [[T1555-credentials_from_password_stores\|T1555]] | [[T1555-credentials_from_password_stores\|Credentials from Password Stores]] | Perform regular software updates to mitigate exploitation risk. |
| [[T1611-escape_to_host\|T1611]] | [[T1611-escape_to_host\|Escape to Host]] | Ensure that hosts are kept up-to-date with security patches.  |
| [[T1072-software_deployment_tools\|T1072]] | [[T1072-software_deployment_tools\|Software Deployment Tools]] | Patch deployment systems regularly to prevent potential remote access through [Exploitation for Privilege Escalation](https://attack.mitre.org/techniques/T1068). |
| [[T1137.004-outlook_home_page\|T1137.004]] | [[T1137.004-outlook_home_page\|Outlook Home Page]] | For the Outlook methods, blocking macros may be ineffective as the Visual Basic engine used for these features is separate from the macro scripting engine.[^3]  Microsoft has released patches to try to address each issue. Ensure KB3191938 which blocks Outlook Visual Basic and displays a malicious code warning, KB4011091 which disables custom forms by default, and KB4011162 which removes the legacy Home Page feature, are applied to systems.[^8]  |
| [[T1542-pre_os_boot\|T1542]] | [[T1542-pre_os_boot\|Pre-OS Boot]] | Patch the BIOS and EFI as necessary. |
| [[T1542.001-system_firmware\|T1542.001]] | [[T1542.001-system_firmware\|System Firmware]] | Patch the BIOS and EFI as necessary. |
| [[T1212-exploitation_for_credential_access\|T1212]] | [[T1212-exploitation_for_credential_access\|Exploitation for Credential Access]] | Update software regularly by employing patch management for internal enterprise endpoints and servers. |
| [[T1602-data_from_configuration_repository\|T1602]] | [[T1602-data_from_configuration_repository\|Data from Configuration Repository]] | Keep system images and software updated and migrate to SNMPv3.[^1]  |
| [[T1189-drive_by_compromise\|T1189]] | [[T1189-drive_by_compromise\|Drive-by Compromise]] | Ensuring that all browsers and plugins are kept updated can help prevent the exploit phase of this technique. Use modern browsers with security features turned on.[^4] <br> |
| [[T1548-abuse_elevation_control_mechanism\|T1548]] | [[T1548-abuse_elevation_control_mechanism\|Abuse Elevation Control Mechanism]] | Perform regular software updates to mitigate exploitation risk. |
| [[T1211-exploitation_for_stealth\|T1211]] | [[T1211-exploitation_for_stealth\|Exploitation for Stealth]] | Update software regularly by employing patch management for internal enterprise endpoints and servers. |
| [[T1574-hijack_execution_flow\|T1574]] | [[T1574-hijack_execution_flow\|Hijack Execution Flow]] | Update software regularly to include patches that fix DLL side-loading vulnerabilities. |
| [[T1176.001-browser_extensions\|T1176.001]] | [[T1176.001-browser_extensions\|Browser Extensions]] | Ensure operating systems and browsers are using the most current version.  |
| [[T1137-office_application_startup\|T1137]] | [[T1137-office_application_startup\|Office Application Startup]] | For the Outlook methods, blocking macros may be ineffective as the Visual Basic engine used for these features is separate from the macro scripting engine.[^3]  Microsoft has released patches to try to address each issue. Ensure KB3191938 which blocks Outlook Visual Basic and displays a malicious code warning, KB4011091 which disables custom forms by default, and KB4011162 which removes the legacy Home Page feature, are applied to systems.[^8]  |
| [[T1195.001-compromise_software_dependencies_and_development_tools\|T1195.001]] | [[T1195.001-compromise_software_dependencies_and_development_tools\|Compromise Software Dependencies and Development Tools]] | A patch management process should be implemented to check unused dependencies, unmaintained and/or previously vulnerable dependencies, unnecessary features, components, files, and documentation. |
| [[T1552.006-group_policy_preferences\|T1552.006]] | [[T1552.006-group_policy_preferences\|Group Policy Preferences]] | Apply patch KB2962486 which prevents credentials from being stored in GPPs.[^5] [^6]  |
| [[T1137.005-outlook_rules\|T1137.005]] | [[T1137.005-outlook_rules\|Outlook Rules]] | For the Outlook methods, blocking macros may be ineffective as the Visual Basic engine used for these features is separate from the macro scripting engine.[^3]  Microsoft has released patches to try to address each issue. Ensure KB3191938 which blocks Outlook Visual Basic and displays a malicious code warning, KB4011091 which disables custom forms by default, and KB4011162 which removes the legacy Home Page feature, are applied to systems.[^8]  |
| [[T1195-supply_chain_compromise\|T1195]] | [[T1195-supply_chain_compromise\|Supply Chain Compromise]] | A patch management process should be implemented to check unused dependencies, unmaintained and/or previously vulnerable dependencies, unnecessary features, components, files, and documentation. |
| [[T1539-steal_web_session_cookie\|T1539]] | [[T1539-steal_web_session_cookie\|Steal Web Session Cookie]] | Regularly update web browsers, password managers, and all related software to the latest versions. Keeping software up-to-date reduces the risk of vulnerabilities being exploited by attackers to extract stored credentials or session cookies. |
| [[T1555.003-credentials_from_web_browsers\|T1555.003]] | [[T1555.003-credentials_from_web_browsers\|Credentials from Web Browsers]] | Regularly update web browsers, password managers, and all related software to the latest versions. Keeping software up-to-date reduces the risk of vulnerabilities being exploited by attackers to extract stored credentials or session cookies. |
| [[T1602.002-network_device_configuration_dump\|T1602.002]] | [[T1602.002-network_device_configuration_dump\|Network Device Configuration Dump]] | Keep system images and software updated and migrate to SNMPv3.[^1]  |
| [[T1546.010-appinit_dlls\|T1546.010]] | [[T1546.010-appinit_dlls\|AppInit DLLs]] | Upgrade to Windows 8 or later and enable secure boot. |
| [[T1574.001-dll\|T1574.001]] | [[T1574.001-dll\|DLL]] | Update software regularly to include patches that fix DLL side-loading vulnerabilities. |
| [[T1176-software_extensions\|T1176]] | [[T1176-software_extensions\|Software Extensions]] | Ensure operating systems and software are using the most current version.  |
| [[T1203-exploitation_for_client_execution\|T1203]] | [[T1203-exploitation_for_client_execution\|Exploitation for Client Execution]] | Perform regular software updates to mitigate exploitation risk. Keeping software up-to-date with the latest security patches helps prevent adversaries from exploiting known vulnerabilities in client software, reducing the risk of successful attacks. |
| [[T1542.002-component_firmware\|T1542.002]] | [[T1542.002-component_firmware\|Component Firmware]] | Perform regular firmware updates to mitigate risks of exploitation and/or abuse. |
| [[T1137.003-outlook_forms\|T1137.003]] | [[T1137.003-outlook_forms\|Outlook Forms]] | For the Outlook methods, blocking macros may be ineffective as the Visual Basic engine used for these features is separate from the macro scripting engine.[^3]  Microsoft has released patches to try to address each issue. Ensure KB3191938 which blocks Outlook Visual Basic and displays a malicious code warning, KB4011091 which disables custom forms by default, and KB4011162 which removes the legacy Home Page feature, are applied to systems.[^8]  |
| [[T1190-exploit_public_facing_application\|T1190]] | [[T1190-exploit_public_facing_application\|Exploit Public-Facing Application]] | Update software regularly by employing patch management for externally exposed applications. |
| [[T1195.002-compromise_software_supply_chain\|T1195.002]] | [[T1195.002-compromise_software_supply_chain\|Compromise Software Supply Chain]] | A patch management process should be implemented to check unused applications, unmaintained and/or previously vulnerable software, unnecessary features, components, files, and documentation. |
| [[T1210-exploitation_of_remote_services\|T1210]] | [[T1210-exploitation_of_remote_services\|Exploitation of Remote Services]] | Update software regularly by employing patch management for internal enterprise endpoints and servers. |
| [[T1546.011-application_shimming\|T1546.011]] | [[T1546.011-application_shimming\|Application Shimming]] | Microsoft released an optional patch update - KB3045645 - that will remove the "auto-elevate" flag within the sdbinst.exe. This will prevent use of application shimming to bypass UAC. |
| [[T1546-event_triggered_execution\|T1546]] | [[T1546-event_triggered_execution\|Event Triggered Execution]] | Perform regular software updates to mitigate exploitation risk. |


## References

[^1]: [Cisco Blog Legacy Device Attacks](https://community.cisco.com/t5/security-blogs/attackers-continue-to-target-legacy-devices/ba-p/4169954)


[^2]: [Github UACMe](https://github.com/hfiref0x/UACME)


[^3]: [SensePost Outlook Forms](https://sensepost.com/blog/2017/outlook-forms-and-shells/)


[^4]: [Browser-updates](https://www.proofpoint.com/us/blog/threat-insight/are-you-sure-your-browser-date-current-landscape-fake-browser-updates)


[^5]: [ADSecurity Finding Passwords in SYSVOL](https://adsecurity.org/?p=2288)


[^6]: [MS14-025](https://support.microsoft.com/en-us/help/2962486/ms14-025-vulnerability-in-group-policy-preferences-could-allow-elevati)


[^7]: [NSA Spotting](https://massarobi.wordpress.com/wp-content/uploads/2017/03/spotting-the-adversary-with-windows-event-log-monitoring.pdf)


[^8]: [SensePost Outlook Home Page](https://sensepost.com/blog/2017/outlook-home-page-another-ruler-vector/)

