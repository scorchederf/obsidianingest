---
aliases: 
    - M1038
    
mitre-attack: https://attack.mitre.org/mitigations/M1038
---

## M1038

Prevent the execution of unauthorized or malicious code on systems by implementing application control, script blocking, and other execution prevention mechanisms. This ensures that only trusted and authorized code is executed, reducing the risk of malware and unauthorized actions. This mitigation can be implemented through the following measures:<br><br>Application Control:<br><br>- Use Case: Use tools like AppLocker or Windows Defender Application Control (WDAC) to create whitelists of authorized applications and block unauthorized ones. On Linux, use tools like SELinux or AppArmor to define mandatory access control policies for application execution.<br>- Implementation: Allow only digitally signed or pre-approved applications to execute on servers and endpoints. (e.g., `New-AppLockerPolicy -PolicyType Enforced -FilePath "C:\Policies\AppLocker.xml"`) <br><br><br>Script Blocking:<br><br>- Use Case: Use script control mechanisms to block unauthorized execution of scripts, such as PowerShell or JavaScript. Web Browsers: Use browser extensions or settings to block JavaScript execution from untrusted sources.<br>- Implementation: Configure PowerShell to enforce Constrained Language Mode for non-administrator users. (e.g., `Set-ExecutionPolicy AllSigned`) <br><br>Executable Blocking:<br><br>- Use Case: Prevent execution of binaries from suspicious locations, such as `%TEMP%` or `%APPDATA%` directories.<br>- Implementation: Block execution of `.exe`, `.bat`, or `.ps1` files from user-writable directories.<br><br>Dynamic Analysis Prevention:<br>- Use Case: Use behavior-based execution prevention tools to identify and block malicious activity in real time.<br>- Implemenation: Employ EDR solutions that analyze runtime behavior and block suspicious code execution.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1219.001-ide_tunneling\|T1219.001]] | [[T1219.001-ide_tunneling\|IDE Tunneling]] | Use Group Policies to require user authentication by disabling anonymous tunnel access, preventing any unauthenticated tunnel creation or usage. Disable the Visual Studio Dev Tunnels feature to block tunnel-related commands, allowing only minimal exceptions for utility functions (unset, echo, ping, and user). Restrict tunnel access to approved Microsoft Entra tenant IDs by specifying allowed tenants; all other users are denied access by default.[^26] [^5]  |
| [[T1216.002-syncappvpublishingserver\|T1216.002]] | [[T1216.002-syncappvpublishingserver\|SyncAppvPublishingServer]] | Certain signed scripts that can be used to execute other programs may not be necessary within a given environment. Use application control configured to block execution of these scripts if they are not required for a given system or network to prevent potential misuse by adversaries. |
| [[T1553.003-sip_and_trust_provider_hijacking\|T1553.003]] | [[T1553.003-sip_and_trust_provider_hijacking\|SIP and Trust Provider Hijacking]] | Enable application control solutions such as AppLocker and/or Device Guard to block the loading of malicious SIP DLLs. |
| [[T1059.010-autohotkey_autoit\|T1059.010]] | [[T1059.010-autohotkey_autoit\|AutoHotKey & AutoIT]] | Use application control to prevent execution of `AutoIt3.exe`, `AutoHotkey.exe`, and other related features that may not be required for a given system or network to prevent potential misuse by adversaries. |
| [[T1036.005-match_legitimate_resource_name_or_location\|T1036.005]] | [[T1036.005-match_legitimate_resource_name_or_location\|Match Legitimate Resource Name or Location]] | Use tools that restrict program execution via application control by attributes other than file name for common operating system utilities that are needed. |
| [[T1574.008-path_interception_by_search_order_hijacking\|T1574.008]] | [[T1574.008-path_interception_by_search_order_hijacking\|Path Interception by Search Order Hijacking]] | Adversaries will likely need to place new binaries in locations to be executed through this weakness. Identify and block potentially malicious software executed path interception by using application control tools, like Windows Defender Application Control, AppLocker, or Software Restriction Policies where appropriate.[^16] [^25] [^13] [^20] [^19] [^2]  |
| [[T1574.006-dynamic_linker_hijacking\|T1574.006]] | [[T1574.006-dynamic_linker_hijacking\|Dynamic Linker Hijacking]] | Adversaries may use new payloads to execute this technique. Identify and block potentially malicious software executed through hijacking by using application control solutions also capable of blocking libraries loaded by legitimate software. |
| [[T1546.002-screensaver\|T1546.002]] | [[T1546.002-screensaver\|Screensaver]] | Block .scr files from being executed from non-standard locations. |
| [[T1564.003-hidden_window\|T1564.003]] | [[T1564.003-hidden_window\|Hidden Window]] | Limit or restrict program execution using anti-virus software. On MacOS, allowlist programs that are allowed to have the plist tag. All other programs should be considered suspicious. |
| [[T1553-subvert_trust_controls\|T1553]] | [[T1553-subvert_trust_controls\|Subvert Trust Controls]] | System settings can prevent applications from running that haven't been downloaded through the Apple Store (or other legitimate repositories) which can help mitigate some of these issues. Also enable application control solutions such as AppLocker and/or Device Guard to block the loading of malicious content. |
| [[T1176.002-ide_extensions\|T1176.002]] | [[T1176.002-ide_extensions\|IDE Extensions]] | Set an IDE extension allow or deny list as appropriate for your security policy.   |
| [[T1218.005-mshta\|T1218.005]] | [[T1218.005-mshta\|Mshta]] | Use application control configured to block execution of `mshta.exe` if it is not required for a given system or network to prevent potential misuse by adversaries. For example, in Windows 10 and Windows Server 2016 and above, Windows Defender Application Control (WDAC) policy rules may be applied to block the `mshta.exe` application and to prevent abuse.[^30]  |
| [[T1059.005-visual_basic\|T1059.005]] | [[T1059.005-visual_basic\|Visual Basic]] | Use application control where appropriate. VBA macros obtained from the Internet, based on the file's Mark of the Web (MOTW) attribute, may be blocked from executing in Office applications (ex: Access, Excel, PowerPoint, Visio, and Word) by default starting in Windows Version 2203.[^6]  |
| [[T1218.004-installutil\|T1218.004]] | [[T1218.004-installutil\|InstallUtil]] | Use application control configured to block execution of InstallUtil.exe if it is not required for a given system or network to prevent potential misuse by adversaries. |
| [[T1204-user_execution\|T1204]] | [[T1204-user_execution\|User Execution]] | Application control may be able to prevent the running of executables masquerading as other files. |
| [[T1574.001-dll\|T1574.001]] | [[T1574.001-dll\|DLL]] | Identify and block potentially malicious software executed through DLL hijacking by using application control solutions capable of blocking DLLs loaded by legitimate software.[^3]  |
| [[T1204.004-malicious_copy_and_paste\|T1204.004]] | [[T1204.004-malicious_copy_and_paste\|Malicious Copy and Paste]] | Use application control where appropriate. PowerShell Constrained Language mode can be used to restrict access to sensitive or otherwise dangerous language elements such as those used to execute arbitrary Windows APIs or files (e.g., `Add-Type`).[^24]  |
| [[T1129-shared_modules\|T1129]] | [[T1129-shared_modules\|Shared Modules]] | Identify and block potentially malicious software executed through this technique by using application control tools capable of preventing unknown modules from being loaded. |
| [[T1218.009-regsvcs_regasm\|T1218.009]] | [[T1218.009-regsvcs_regasm\|Regsvcs／Regasm]] | Block execution of Regsvcs.exe and Regasm.exe if they are not required for a given system or network to prevent potential misuse by adversaries. |
| [[T1548-abuse_elevation_control_mechanism\|T1548]] | [[T1548-abuse_elevation_control_mechanism\|Abuse Elevation Control Mechanism]] | System settings can prevent applications from running that haven't been downloaded from legitimate repositories which may help mitigate some of these issues. Not allowing unsigned applications from being run may also mitigate some risk. |
| [[T1548.004-elevated_execution_with_prompt\|T1548.004]] | [[T1548.004-elevated_execution_with_prompt\|Elevated Execution with Prompt]] | System settings can prevent applications from running that haven't been downloaded through the Apple Store which may help mitigate some of these issues. Not allowing unsigned applications from being run may also mitigate some risk. |
| [[T1611-escape_to_host\|T1611]] | [[T1611-escape_to_host\|Escape to Host]] | Use read-only containers, read-only file systems, and minimal images when possible to prevent the running of commands.[^18]  Where possible, also consider using application control and software restriction tools (such as those provided by SELinux) to restrict access to files, processes, and system calls in containers.[^11]  |
| [[T1216.001-pubprn\|T1216.001]] | [[T1216.001-pubprn\|PubPrn]] | Certain signed scripts that can be used to execute other programs may not be necessary within a given environment. Use application control configured to block execution of these scripts if they are not required for a given system or network to prevent potential misuse by adversaries. |
| [[T1547.009-shortcut_modification\|T1547.009]] | [[T1547.009-shortcut_modification\|Shortcut Modification]] | Prevents malicious shortcuts or LNK files from executing unwanted code by ensuring only authorized applications and scripts are allowed to run. |
| [[T1218.012-verclsid\|T1218.012]] | [[T1218.012-verclsid\|Verclsid]] | Use application control configured to block execution of verclsid.exe if it is not required for a given system or network to prevent potential misuse by adversaries. |
| [[T1106-native_api\|T1106]] | [[T1106-native_api\|Native API]] | Identify and block potentially malicious software executed that may be executed through this technique by using application control [^21]  tools, like Windows Defender Application Control[^25] , AppLocker, [^13]  [^20]  or Software Restriction Policies [^22]  where appropriate. [^17]  |
| [[T1127.003-jamplus\|T1127.003]] | [[T1127.003-jamplus\|JamPlus]] | Consider blocking or restricting JamPlus if not required. |
| [[T1218.015-electron_applications\|T1218.015]] | [[T1218.015-electron_applications\|Electron Applications]] | Where possible, enforce binary and application integrity with digital signature verification to prevent untrusted code from executing. For example, do not use `shell.openExternal` with untrusted content.<br><br>Where possible, set `nodeIntegration` to false, which disables access to the Node.js function.[^7]  By disabling access to the Node.js function, this may limit the ability to execute malicious commands by injecting JavaScript code.<br><br>Do not disable `webSecurity`, which may allow for users of the application to invoke malicious content from online sources. |
| [[T1219-remote_access_tools\|T1219]] | [[T1219-remote_access_tools\|Remote Access Tools]] | Use application control to mitigate installation and use of unapproved software that can be used for remote access. |
| [[T1216-system_script_proxy_execution\|T1216]] | [[T1216-system_script_proxy_execution\|System Script Proxy Execution]] | Certain signed scripts that can be used to execute other programs may not be necessary within a given environment. Use application control configured to block execution of these scripts if they are not required for a given system or network to prevent potential misuse by adversaries. |
| [[T1047-windows_management_instrumentation\|T1047]] | [[T1047-windows_management_instrumentation\|Windows Management Instrumentation]] | Use application control configured to block execution of `wmic.exe` if it is not required for a given system or network to prevent potential misuse by adversaries. For example, in Windows 10 and Windows Server 2016 and above, Windows Defender Application Control (WDAC) policy rules may be applied to block the `wmic.exe` application and to prevent abuse.[^30]  |
| [[T1674-input_injection\|T1674]] | [[T1674-input_injection\|Input Injection]] | Denylist scripting and use application control where appropriate. For example, PowerShell Constrained Language mode can be used to restrict access to sensitive or otherwise dangerous language elements such as those used to execute arbitrary Windows APIs or files (e.g., `Add-Type`).[^24]  |
| [[T1059.007-javascript\|T1059.007]] | [[T1059.007-javascript\|JavaScript]] | Denylist scripting where appropriate. |
| [[T1204.002-malicious_file\|T1204.002]] | [[T1204.002-malicious_file\|Malicious File]] | Application control may be able to prevent the running of executables masquerading as other files. |
| [[T1546.010-appinit_dlls\|T1546.010]] | [[T1546.010-appinit_dlls\|AppInit DLLs]] | Adversaries can install new AppInit DLLs binaries to execute this technique. Identify and block potentially malicious software executed through AppInit DLLs functionality by using application control [^21]  tools, like Windows Defender Application Control[^25] , AppLocker, [^13]  [^20]  or Software Restriction Policies [^22]  where appropriate. [^17]  |
| [[T1059.004-unix_shell\|T1059.004]] | [[T1059.004-unix_shell\|Unix Shell]] | Use application control where appropriate. On ESXi hosts, the `execInstalledOnly` feature prevents binaries from being run unless they have been packaged and signed as part of a vSphere installation bundle (VIB).[^12]  |
| [[T1574-hijack_execution_flow\|T1574]] | [[T1574-hijack_execution_flow\|Hijack Execution Flow]] | Adversaries may use new payloads to execute this technique. Identify and block potentially malicious software executed through hijacking by using application control solutions also capable of blocking libraries loaded by legitimate software. |
| [[T1505.004-iis_components\|T1505.004]] | [[T1505.004-iis_components\|IIS Components]] | Restrict unallowed ISAPI extensions and filters from running by specifying a list of ISAPI extensions and filters that can run on IIS.[^1]  |
| [[T1547.004-winlogon_helper_dll\|T1547.004]] | [[T1547.004-winlogon_helper_dll\|Winlogon Helper DLL]] | Identify and block potentially malicious software that may be executed through the Winlogon helper process by using application control [^21]  tools like AppLocker [^13]  [^20]  that are capable of auditing and/or blocking unknown DLLs. |
| [[T1059.002-applescript\|T1059.002]] | [[T1059.002-applescript\|AppleScript]] | Use application control where appropriate. |
| [[T1553.001-gatekeeper_bypass\|T1553.001]] | [[T1553.001-gatekeeper_bypass\|Gatekeeper Bypass]] | System settings can prevent applications from running that haven't been downloaded through the Apple Store which can help mitigate some of these issues.  |
| [[T1036.008-masquerade_file_type\|T1036.008]] | [[T1036.008-masquerade_file_type\|Masquerade File Type]] | Ensure that input sanitization is performed and that files are validated properly before execution; furthermore, implement a strict allow list to ensure that only authorized file types are processed.[^29]  Restrict and/or block execution of files where headers and extensions do not match. <br><br> |
| [[T1218.008-odbcconf\|T1218.008]] | [[T1218.008-odbcconf\|Odbcconf]] | Use application control configured to block execution of Odbcconf.exe if it is not required for a given system or network to prevent potential misuse by adversaries. |
| [[T1685-disable_or_modify_tools\|T1685]] | [[T1685-disable_or_modify_tools\|Disable or Modify Tools]] | Use application control where appropriate, especially regarding the execution of tools outside of the organization's security policies (such as rootkit removal tools) that have been abused to impair system defenses. Ensure that only approved security applications are used and running on enterprise systems. |
| [[T1059-command_and_scripting_interpreter\|T1059]] | [[T1059-command_and_scripting_interpreter\|Command and Scripting Interpreter]] | Use application control where appropriate. For example, PowerShell Constrained Language mode can be used to restrict access to sensitive or otherwise dangerous language elements such as those used to execute arbitrary Windows APIs or files (e.g., `Add-Type`).[^24]  |
| [[T1574.007-path_interception_by_path_environment_variable\|T1574.007]] | [[T1574.007-path_interception_by_path_environment_variable\|Path Interception by PATH Environment Variable]] | Adversaries will likely need to place new binaries in locations to be executed through this weakness. Identify and block potentially malicious software executed path interception by using application control tools, like Windows Defender Application Control, AppLocker, or Software Restriction Policies where appropriate.[^16] [^25] [^13] [^20] [^19] [^2]  |
| [[T1127-trusted_developer_utilities_proxy_execution\|T1127]] | [[T1127-trusted_developer_utilities_proxy_execution\|Trusted Developer Utilities Proxy Execution]] | Certain developer utilities should be blocked or restricted if not required. |
| [[T1490-inhibit_system_recovery\|T1490]] | [[T1490-inhibit_system_recovery\|Inhibit System Recovery]] | Consider using application control configured to block execution of utilities such as `diskshadow.exe` that may not be required for a given system or network to prevent potential misuse by adversaries.  |
| [[T1059.008-network_device_cli\|T1059.008]] | [[T1059.008-network_device_cli\|Network Device CLI]] | TACACS+ can keep control over which commands administrators are permitted to use through the configuration of authentication and command authorization. [^23]  |
| [[T1218-system_binary_proxy_execution\|T1218]] | [[T1218-system_binary_proxy_execution\|System Binary Proxy Execution]] | Consider using application control to prevent execution of binaries that are susceptible to abuse and not required for a given system or network. |
| [[T1218.002-control_panel\|T1218.002]] | [[T1218.002-control_panel\|Control Panel]] | Identify and block potentially malicious and unknown .cpl files by using application control [^21]  tools, like Windows Defender Application Control[^25] , AppLocker, [^13]  [^20]  or Software Restriction Policies [^22]  where appropriate. [^17]  |
| [[T1059.003-windows_command_shell\|T1059.003]] | [[T1059.003-windows_command_shell\|Windows Command Shell]] | Use application control where appropriate. |
| [[T1546.006-lc_load_dylib_addition\|T1546.006]] | [[T1546.006-lc_load_dylib_addition\|LC_LOAD_DYLIB Addition]] | Allow applications via known hashes. |
| [[T1220-xsl_script_processing\|T1220]] | [[T1220-xsl_script_processing\|XSL Script Processing]] | If msxsl.exe is unnecessary, then block its execution to prevent abuse by adversaries. |
| [[T1080-taint_shared_content\|T1080]] | [[T1080-taint_shared_content\|Taint Shared Content]] | Identify potentially malicious software that may be used to taint content or may result from it and audit and/or block the unknown programs by using application control [^21]  tools, like AppLocker, [^13]  [^20]  or Software Restriction Policies [^22]  where appropriate. [^17]  |
| [[T1059.009-cloud_api\|T1059.009]] | [[T1059.009-cloud_api\|Cloud API]] | Use application control where appropriate to block use of PowerShell CmdLets or other host based resources to access cloud API resources. |
| [[T1547.006-kernel_modules_and_extensions\|T1547.006]] | [[T1547.006-kernel_modules_and_extensions\|Kernel Modules and Extensions]] | Application control and software restriction tools, such as SELinux, KSPP, grsecurity MODHARDEN, and Linux kernel tuning can aid in restricting kernel module loading.[^9] [^4] [^8] [^14] [^15]  |
| [[T1574.009-path_interception_by_unquoted_path\|T1574.009]] | [[T1574.009-path_interception_by_unquoted_path\|Path Interception by Unquoted Path]] | Adversaries will likely need to place new binaries in locations to be executed through this weakness. Identify and block potentially malicious software executed path interception by using application control tools, like Windows Defender Application Control, AppLocker, or Software Restriction Policies where appropriate.[^16] [^25] [^13] [^20] [^19] [^2]  |
| [[T1059.006-python\|T1059.006]] | [[T1059.006-python\|Python]] | Denylist Python where not required. |
| [[T1059.013-container_cli_api\|T1059.013]] | [[T1059.013-container_cli_api\|Container CLI／API]] | Deny scripting where appropriate. Tools such as Python or Go can utilize Kubernetes and Docker within a client library and execute commands within their application. |
| [[T1059.011-lua\|T1059.011]] | [[T1059.011-lua\|Lua]] | Denylist Lua interpreters where appropriate. |
| [[T1127.001-msbuild\|T1127.001]] | [[T1127.001-msbuild\|MSBuild]] | Use application control configured to block execution of `msbuild.exe` if it is not required for a given system or network to prevent potential misuse by adversaries. For example, in Windows 10 and Windows Server 2016 and above, Windows Defender Application Control (WDAC) policy rules may be applied to block the `msbuild.exe` application and to prevent abuse.[^30]  |
| [[T1574.012-cor_profiler\|T1574.012]] | [[T1574.012-cor_profiler\|COR_PROFILER]] | Identify and block potentially malicious unmanaged COR_PROFILER profiling DLLs  by using application control solutions like AppLocker that are capable of auditing and/or blocking unapproved DLLs.[^21] [^13] [^20]  |
| [[T1546.008-accessibility_features\|T1546.008]] | [[T1546.008-accessibility_features\|Accessibility Features]] | Adversaries can replace accessibility features binaries with alternate binaries to execute this technique. Identify and block potentially malicious software executed through accessibility features functionality by using application control [^21]  tools, like Windows Defender Application Control[^25] , AppLocker, [^13]  [^20]  or Software Restriction Policies [^22]  where appropriate. [^17]  |
| [[T1546.009-appcert_dlls\|T1546.009]] | [[T1546.009-appcert_dlls\|AppCert DLLs]] | Adversaries install new AppCertDLL binaries to execute this technique. Identify and block potentially malicious software executed through AppCertDLLs functionality by using application control [^21]  tools, like Windows Defender Application Control[^25] , AppLocker, [^13]  [^20]  or Software Restriction Policies [^22]  where appropriate. [^17]  |
| [[T1176-software_extensions\|T1176]] | [[T1176-software_extensions\|Software Extensions]] | Set an extension allow or deny list as appropriate for your security policy.  |
| [[T1068-exploitation_for_privilege_escalation\|T1068]] | [[T1068-exploitation_for_privilege_escalation\|Exploitation for Privilege Escalation]] | Consider blocking the execution of known vulnerable drivers that adversaries may exploit to execute code in kernel mode. Validate driver block rules in audit mode to ensure stability prior to production deployment.[^27]  |
| [[T1176.001-browser_extensions\|T1176.001]] | [[T1176.001-browser_extensions\|Browser Extensions]] | Set a browser extension allow or deny list as appropriate for your security policy.[^10]  |
| [[T1553.005-mark_of_the_web_bypass\|T1553.005]] | [[T1553.005-mark_of_the_web_bypass\|Mark-of-the-Web Bypass]] | Consider blocking container file types at web and/or email gateways. Consider unregistering container file extensions in Windows File Explorer.[^28]  |
| [[T1218.003-cmstp\|T1218.003]] | [[T1218.003-cmstp\|CMSTP]] | Consider using application control configured to block execution of CMSTP.exe if it is not required for a given system or network to prevent potential misuse by adversaries. |
| [[T1219.002-remote_desktop_software\|T1219.002]] | [[T1219.002-remote_desktop_software\|Remote Desktop Software]] | Use application control to mitigate installation and use of unapproved software that can be used for remote access. |
| [[T1036-masquerading\|T1036]] | [[T1036-masquerading\|Masquerading]] | Use tools that restrict program execution via application control by attributes other than file name for common operating system utilities that are needed. |
| [[T1218.014-mmc\|T1218.014]] | [[T1218.014-mmc\|MMC]] | Use application control configured to block execution of MMC if it is not required for a given system or network to prevent potential misuse by adversaries. |
| [[T1218.001-compiled_html_file\|T1218.001]] | [[T1218.001-compiled_html_file\|Compiled HTML File]] | Consider using application control to prevent execution of hh.exe if it is not required for a given system or network to prevent potential misuse by adversaries. |
| [[T1218.013-mavinject\|T1218.013]] | [[T1218.013-mavinject\|Mavinject]] | Use application control configured to block execution of mavinject.exe if it is not required for a given system or network to prevent potential misuse by adversaries. |
| [[T1564.006-run_virtual_instance\|T1564.006]] | [[T1564.006-run_virtual_instance\|Run Virtual Instance]] | Use application control to mitigate installation and use of unapproved virtualization software. |
| [[T1609-container_administration_command\|T1609]] | [[T1609-container_administration_command\|Container Administration Command]] | Use read-only containers, read-only file systems, and minimal images when possible to prevent the execution of commands.[^18]  Where possible, also consider using application control and software restriction tools (such as those provided by SELinux) to restrict access to files, processes, and system calls in containers.[^11]  |
| [[T1685.003-modify_or_spoof_tool_ui\|T1685.003]] | [[T1685.003-modify_or_spoof_tool_ui\|Modify or Spoof Tool UI]] | Use application controls to mitigate installation and use of payloads that may be utilized to spoof security alerting. |
| [[T1059.001-powershell\|T1059.001]] | [[T1059.001-powershell\|PowerShell]] | Use application control where appropriate. PowerShell Constrained Language mode can be used to restrict access to sensitive or otherwise dangerous language elements such as those used to execute arbitrary Windows APIs or files (e.g., `Add-Type`).[^24]  |


## References

[^1]: [Microsoft ISAPICGIRestriction 2016](https://docs.microsoft.com/en-us/iis/configuration/system.webserver/security/isapicgirestriction/)


[^2]: [Microsoft Using Software Restriction ](https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2012-R2-and-2012/ee791851(v=ws.11)?redirectedfrom=MSDN)


[^3]: [Microsoft AppLocker DLL](https://learn.microsoft.com/en-us/windows/security/application-security/application-control/app-control-for-business/applocker/dll-rules-in-applocker)


[^4]: [Wikibooks Grsecurity](https://en.wikibooks.org/wiki/Grsecurity/The_RBAC_System)


[^5]: [Microsoft Dev Tunnels Group Policies](https://techcommunity.microsoft.com/blog/azuredevcommunityblog/manage-dev-tunnels-with-group-policies/4149472)


[^6]: [Default VBS macros Blocking ](https://techcommunity.microsoft.com/t5/microsoft-365-blog/helping-users-stay-safe-blocking-internet-macros-by-default-in/ba-p/3071805)


[^7]: [Electron Security 3](https://medium.com/certik/vulnerability-in-electron-based-application-unintentionally-giving-malicious-code-room-to-run-e2e1447d01b8)


[^8]: [Kernel Self Protection Project](https://www.kernel.org/doc/html/latest/security/self-protection.html)


[^9]: [Kernel.org Restrict Kernel Module](https://patchwork.kernel.org/patch/8754821/)


[^10]: [Technospot Chrome Extensions GP](http://www.technospot.net/blogs/block-chrome-extensions-using-google-chrome-group-policy-settings/)


[^11]: [Kubernetes Security Context](https://kubernetes.io/docs/tasks/configure-pod-container/security-context/)


[^12]: [Google Cloud Threat Intelligence ESXi Hardening 2023](https://cloud.google.com/blog/topics/threat-intelligence/vmware-detection-containment-hardening)


[^13]: [Windows Commands JPCERT](https://blogs.jpcert.or.jp/en/2016/01/windows-commands-abused-by-attackers.html)


[^14]: [Increasing Linux kernel integrity](https://linux-audit.com/increase-kernel-integrity-with-disabled-linux-kernel-modules-loading/)


[^15]: [LKM loading kernel restrictions](https://xorl.wordpress.com/2018/02/17/lkm-loading-kernel-restrictions/)


[^16]: [SANS Application Whitelisting](https://www.sans.org/reading-room/whitepapers/application/application-whitelisting-panacea-propaganda-33599)


[^17]: [TechNet Applocker vs SRP](https://technet.microsoft.com/en-us/library/ee791851.aspx)


[^18]: [Kubernetes Hardening Guide](https://media.defense.gov/2022/Aug/29/2003066362/-1/-1/0/CTR_KUBERNETES_HARDENING_GUIDANCE_1.2_20220829.PDF)


[^19]: [Microsoft Application Lockdown](https://docs.microsoft.com/en-us/previous-versions/technet-magazine/cc510322(v=msdn.10)?redirectedfrom=MSDN)


[^20]: [NSA MS AppLocker](https://apps.nsa.gov/iaarchive/library/ia-guidance/tech-briefs/application-whitelisting-using-microsoft-applocker.cfm)


[^21]: [Beechey 2010](http://www.sans.org/reading-room/whitepapers/application/application-whitelisting-panacea-propaganda-33599)


[^22]: [Corio 2008](https://learn.microsoft.com/en-us/previous-versions/technet-magazine/cc510322(v=msdn.10))


[^23]: [Cisco IOS Software Integrity Assurance - TACACS](https://tools.cisco.com/security/center/resources/integrity_assurance.html#39)


[^24]: [Microsoft PowerShell CLM](https://devblogs.microsoft.com/powershell/powershell-constrained-language-mode/)


[^25]: [Microsoft Windows Defender Application Control](https://docs.microsoft.com/en-us/windows/security/threat-protection/windows-defender-application-control/windows-defender-application-control)


[^26]: [Microsoft Dev Tunnels Group Policy Mitigation](https://learn.microsoft.com/en-us/azure/developer/dev-tunnels/policies)


[^27]: [Microsoft Driver Block Rules](https://docs.microsoft.com/en-us/windows/security/threat-protection/windows-defender-application-control/microsoft-recommended-driver-block-rules)


[^28]: [Dormann Dangers of VHD 2019](https://insights.sei.cmu.edu/cert/2019/09/the-dangers-of-vhd-and-vhdx-files.html)


[^29]: [file_upload_attacks_pt2](https://blog.yeswehack.com/yeswerhackers/file-upload-attacks-part-2/)


[^30]: [Microsoft WDAC](https://docs.microsoft.com/windows/security/threat-protection/windows-defender-application-control/microsoft-recommended-block-rules)

