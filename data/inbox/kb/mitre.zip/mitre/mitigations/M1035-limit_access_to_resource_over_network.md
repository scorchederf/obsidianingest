---
aliases: 
    - M1035
    
mitre-attack: https://attack.mitre.org/mitigations/M1035
---

## M1035

Restrict access to network resources, such as file shares, remote systems, and services, to only those users, accounts, or systems with a legitimate business requirement. This can include employing technologies like network concentrators, RDP gateways, and zero-trust network access (ZTNA) models, alongside hardening services and protocols. This mitigation can be implemented through the following measures:<br><br>Audit and Restrict Access:<br><br>- Regularly audit permissions for file shares, network services, and remote access tools.<br>- Remove unnecessary access and enforce least privilege principles for users and services.<br>- Use Active Directory and IAM tools to restrict access based on roles and attributes.<br><br>Deploy Secure Remote Access Solutions:<br><br>- Use RDP gateways, VPN concentrators, and ZTNA solutions to aggregate and secure remote access connections.<br>- Configure access controls to restrict connections based on time, device, and user identity.<br>- Enforce MFA for all remote access mechanisms.<br><br>Disable Unnecessary Services:<br><br>- Identify running services using tools like netstat (Windows/Linux) or Nmap.<br>- Disable unused services, such as Telnet, FTP, and legacy SMB, to reduce the attack surface.<br>- Use firewall rules to block traffic on unused ports and protocols.<br><br>Network Segmentation and Isolation:<br><br>- Use VLANs, firewalls, or micro-segmentation to isolate critical network resources from general access.<br>- Restrict communication between subnets to prevent lateral movement.<br><br>Monitor and Log Access:<br><br>- Monitor access attempts to file shares, RDP, and remote network resources using SIEM tools.<br>- Enable auditing and logging for successful and failed attempts to access restricted resources.<br><br>*Tools for Implementation*<br><br>File Share Management:<br><br>- Microsoft Active Directory Group Policies<br>- Samba (Linux/Unix file share management)<br>- AccessEnum (Windows access auditing tool)<br><br>Secure Remote Access:<br><br>- Microsoft Remote Desktop Gateway<br>- Apache Guacamole (open-source RDP/VNC gateway)<br>- Zero Trust solutions: Tailscale, Cloudflare Zero Trust<br><br>Service and Protocol Hardening:<br><br>- Nmap or Nessus for network service discovery<br>- Windows Group Policy Editor for disabling SMBv1, Telnet, and legacy protocols<br>- iptables or firewalld (Linux) for blocking unnecessary traffic<br><br>Network Segmentation:<br><br>- pfSense for open-source network isolation

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1542-pre_os_boot\|T1542]] | [[T1542-pre_os_boot\|Pre-OS Boot]] | Prevent access to file shares, remote access to systems, unnecessary services. Mechanisms to limit access may include use of network concentrators, RDP gateways, etc. |
| [[T1557-adversary_in_the_middle\|T1557]] | [[T1557-adversary_in_the_middle\|Adversary-in-the-Middle]] | Limit access to network infrastructure and resources that can be used to reshape traffic or otherwise produce AiTM conditions. |
| [[T1563.002-rdp_hijacking\|T1563.002]] | [[T1563.002-rdp_hijacking\|RDP Hijacking]] | Use remote desktop gateways. |
| [[T1552.005-cloud_instance_metadata_api\|T1552.005]] | [[T1552.005-cloud_instance_metadata_api\|Cloud Instance Metadata API]] | Limit access to the Instance Metadata API using a host-based firewall such as iptables. |
| [[T1612-build_image_on_host\|T1612]] | [[T1612-build_image_on_host\|Build Image on Host]] | Limit communications with the container service to local Unix sockets or remote access via SSH. Require secure port access to communicate with the APIs over TLS by disabling unauthenticated access to the Docker API on port 2375. Instead, communicate with the Docker API over TLS on port 2376.[^6]  |
| [[T1021.001-remote_desktop_protocol\|T1021.001]] | [[T1021.001-remote_desktop_protocol\|Remote Desktop Protocol]] | Use remote desktop gateways. |
| [[T1021-remote_services\|T1021]] | [[T1021-remote_services\|Remote Services]] | Prevent unnecessary remote access to file shares, hypervisors, sensitive systems, etc. Mechanisms to limit access may include use of network concentrators, RDP gateways, etc.[^3]  |
| [[T1200-hardware_additions\|T1200]] | [[T1200-hardware_additions\|Hardware Additions]] | Establish network access control policies, such as using device certificates and the 802.1x standard. [^4]  Restrict use of DHCP to registered devices to prevent unregistered devices from communicating with trusted systems. |
| [[T1542.005-tftp_boot\|T1542.005]] | [[T1542.005-tftp_boot\|TFTP Boot]] | Restrict use of protocols without encryption or authentication mechanisms. Limit access to administrative and management interfaces from untrusted network sources.  |
| [[T1552.007-container_api\|T1552.007]] | [[T1552.007-container_api\|Container API]] | Limit communications with the container service to managed and secured channels, such as local Unix sockets or remote access via SSH. Require secure port access to communicate with the APIs over TLS by disabling unauthenticated access to the Docker API and Kubernetes API Server.[^6] [^5]  In Kubernetes clusters deployed in cloud environments, use native cloud platform features to restrict the IP ranges that are permitted to access to API server.[^7]  Where possible, consider enabling just-in-time (JIT) access to the Kubernetes API to place additional restrictions on access.[^2]  |
| [[T1610-deploy_container\|T1610]] | [[T1610-deploy_container\|Deploy Container]] | Limit communications with the container service to managed and secured channels, such as local Unix sockets or remote access via SSH. Require secure port access to communicate with the APIs over TLS by disabling unauthenticated access to the Docker API, Kubernetes API Server, and container orchestration web applications.[^6] [^5]  In Kubernetes clusters deployed in cloud environments, use native cloud platform features to restrict the IP ranges that are permitted to access to API server.[^7]  Where possible, consider enabling just-in-time (JIT) access to the Kubernetes API to place additional restrictions on access.[^2]  |
| [[T1133-external_remote_services\|T1133]] | [[T1133-external_remote_services\|External Remote Services]] | Limit access to remote services through centrally managed concentrators such as VPNs and other managed remote access systems. |
| [[T1552-unsecured_credentials\|T1552]] | [[T1552-unsecured_credentials\|Unsecured Credentials]] | Limit network access to sensitive services, such as the Instance Metadata API. |
| [[T1021.002-smb_windows_admin_shares\|T1021.002]] | [[T1021.002-smb_windows_admin_shares\|SMB／Windows Admin Shares]] | Consider disabling Windows administrative shares. |
| [[T1613-container_and_resource_discovery\|T1613]] | [[T1613-container_and_resource_discovery\|Container and Resource Discovery]] | Limit communications with the container service to managed and secured channels, such as local Unix sockets or remote access via SSH. Require secure port access to communicate with the APIs over TLS by disabling unauthenticated access to the Docker API and Kubernetes API Server.[^6] [^5]  In Kubernetes clusters deployed in cloud environments, use native cloud platform features to restrict the IP ranges that are permitted to access to API server.[^7]  Where possible, consider enabling just-in-time (JIT) access to the Kubernetes API to place additional restrictions on access.[^2]  |
| [[T1190-exploit_public_facing_application\|T1190]] | [[T1190-exploit_public_facing_application\|Exploit Public-Facing Application]] | Ensure that all publicly exposed services are actually intended to be so, and restrict access to any that should only be available internally.  |
| [[T1557.002-arp_cache_poisoning\|T1557.002]] | [[T1557.002-arp_cache_poisoning\|ARP Cache Poisoning]] | Create static ARP entries for networked devices. Implementing static ARP entries may be infeasible for large networks. |
| [[T1546.008-accessibility_features\|T1546.008]] | [[T1546.008-accessibility_features\|Accessibility Features]] | If possible, use a Remote Desktop Gateway to manage connections and security configuration of RDP within a network.[^1]  |
| [[T1609-container_administration_command\|T1609]] | [[T1609-container_administration_command\|Container Administration Command]] | Limit communications with the container service to managed and secured channels, such as local Unix sockets or remote access via SSH. Require secure port access to communicate with the APIs over TLS by disabling unauthenticated access to the Docker API and Kubernetes API Server.[^6] [^5]  In Kubernetes clusters deployed in cloud environments, use native cloud platform features to restrict the IP ranges that are permitted to access to API server.[^7]  Where possible, consider enabling just-in-time (JIT) access to the Kubernetes API to place additional restrictions on access.[^2]  |


## References

[^1]: [TechNet RDP Gateway](https://technet.microsoft.com/en-us/library/cc731150.aspx)


[^2]: [Microsoft AKS Azure AD 2023](https://learn.microsoft.com/en-us/azure/aks/managed-aad)


[^3]: [Sygnia ESXi Ransomware 2024](https://www.sygnia.co/blog/esxi-ransomware-attacks/)


[^4]: [Wikipedia 802.1x](https://en.wikipedia.org/wiki/IEEE_802.1X)


[^5]: [Kubernetes API Control Access](https://kubernetes.io/docs/concepts/security/controlling-access/)


[^6]: [Docker Daemon Socket Protect](https://docs.docker.com/engine/security/protect-access/)


[^7]: [Kubernetes Cloud Native Security](https://kubernetes.io/docs/concepts/security/overview/)

