---
aliases: 
    - M1042
    
mitre-attack: https://attack.mitre.org/mitigations/M1042
---

## M1042

Disable or remove unnecessary and potentially vulnerable software, features, or services to reduce the attack surface and prevent abuse by adversaries. This involves identifying software or features that are no longer needed or that could be exploited and ensuring they are either removed or properly disabled. This mitigation can be implemented through the following measures: <br><br>Remove Legacy Software:<br><br>- Use Case: Disable or remove older versions of software that no longer receive updates or security patches (e.g., legacy Java, Adobe Flash).<br>- Implementation: A company removes Flash Player from all employee systems after it has reached its end-of-life date.<br><br>Disable Unused Features:<br><br>- Use Case: Turn off unnecessary operating system features like SMBv1, Telnet, or RDP if they are not required.<br>- Implementation: Disable SMBv1 in a Windows environment to mitigate vulnerabilities like EternalBlue.<br><br>Control Applications Installed by Users:<br><br>- Use Case: Prevent users from installing unauthorized software via group policies or other management tools.<br>- Implementation: Block user installations of unauthorized file-sharing applications (e.g., BitTorrent clients) in an enterprise environment.<br><br>Remove Unnecessary Services:<br><br>- Use Case: Identify and disable unnecessary default services running on endpoints, servers, or network devices.<br>- Implementation: Disable unused administrative shares (e.g., C$, ADMIN$) on workstations.<br><br>Restrict Add-ons and Plugins:<br><br>- Use Case: Remove or disable browser plugins and add-ons that are not needed for business purposes.<br>- Implementation: Disable Java and ActiveX plugins in web browsers to prevent drive-by attacks.<br><br>

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1547.007-re_opened_applications\|T1547.007]] | [[T1547.007-re_opened_applications\|Re-opened Applications]] | This feature can be disabled entirely with the following terminal command: `defaults write -g ApplePersistence -bool no`. |
| [[T1021.004-ssh\|T1021.004]] | [[T1021.004-ssh\|SSH]] | Disable the SSH daemon on systems that do not require it, especially ESXi servers. For macOS, ensure Remote Login is disabled under Sharing Preferences.[^11]  |
| [[T1671-cloud_application_integration\|T1671]] | [[T1671-cloud_application_integration\|Cloud Application Integration]] | Do not allow users to add new application integrations into a SaaS environment. In Entra ID environments, consider enforcing the “Do not allow user consent” option.[^12]  |
| [[T1021.005-vnc\|T1021.005]] | [[T1021.005-vnc\|VNC]] | Uninstall any VNC server software where not required. |
| [[T1210-exploitation_of_remote_services\|T1210]] | [[T1210-exploitation_of_remote_services\|Exploitation of Remote Services]] | Minimize available services to only those that are necessary. |
| [[T1059.005-visual_basic\|T1059.005]] | [[T1059.005-visual_basic\|Visual Basic]] | Turn off or restrict access to unneeded VB components. |
| [[T1595.003-wordlist_scanning\|T1595.003]] | [[T1595.003-wordlist_scanning\|Wordlist Scanning]] | Remove or disable access to any systems, resources, and infrastructure that are not explicitly required to be available externally. |
| [[T1021.006-windows_remote_management\|T1021.006]] | [[T1021.006-windows_remote_management\|Windows Remote Management]] | Disable the WinRM service. |
| [[T1559-inter_process_communication\|T1559]] | [[T1559-inter_process_communication\|Inter-Process Communication]] | Registry keys specific to Microsoft Office feature control security can be set to disable automatic DDE/OLE execution. [^6] [^27] [^3]  Microsoft also created, and enabled by default, Registry keys to completely disable DDE execution in Word and Excel.[^16]  |
| [[T1564.006-run_virtual_instance\|T1564.006]] | [[T1564.006-run_virtual_instance\|Run Virtual Instance]] | Disable native virtualization technologies such as Hyper-V if not necessary within a given environment. Consider also disabling Windows Sandbox if it is not needed to test or debug applications. |
| [[T1557.001-name_resolution_poisoning_and_smb_relay\|T1557.001]] | [[T1557.001-name_resolution_poisoning_and_smb_relay\|Name Resolution Poisoning and SMB Relay]] | Disable LLMNR, mDNS, and NetBIOS in local computer security settings or by group policy if they are not needed within an environment. [^5]  |
| [[T1046-network_service_discovery\|T1046]] | [[T1046-network_service_discovery\|Network Service Discovery]] | Ensure that unnecessary ports and services are closed to prevent risk of discovery and potential exploitation. |
| [[T1218.015-electron_applications\|T1218.015]] | [[T1218.015-electron_applications\|Electron Applications]] | Remove or deny access to unnecessary and potentially vulnerable software and features to prevent abuse by adversaries. Many native binaries may not be necessary within a given environment: for example, consider disabling the Node.js integration in all renderers that display remote content to protect users by limiting adversaries’ power to plant malicious JavaScript within Electron applications.[^8]  |
| [[T1127.002-clickonce\|T1127.002]] | [[T1127.002-clickonce\|ClickOnce]] | Disable ClickOnce installations from the internet using the following registry key: <br>`\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\.NETFramework\Security\TrustManager\PromptingLevel — Internet:Disabled`[^21] [^23] <br><br>ClickOnce may not be necessary within an environment and should be disabled if not being used. |
| [[T1649-steal_or_forge_authentication_certificates\|T1649]] | [[T1649-steal_or_forge_authentication_certificates\|Steal or Forge Authentication Certificates]] | Consider disabling old/dangerous authentication protocols (e.g. NTLM), as well as unnecessary certificate features, such as potentially vulnerable AD CS web and other enrollment server roles.[^14]  |
| [[T1114.003-email_forwarding_rule\|T1114.003]] | [[T1114.003-email_forwarding_rule\|Email Forwarding Rule]] | Consider disabling external email forwarding.[^25]  |
| [[T1557-adversary_in_the_middle\|T1557]] | [[T1557-adversary_in_the_middle\|Adversary-in-the-Middle]] | Disable legacy network protocols that may be used   to intercept network traffic if applicable, especially those that are not needed within an environment. |
| [[T1011-exfiltration_over_other_network_medium\|T1011]] | [[T1011-exfiltration_over_other_network_medium\|Exfiltration Over Other Network Medium]] | Disable WiFi connection, modem, cellular data connection, Bluetooth, or another radio frequency (RF) channel in local computer security settings or by group policy if it is not needed within an environment. |
| [[T1098-account_manipulation\|T1098]] | [[T1098-account_manipulation\|Account Manipulation]] | Remove unnecessary and potentially abusable authentication and authorization mechanisms where possible. |
| [[T1685-disable_or_modify_tools\|T1685]] | [[T1685-disable_or_modify_tools\|Disable or Modify Tools]] | Consider removing previous versions of tools that are unnecessary to the environment when possible. |
| [[T1052.001-exfiltration_over_usb\|T1052.001]] | [[T1052.001-exfiltration_over_usb\|Exfiltration over USB]] | Disable Autorun if it is unnecessary. [^9]  Disallow or restrict removable media at an organizational policy level if they are not required for business operations. [^18]  |
| [[T1553.005-mark_of_the_web_bypass\|T1553.005]] | [[T1553.005-mark_of_the_web_bypass\|Mark-of-the-Web Bypass]] | Consider disabling auto-mounting of disk image files (i.e., .iso, .img, .vhd, and .vhdx). This can be achieved by modifying the Registry values related to the Windows Explorer file associations in order to disable the automatic Explorer "Mount and Burn" dialog for these file extensions. Note: this will not deactivate the mount functionality itself.[^20]  |
| [[T1505-server_software_component\|T1505]] | [[T1505-server_software_component\|Server Software Component]] | Consider disabling software components from servers when possible to prevent abuse by adversaries.[^1]  |
| [[T1127.003-jamplus\|T1127.003]] | [[T1127.003-jamplus\|JamPlus]] | JamPlus may not be necessary within a given environment and should be removed if not used. |
| [[T1059.001-powershell\|T1059.001]] | [[T1059.001-powershell\|PowerShell]] | It may be possible to remove PowerShell from systems when not needed, but a review should be performed to assess the impact to an environment, since it could be in use for many legitimate purposes and administrative functions.<br><br>Disable/restrict the WinRM Service to help prevent uses of PowerShell for remote execution. |
| [[T1218.008-odbcconf\|T1218.008]] | [[T1218.008-odbcconf\|Odbcconf]] | Odbcconf.exe may not be necessary within a given environment. |
| [[T1091-replication_through_removable_media\|T1091]] | [[T1091-replication_through_removable_media\|Replication Through Removable Media]] | Disable Autorun if it is unnecessary. [^9]  Disallow or restrict removable media at an organizational policy level if it is not required for business operations. [^18]  |
| [[T1137-office_application_startup\|T1137]] | [[T1137-office_application_startup\|Office Application Startup]] | Follow Office macro security best practices suitable for your environment. Disable Office VBA macros from executing.<br><br>Disable Office add-ins. If they are required, follow best practices for securing them by requiring them to be signed and disabling user notification for allowing add-ins. For some add-ins types (WLL, VBA) additional mitigation is likely required as disabling add-ins in the Office Trust Center does not disable WLL nor does it prevent VBA code from executing. [^2]  |
| [[T1546.002-screensaver\|T1546.002]] | [[T1546.002-screensaver\|Screensaver]] | Use Group Policy to disable screensavers if they are unnecessary.[^17]  |
| [[T1059-command_and_scripting_interpreter\|T1059]] | [[T1059-command_and_scripting_interpreter\|Command and Scripting Interpreter]] | Disable or remove any unnecessary or unused shells or interpreters. |
| [[T1021.003-distributed_component_object_model\|T1021.003]] | [[T1021.003-distributed_component_object_model\|Distributed Component Object Model]] | Consider disabling DCOM through Dcomcnfg.exe.[^19]  |
| [[T1021.001-remote_desktop_protocol\|T1021.001]] | [[T1021.001-remote_desktop_protocol\|Remote Desktop Protocol]] | Disable the RDP service if it is unnecessary. |
| [[T1555.004-windows_credential_manager\|T1555.004]] | [[T1555.004-windows_credential_manager\|Windows Credential Manager]] | Consider enabling the “Network access: Do not allow storage of passwords and credentials for network authentication” setting that will prevent network credentials from being stored by the Credential Manager.[^13]  |
| [[T1092-communication_through_removable_media\|T1092]] | [[T1092-communication_through_removable_media\|Communication Through Removable Media]] | Disable Autoruns if it is unnecessary.[^9]  |
| [[T1563.002-rdp_hijacking\|T1563.002]] | [[T1563.002-rdp_hijacking\|RDP Hijacking]] | Disable the RDP service if it is unnecessary. |
| [[T1218.013-mavinject\|T1218.013]] | [[T1218.013-mavinject\|Mavinject]] | Consider removing mavinject.exe if Microsoft App-V is not used within a given environment. |
| [[T1563-remote_service_session_hijacking\|T1563]] | [[T1563-remote_service_session_hijacking\|Remote Service Session Hijacking]] | Disable the remote service (ex: SSH, RDP, etc.) if it is unnecessary. |
| [[T1098.004-ssh_authorized_keys\|T1098.004]] | [[T1098.004-ssh_authorized_keys\|SSH Authorized Keys]] | Disable SSH if it is not necessary on a host or restrict SSH access for specific users/groups using `/etc/ssh/sshd_config`. Setting the `PermitRootLogin` directive to `no` will prevent the root user from logging in via SSH.[^7]  |
| [[T1557.002-arp_cache_poisoning\|T1557.002]] | [[T1557.002-arp_cache_poisoning\|ARP Cache Poisoning]] | Consider disabling updating the ARP cache on gratuitous ARP replies. |
| [[T1219.002-remote_desktop_software\|T1219.002]] | [[T1219.002-remote_desktop_software\|Remote Desktop Software]] | Consider disabling unnecessary remote connection functionality, including both unapproved software installations and specific features built into supported applications. |
| [[T1218.012-verclsid\|T1218.012]] | [[T1218.012-verclsid\|Verclsid]] | Consider removing verclsid.exe if it is not necessary within a given environment. |
| [[T1218.005-mshta\|T1218.005]] | [[T1218.005-mshta\|Mshta]] | Mshta.exe may not be necessary within a given environment since its functionality is tied to older versions of Internet Explorer that have reached end of life. |
| [[T1563.001-ssh_hijacking\|T1563.001]] | [[T1563.001-ssh_hijacking\|SSH Hijacking]] | Ensure that agent forwarding is disabled on systems that do not explicitly require this feature to prevent misuse. [^28]  |
| [[T1133-external_remote_services\|T1133]] | [[T1133-external_remote_services\|External Remote Services]] | Disable or block remotely available services that may be unnecessary. |
| [[T1218.007-msiexec\|T1218.007]] | [[T1218.007-msiexec\|Msiexec]] | Consider disabling the `AlwaysInstallElevated` policy to prevent elevated execution of Windows Installer packages.[^29]  |
| [[T1564.007-vba_stomping\|T1564.007]] | [[T1564.007-vba_stomping\|VBA Stomping]] | Turn off or restrict access to unneeded VB components.[^26]  |
| [[T1059.007-javascript\|T1059.007]] | [[T1059.007-javascript\|JavaScript]] | Turn off or restrict access to unneeded scripting components. |
| [[T1609-container_administration_command\|T1609]] | [[T1609-container_administration_command\|Container Administration Command]] | Remove unnecessary tools and software from containers. |
| [[T1218.004-installutil\|T1218.004]] | [[T1218.004-installutil\|InstallUtil]] | InstallUtil may not be necessary within a given environment. |
| [[T1127.001-msbuild\|T1127.001]] | [[T1127.001-msbuild\|MSBuild]] | MSBuild.exe may not be necessary within an environment and should be removed if not being used. |
| [[T1011.001-exfiltration_over_bluetooth\|T1011.001]] | [[T1011.001-exfiltration_over_bluetooth\|Exfiltration Over Bluetooth]] | Disable Bluetooth in local computer security settings or by group policy if it is not needed within an environment. |
| [[T1218.014-mmc\|T1218.014]] | [[T1218.014-mmc\|MMC]] | MMC may not be necessary within a given environment since it is primarily used by system administrators, not regular users or clients.  |
| [[T1552.005-cloud_instance_metadata_api\|T1552.005]] | [[T1552.005-cloud_instance_metadata_api\|Cloud Instance Metadata API]] | Disable unnecessary metadata services and restrict or disable insecure versions of metadata services that are in use to prevent adversary access.[^24]  |
| [[T1546.014-emond\|T1546.014]] | [[T1546.014-emond\|Emond]] | Consider disabling emond by removing the [Launch Daemon](https://attack.mitre.org/techniques/T1543/004) plist file. |
| [[T1021-remote_services\|T1021]] | [[T1021-remote_services\|Remote Services]] | If remote services, such as the ability to make direct connections to cloud virtual machines, are not required, disable these connection types where feasible. On ESXi servers, consider enabling lockdown mode, which disables direct access to an ESXi host and requires that the host be managed remotely using vCenter.[^22] [^15]  |
| [[T1021.008-direct_cloud_vm_connections\|T1021.008]] | [[T1021.008-direct_cloud_vm_connections\|Direct Cloud VM Connections]] | If direct virtual machine connections are not required for administrative use, disable these connection types where feasible. |
| [[T1137.001-office_template_macros\|T1137.001]] | [[T1137.001-office_template_macros\|Office Template Macros]] | Follow Office macro security best practices suitable for your environment. Disable Office VBA macros from executing.<br><br>Disable Office add-ins. If they are required, follow best practices for securing them by requiring them to be signed and disabling user notification for allowing add-ins. For some add-ins types (WLL, VBA) additional mitigation is likely required as disabling add-ins in the Office Trust Center does not disable WLL nor does it prevent VBA code from executing. [^2] <br> |
| [[T1505.003-web_shell\|T1505.003]] | [[T1505.003-web_shell\|Web Shell]] | Consider disabling functions from web technologies such as PHP’s `evaI()` that may be abused for web shells.[^1]  |
| [[T1205-traffic_signaling\|T1205]] | [[T1205-traffic_signaling\|Traffic Signaling]] | Disable Wake-on-LAN if it is not needed within an environment. |
| [[T1218-system_binary_proxy_execution\|T1218]] | [[T1218-system_binary_proxy_execution\|System Binary Proxy Execution]] | Many native binaries may not be necessary within a given environment. |
| [[T1052-exfiltration_over_physical_medium\|T1052]] | [[T1052-exfiltration_over_physical_medium\|Exfiltration Over Physical Medium]] | Disable Autorun if it is unnecessary. [^9]  Disallow or restrict removable media at an organizational policy level if they are not required for business operations. [^18]  |
| [[T1218.009-regsvcs_regasm\|T1218.009]] | [[T1218.009-regsvcs_regasm\|Regsvcs／Regasm]] | Regsvcs and Regasm may not be necessary within a given environment. |
| [[T1221-template_injection\|T1221]] | [[T1221-template_injection\|Template Injection]] | Consider disabling Microsoft Office macros/active content to prevent the execution of malicious payloads in documents [^4] , though this setting may not mitigate the [Forced Authentication](https://attack.mitre.org/techniques/T1187) use for this technique. |
| [[T1559.002-dynamic_data_exchange\|T1559.002]] | [[T1559.002-dynamic_data_exchange\|Dynamic Data Exchange]] | Registry keys specific to Microsoft Office feature control security can be set to disable automatic DDE/OLE execution. [^6] [^27] [^3]  Microsoft also created, and enabled by default, Registry keys to completely disable DDE execution in Word and Excel.[^16]  |
| [[T1689-downgrade_attack\|T1689]] | [[T1689-downgrade_attack\|Downgrade Attack]] | Consider removing previous versions of tools that are unnecessary to the environment when possible. |
| [[T1098.002-additional_email_delegate_permissions\|T1098.002]] | [[T1098.002-additional_email_delegate_permissions\|Additional Email Delegate Permissions]] | If email delegation is not required, disable it. In Google Workspace this can be accomplished through the Google Admin console.[^10]  |
| [[T1127-trusted_developer_utilities_proxy_execution\|T1127]] | [[T1127-trusted_developer_utilities_proxy_execution\|Trusted Developer Utilities Proxy Execution]] | Specific developer utilities may not be necessary within a given environment and should be removed if not used. |
| [[T1611-escape_to_host\|T1611]] | [[T1611-escape_to_host\|Escape to Host]] | Remove unnecessary tools and software from containers. |
| [[T1219-remote_access_tools\|T1219]] | [[T1219-remote_access_tools\|Remote Access Tools]] | Consider disabling unnecessary remote connection functionality, including both unapproved software installations and specific features built into supported applications. |
| [[T1098.001-additional_cloud_credentials\|T1098.001]] | [[T1098.001-additional_cloud_credentials\|Additional Cloud Credentials]] | Remove unnecessary and potentially abusable authentication mechanisms where possible. For example, in Entra ID environments, disable the app password feature unless explicitly required.  |
| [[T1218.003-cmstp\|T1218.003]] | [[T1218.003-cmstp\|CMSTP]] | CMSTP.exe may not be necessary within a given environment (unless using it for VPN connection installation). |


## References

[^1]: [ITSyndicate Disabling PHP functions](https://itsyndicate.org/blog/disabling-dangerous-php-functions/)


[^2]: [MRWLabs Office Persistence Add-ins](https://web.archive.org/web/20190526112859/https://labs.mwrinfosecurity.com/blog/add-in-opportunities-for-office-persistence/)


[^3]: [GitHub Disable DDEAUTO Oct 2017](https://gist.github.com/wdormann/732bb88d9b5dd5a66c9f1e1498f31a1b)


[^4]: [Microsoft Disable Macros](https://support.office.com/article/enable-or-disable-macros-in-office-files-12b036fd-d140-4e74-b45e-16fed1a7e5c6)


[^5]: [ADSecurity Windows Secure Baseline](https://adsecurity.org/?p=3299)


[^6]: [Microsoft DDE Advisory Nov 2017](https://technet.microsoft.com/library/security/4053440)


[^7]: [Broadcom ESXi SSH](https://knowledge.broadcom.com/external/article/313767/allowing-ssh-access-to-vmware-vsphere-es.html)


[^8]: [Electron Security 2](https://stackoverflow.com/questions/48854265/why-do-i-see-an-electron-security-warning-after-updating-my-electron-project-t)


[^9]: [Microsoft Disable Autorun](https://support.microsoft.com/en-us/kb/967715)


[^10]: [Gmail Delegation](https://support.google.com/a/answer/7223765?hl=en)


[^11]: [Apple Unified Log Analysis Remote Login and Screen Sharing](https://sarah-edwards-xzkc.squarespace.com/blog/2020/4/30/analysis-of-apple-unified-logs-quarantine-edition-entry-6-working-from-home-remote-logins)


[^12]: [Microsoft Entra Configure OAuth Consent](https://learn.microsoft.com/en-us/entra/identity/enterprise-apps/configure-user-consent?pivots=portal)


[^13]: [Microsoft Network access Credential Manager](https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2012-R2-and-2012/jj852185(v=ws.11)?redirectedfrom=MSDN)


[^14]: [SpecterOps Certified Pre Owned](https://web.archive.org/web/20220818094600/https://specterops.io/assets/resources/Certified_Pre-Owned.pdf)


[^15]: [Broadcom ESXi Lockdown Mode](https://knowledge.broadcom.com/external/article/336894/enabling-or-disabling-lockdown-mode-on-a.html)


[^16]: [Microsoft ADV170021 Dec 2017](https://portal.msrc.microsoft.com/security-guidance/advisory/ADV170021)


[^17]: [TechNet Screensaver GP](https://technet.microsoft.com/library/cc938799.aspx)


[^18]: [TechNet Removable Media Control](https://technet.microsoft.com/en-us/library/cc772540(v=ws.10).aspx)


[^19]: [Microsoft Disable DCOM](https://technet.microsoft.com/library/cc771387.aspx)


[^20]: [GitHub MOTW](https://gist.github.com/wdormann/fca29e0dcda8b5c0472e73e10c78c3e7)


[^21]: [NetSPI ClickOnce](https://www.netspi.com/blog/technical-blog/adversary-simulation/all-you-need-is-one-a-clickonce-love-story/)


[^22]: [Google Cloud Threat Intelligence ESXi Hardening 2023](https://cloud.google.com/blog/topics/threat-intelligence/vmware-detection-containment-hardening)


[^23]: [Microsoft Learn ClickOnce Config](https://learn.microsoft.com/en-us/visualstudio/deployment/how-to-configure-the-clickonce-trust-prompt-behavior?view=vs-2022&tabs=csharp)


[^24]: [Amazon AWS IMDS V2](https://aws.amazon.com/blogs/security/defense-in-depth-open-firewalls-reverse-proxies-ssrf-vulnerabilities-ec2-instance-metadata-service/)


[^25]: [Microsoft BEC Campaign](https://www.microsoft.com/security/blog/2021/06/14/behind-the-scenes-of-business-email-compromise-using-cross-domain-threat-data-to-disrupt-a-large-bec-infrastructure/)


[^26]: [Microsoft Disable VBA Jan 2020](https://docs.microsoft.com/en-us/previous-versions/office/troubleshoot/office-developer/turn-off-visual-basic-for-application)


[^27]: [BleepingComputer DDE Disabled in Word Dec 2017](https://www.bleepingcomputer.com/news/microsoft/microsoft-disables-dde-feature-in-word-to-prevent-further-malware-attacks/)


[^28]: [Symantec SSH and ssh-agent](https://www.symantec.com/connect/articles/ssh-and-ssh-agent)


[^29]: [Microsoft AlwaysInstallElevated 2018](https://docs.microsoft.com/en-us/windows/win32/msi/alwaysinstallelevated)

