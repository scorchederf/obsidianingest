---
aliases: 
    - M1045
    
mitre-attack: https://attack.mitre.org/mitigations/M1045
---

## M1045

Code Signing is a security process that ensures the authenticity and integrity of software by digitally signing executables, scripts, and other code artifacts. It prevents untrusted or malicious code from executing by verifying the digital signatures against trusted sources. Code signing protects against tampering, impersonation, and distribution of unauthorized or malicious software, forming a critical defense against supply chain and software exploitation attacks. This mitigation can be implemented through the following measures:<br><br>Enforce Signed Code Execution:<br><br>- Implementation: Configure operating systems (e.g., Windows with AppLocker or Linux with Secure Boot) to allow only signed code to execute.<br>- Use Case: Prevent the execution of malicious PowerShell scripts by requiring all scripts to be signed with a trusted certificate.<br><br>Vendor-Signed Driver Enforcement:<br><br>- Implementation: Enable kernel-mode code signing to ensure that only drivers signed by trusted vendors can be loaded.<br>- Use Case: A malicious driver attempting to modify system memory fails to load because it lacks a valid signature.<br><br>Certificate Revocation Management:<br><br>- Implementation: Use Online Certificate Status Protocol (OCSP) or Certificate Revocation Lists (CRLs) to block certificates associated with compromised or deprecated code.<br>- Use Case: A compromised certificate used to sign a malicious update is revoked, preventing further execution of the software.<br><br>Third-Party Software Verification:<br><br>- Implementation: Require software from external vendors to be signed with valid certificates before deployment.<br>- Use Case: An organization only deploys signed and verified third-party software to prevent supply chain attacks.<br><br>Script Integrity in CI/CD Pipelines:<br><br>- Implementation: Integrate code signing into CI/CD pipelines to sign and verify code artifacts before production release.<br>- Use Case: A software company ensures that all production builds are signed, preventing tampered builds from reaching customers.<br><br>**Key Components of Code Signing**<br><br>- Digital Signature Verification: Verifies the authenticity of code by ensuring it was signed by a trusted entity.<br>- Certificate Management: Uses Public Key Infrastructure (PKI) to manage signing certificates and revocation lists.<br>- Enforced Policy for Unsigned Code: Prevents the execution of unsigned or untrusted binaries and scripts.<br>- Hash Integrity Check: Confirms that code has not been altered since signing by comparing cryptographic hashes.<br>

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1505-server_software_component\|T1505]] | [[T1505-server_software_component\|Server Software Component]] | Ensure all application component binaries are signed by the correct application developers. |
| [[T1204.003-malicious_image\|T1204.003]] | [[T1204.003-malicious_image\|Malicious Image]] | Utilize a trust model such as Docker Content Trust with digital signatures to ensure runtime verification of the integrity and publisher of specific image tags.[^3] [^1]  |
| [[T1525-implant_internal_image\|T1525]] | [[T1525-implant_internal_image\|Implant Internal Image]] | Several cloud service providers support content trust models that require container images be signed by trusted sources.[^1] [^3]  |
| [[T1059.002-applescript\|T1059.002]] | [[T1059.002-applescript\|AppleScript]] | Require that all AppleScript be signed by a trusted developer ID before being executed - this will prevent random AppleScript code from executing.[^2]  This subjects AppleScript code to the same scrutiny as other .app files passing through Gatekeeper. |
| [[T1059-command_and_scripting_interpreter\|T1059]] | [[T1059-command_and_scripting_interpreter\|Command and Scripting Interpreter]] | Where possible, only permit execution of signed scripts. |
| [[T1036.005-match_legitimate_resource_name_or_location\|T1036.005]] | [[T1036.005-match_legitimate_resource_name_or_location\|Match Legitimate Resource Name or Location]] | Require signed binaries and images. |
| [[T1036.001-invalid_code_signature\|T1036.001]] | [[T1036.001-invalid_code_signature\|Invalid Code Signature]] | Require signed binaries. |
| [[T1546.013-powershell_profile\|T1546.013]] | [[T1546.013-powershell_profile\|PowerShell Profile]] | Enforce execution of only signed PowerShell scripts. Sign profiles to avoid them from being modified. |
| [[T1036-masquerading\|T1036]] | [[T1036-masquerading\|Masquerading]] | Require signed binaries. |
| [[T1554-compromise_host_software_binary\|T1554]] | [[T1554-compromise_host_software_binary\|Compromise Host Software Binary]] | Ensure all application component binaries are signed by the correct application developers. |
| [[T1601.001-patch_system_image\|T1601.001]] | [[T1601.001-patch_system_image\|Patch System Image]] | Many vendors provide digitally signed operating system images to validate the integrity of the software used on their platform.  Make use of this feature where possible in order to prevent and/or detect attempts by adversaries to compromise the system image. [^5]  |
| [[T1601.002-downgrade_system_image\|T1601.002]] | [[T1601.002-downgrade_system_image\|Downgrade System Image]] | Many vendors provide digitally signed operating system images to validate the integrity of the software used on their platform.  Make use of this feature where possible in order to prevent and/or detect attempts by adversaries to compromise the system image. [^5]  |
| [[T1543.003-windows_service\|T1543.003]] | [[T1543.003-windows_service\|Windows Service]] | Enforce registration and execution of only legitimately signed service drivers where possible. |
| [[T1059.001-powershell\|T1059.001]] | [[T1059.001-powershell\|PowerShell]] | Set PowerShell execution policy to execute only signed scripts. |
| [[T1505.001-sql_stored_procedures\|T1505.001]] | [[T1505.001-sql_stored_procedures\|SQL Stored Procedures]] | Ensure all application component binaries are signed by the correct application developers.  |
| [[T1543-create_or_modify_system_process\|T1543]] | [[T1543-create_or_modify_system_process\|Create or Modify System Process]] | Enforce registration and execution of only legitimately signed service drivers where possible. |
| [[T1601-modify_system_image\|T1601]] | [[T1601-modify_system_image\|Modify System Image]] | Many vendors provide digitally signed operating system images to validate the integrity of the software used on their platform.  Make use of this feature where possible in order to prevent and/or detect attempts by adversaries to compromise the system image. [^5]  |
| [[T1505.004-iis_components\|T1505.004]] | [[T1505.004-iis_components\|IIS Components]] | Ensure IIS DLLs and binaries are signed by the correct application developers. |
| [[T1546.006-lc_load_dylib_addition\|T1546.006]] | [[T1546.006-lc_load_dylib_addition\|LC_LOAD_DYLIB Addition]] | Enforce that all binaries be signed by the correct Apple Developer IDs. |
| [[T1505.006-vsphere_installation_bundles\|T1505.006]] | [[T1505.006-vsphere_installation_bundles\|vSphere Installation Bundles]] | Enabling the `execInstalledOnly` feature prevents unsigned binaries from being run on ESXi hosts.[^6]  |
| [[T1505.002-transport_agent\|T1505.002]] | [[T1505.002-transport_agent\|Transport Agent]] | Ensure all application component binaries are signed by the correct application developers.  |
| [[T1127.002-clickonce\|T1127.002]] | [[T1127.002-clickonce\|ClickOnce]] | Enforce binary and application integrity with digital signature verification to prevent untrusted code from executing.[^4]  |


## References

[^1]: [Content trust in Azure Container Registry](https://docs.microsoft.com/en-us/azure/container-registry/container-registry-content-trust)


[^2]: [applescript signing](https://www.engadget.com/2013/10/23/applescript-and-automator-gain-new-features-in-os-x-mavericks/)


[^3]: [Content trust in Docker](https://docs.docker.com/engine/security/trust/content_trust/)


[^4]: [Microsoft Learn ClickOnce and Authenticode](https://learn.microsoft.com/en-us/visualstudio/deployment/clickonce-and-authenticode?view=vs-2022)


[^5]: [Cisco IOS Software Integrity Assurance - Deploy Signed IOS](https://tools.cisco.com/security/center/resources/integrity_assurance.html#34)


[^6]: [Google Cloud Threat Intelligence ESXi Hardening 2023](https://cloud.google.com/blog/topics/threat-intelligence/vmware-detection-containment-hardening)

