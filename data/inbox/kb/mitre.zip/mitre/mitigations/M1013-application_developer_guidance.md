---
aliases: 
    - M1013
    
mitre-attack: https://attack.mitre.org/mitigations/M1013
---

## M1013

Application Developer Guidance focuses on providing developers with the knowledge, tools, and best practices needed to write secure code, reduce vulnerabilities, and implement secure design principles. By integrating security throughout the software development lifecycle (SDLC), this mitigation aims to prevent the introduction of exploitable weaknesses in applications, systems, and APIs. This mitigation can be implemented through the following measures:<br> <br>Preventing SQL Injection (Secure Coding Practice):<br><br>- Implementation: Train developers to use parameterized queries or prepared statements instead of directly embedding user input into SQL queries.<br>- Use Case: A web application accepts user input to search a database. By sanitizing and validating user inputs, developers can prevent attackers from injecting malicious SQL commands.<br><br>Cross-Site Scripting (XSS) Mitigation:<br><br>- Implementation: Require developers to implement output encoding for all user-generated content displayed on a web page.<br>- Use Case: An e-commerce site allows users to leave product reviews. Properly encoding and escaping user inputs prevents malicious scripts from being executed in other users’ browsers.<br><br>Secure API Design:<br><br>- Implementation: Train developers to authenticate all API endpoints and avoid exposing sensitive information in API responses.<br>- Use Case: A mobile banking application uses APIs for account management. By enforcing token-based authentication for every API call, developers reduce the risk of unauthorized access.<br><br>Static Code Analysis in the Build Pipeline:<br><br>- Implementation: Incorporate tools into CI/CD pipelines to automatically scan for vulnerabilities during the build process.<br>- Use Case: A fintech company integrates static analysis tools to detect hardcoded credentials in their source code before deployment.<br><br>Threat Modeling in the Design Phase:<br><br>- Implementation: Use frameworks like STRIDE (Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege) to assess threats during application design.<br>- Use Case: Before launching a customer portal, a SaaS company identifies potential abuse cases, such as session hijacking, and designs mitigations like secure session management.<br><br>**Tools for Implementation**:<br><br>- Static Code Analysis Tools: Use tools that can scan for known vulnerabilities in source code.<br>- Dynamic Application Security Testing (DAST): Use tools like Burp Suite or OWASP ZAP to simulate runtime attacks and identify vulnerabilities.<br>- Secure Frameworks: Recommend secure-by-default frameworks (e.g., Django for Python, Spring Security for Java) that enforce security best practices.

### Techniques Addressed by Mitigation
| ID | Name | Description |
| --- | --- | --- |
| [[T1496.003-sms_pumping\|T1496.003]] | [[T1496.003-sms_pumping\|SMS Pumping]] | Consider implementing CAPTCHA protection on forms that send messages via SMS.  |
| [[T1647-plist_file_modification\|T1647]] | [[T1647-plist_file_modification\|Plist File Modification]] | Ensure applications are using Apple's developer guidance which enables hardened runtime.[^1]  |
| [[T1195-supply_chain_compromise\|T1195]] | [[T1195-supply_chain_compromise\|Supply Chain Compromise]] | Application developers should be cautious when selecting third-party libraries to integrate into their application. Additionally, where possible, developers should lock software dependencies to specific versions rather than pulling the latest version on build.[^9]  |
| [[T1574-hijack_execution_flow\|T1574]] | [[T1574-hijack_execution_flow\|Hijack Execution Flow]] | When possible, include hash values in manifest files to help prevent side-loading of malicious libraries.[^4]  |
| [[T1564-hide_artifacts\|T1564]] | [[T1564-hide_artifacts\|Hide Artifacts]] | Application developers should consider limiting the requirements for custom or otherwise difficult to manage file/folder exclusions. Where possible, install applications to trusted system folder paths that are already protected by restricted file and directory permissions. |
| [[T1212-exploitation_for_credential_access\|T1212]] | [[T1212-exploitation_for_credential_access\|Exploitation for Credential Access]] | Application developers should consider taking measures to validate authentication requests by enabling one-time passwords, providing timestamps or sequence numbers for messages sent, using digital signatures, and/or using random session keys.[^6] [^7]  |
| [[T1564.012-file_path_exclusions\|T1564.012]] | [[T1564.012-file_path_exclusions\|File／Path Exclusions]] | Application developers should consider limiting the requirements for custom or otherwise difficult to manage file/folder exclusions. Where possible, install applications to trusted system folder paths that are already protected by restricted file and directory permissions. |
| [[T1550.001-application_access_token\|T1550.001]] | [[T1550.001-application_access_token\|Application Access Token]] | Consider implementing token binding strategies, such as Azure AD token protection or OAuth Proof of Possession, that cryptographically bind a token to a secret. This may prevent the token from being used without knowledge of the secret or possession of the device the token is tied to.[^8] [^3]  |
| [[T1559.003-xpc_services\|T1559.003]] | [[T1559.003-xpc_services\|XPC Services]] | Enable the Hardened Runtime capability when developing applications. Do not include the `com.apple.security.get-task-allow` entitlement with the value set to any variation of true.  |
| [[T1550-use_alternate_authentication_material\|T1550]] | [[T1550-use_alternate_authentication_material\|Use Alternate Authentication Material]] | Consider implementing token binding strategies, such as Azure AD token protection or OAuth Proof of Possession, that cryptographically bind a token to a secret. This may prevent the token from being used without knowledge of the secret or possession of the device the token is tied to.[^8] [^3]  |
| [[T1593.003-code_repositories\|T1593.003]] | [[T1593.003-code_repositories\|Code Repositories]] | Application developers uploading to public code repositories should be careful to avoid publishing sensitive information such as credentials and API keys. |
| [[T1078-valid_accounts\|T1078]] | [[T1078-valid_accounts\|Valid Accounts]] | Ensure that applications do not store sensitive data or credentials insecurely. (e.g. plaintext credentials in code, published credentials in repositories, or credentials in public cloud storage). |
| [[T1564.009-resource_forking\|T1564.009]] | [[T1564.009-resource_forking\|Resource Forking]] | Configure applications to use the application bundle structure which leverages the `/Resources` folder location.[^5]   |
| [[T1574.001-dll\|T1574.001]] | [[T1574.001-dll\|DLL]] | When possible, include hash values in manifest files to help prevent side-loading of malicious libraries.  |
| [[T1195.001-compromise_software_dependencies_and_development_tools\|T1195.001]] | [[T1195.001-compromise_software_dependencies_and_development_tools\|Compromise Software Dependencies and Development Tools]] | Application developers should be cautious when selecting third-party libraries to integrate into their application. Additionally, where possible, developers should lock software dependencies to specific versions rather than pulling the latest version on build.[^9]  GitHub Actions may be pinned to a specific commit hash rather than a tag or branch.[^2]   |
| [[T1593-search_open_websites_domains\|T1593]] | [[T1593-search_open_websites_domains\|Search Open Websites／Domains]] | Application developers uploading to public code repositories should be careful to avoid publishing sensitive information such as credentials and API keys. |
| [[T1559-inter_process_communication\|T1559]] | [[T1559-inter_process_communication\|Inter-Process Communication]] | Enable the Hardened Runtime capability when developing applications. Do not include the `com.apple.security.get-task-allow` entitlement with the value set to any variation of true.  |


## References

[^1]: [Apple Developer Doco Hardened Runtime](https://developer.apple.com/documentation/security/hardened_runtime)


[^2]: [Unit 42 Palo Alto GitHub Actions Supply Chain Attack 2025](https://unit42.paloaltonetworks.com/github-actions-supply-chain-attack)


[^3]: [Okta DPoP 2023](https://www.okta.com/blog/2023/06/a-leap-forward-in-token-security-okta-adds-support-for-dpop/)


[^4]: [FireEye DLL Side-Loading](https://www.fireeye.com/content/dam/fireeye-www/global/en/current-threats/pdfs/rpt-dll-sideloading.pdf)


[^5]: [Apple App Security Overview](https://support.apple.com/guide/security/app-security-overview-sec35dd877d0/1/web/1)


[^6]: [Comparitech Replay Attack](https://www.comparitech.com/blog/information-security/what-is-a-replay-attack/)


[^7]: [Bugcrowd Replay Attack](https://www.bugcrowd.com/glossary/replay-attack/)


[^8]: [Microsoft Token Protection 2023](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-token-protection)


[^9]: [Cider Security Top 10 CICD Security Risks](https://web.archive.org/web/20220316130828/https://www.cidersecurity.io/top-10-cicd-security-risks/)

